package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

import util.Constants;
import util.Language;

public class HelpFrame extends JFrame{
	private static final long serialVersionUID = 6237285733229203675L;
	private JTextArea textArea;
	private JScrollPane scrollPane;
	private JButton btnGeneral;
	private JButton btnMechanics;
	private JButton btnFormula;
	private JButton btnBack;
	private JButton btnControls;
	
	public HelpFrame(){	
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		setVisible(false);
		setTitle(Language.getString("help"));
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		getContentPane().setBackground(Color.DARK_GRAY);
		getContentPane().setLayout(null);
		setResizable(false);
		
		setSize(new Dimension(681, 365));
		setLocation(Constants.calcFrameLocation(getSize()));
		
		btnGeneral = new JButton(Language.getString("general"));
		btnGeneral.setFocusable(false);
		btnGeneral.setFont(new Font(Constants.FONT_NAME_3, Font.PLAIN, 14));
		btnGeneral.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				textArea.setText(Language.getString("general help"));
				textArea.setCaretPosition(0);
			}
		});
		btnGeneral.setBounds(10, 11, 115, 23);
		getContentPane().add(btnGeneral);
		
		btnMechanics = new JButton(Language.getString("mechanics"));
		btnMechanics.setFocusable(false);
		btnMechanics.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				textArea.setText(Language.getString("mechanics help"));
				textArea.setCaretPosition(0);
			}
		});
		btnMechanics.setFont(new Font(Constants.FONT_NAME_3, Font.PLAIN, 14));
		btnMechanics.setBounds(10, 45, 115, 23);
		getContentPane().add(btnMechanics);
		
		btnFormula = new JButton(Language.getString("formula"));
		btnFormula.setFocusable(false);
		btnFormula.setFont(new Font(Constants.FONT_NAME_3, Font.PLAIN, 14));
		btnFormula.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				textArea.setText(Language.getString("formula help"));
				textArea.setCaretPosition(0);
			}
		});
		btnFormula.setBounds(10, 79, 115, 23);
		getContentPane().add(btnFormula);
		
		btnControls = new JButton(Language.getString("controls"));
		btnControls.setFocusable(false);
		btnControls.setFont(new Font(Constants.FONT_NAME_3, Font.PLAIN, 14));
		btnControls.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				textArea.setText(Language.getString("controls help"));
				textArea.setCaretPosition(0);
			}
		});
		btnControls.setBounds(10, 111, 115, 23);
		getContentPane().add(btnControls);
		
		btnBack = new JButton(Language.getString("back"));
		btnBack.setFocusable(false);
		btnBack.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				setVisible(false);
			}
		});
		btnBack.setFont(new Font(Constants.FONT_NAME_3, Font.PLAIN, 14));
		btnBack.setBounds(10, 303, 115, 23);
		getContentPane().add(btnBack);
		
		scrollPane = new JScrollPane();
		scrollPane.setFocusable(false);
		scrollPane.setBounds(135, 11, 530, 315);
		getContentPane().add(scrollPane);
		
		textArea = new JTextArea();
		textArea.setFocusable(false);
		textArea.setEditable(false);
		textArea.setForeground(Color.WHITE);
		textArea.setBackground(Color.DARK_GRAY);
		scrollPane.setViewportView(textArea);
		textArea.setText(Language.getString("choose help category"));
		textArea.setFont(new Font(Constants.FONT_NAME_3, Font.PLAIN, 18));
		textArea.setWrapStyleWord(true);
		textArea.setLineWrap(true);
		textArea.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
	}
	
	public void languageChanged(){
		setTitle(Language.getString("help"));
		btnGeneral.setText(Language.getString("general"));
		btnMechanics.setText(Language.getString("mechanics"));
		btnFormula.setText(Language.getString("formula"));
		btnControls.setText(Language.getString("controls"));
		btnBack.setText(Language.getString("back"));
		textArea.setText(Language.getString("choose help category"));
	}
}