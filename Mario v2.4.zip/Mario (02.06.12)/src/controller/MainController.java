package controller;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

import model.formula.CnfInfo;
import model.formula.Formula;
import model.formula.FormulaFileInfo;
import util.Constants;
import util.GameMode;
import util.Language;
import util.Language.LanguageCode;
import view.FormulaEnterFrame;
import view.HelpFrame;

public class MainController extends Controller{
	private GameController gameController;
	private FormulaEnterFrame formulaEnterFrame;
	private HelpFrame helpFrame;
	private ActionListener actionListener;
	JFileChooser fileChooser;
	
	private List<CnfInfo> cnfInfos;
	
	public MainController(){
		Language.initLanguageCodeMap();
		
		this.gameController = new GameController(this);
		this.gameController.deactivate();
		this.formulaEnterFrame = new FormulaEnterFrame();
		this.helpFrame = new HelpFrame();
		this.fileChooser = new JFileChooser();
		
		this.cnfInfos = new LinkedList<CnfInfo>();
		
		createKeyListener();
		createMouseListener();
		createActionListener();
		
		activate();
	}
	
	@Override
	public void activate(){
		this.formulaEnterFrame.setVisible(true);
		this.helpFrame.setVisible(false);
	}
	@Override
	public void deactivate(){
		this.formulaEnterFrame.setVisible(false);
		this.helpFrame.setVisible(false);
	}
	@Override
	public void createMouseListener(){
		this.mouseListener = new MouseAdapter(){
			@Override
			public void mouseClicked(MouseEvent e){
				if(e.getSource() == MainController.this.formulaEnterFrame.getParseButton()){
					checkFormula();
				}else if(e.getSource() == MainController.this.formulaEnterFrame.getStartGameButton()){
					startGame();
				}else if(e.getSource() == MainController.this.formulaEnterFrame.getEndButton()){
					MainController.this.gameController.deactivate();
					activate();
				}
			}
		};

		//Do that after creating key listener. 
		this.formulaEnterFrame.getParseButton().addMouseListener(this.mouseListener);
		this.formulaEnterFrame.getStartGameButton().addMouseListener(this.mouseListener);
		this.formulaEnterFrame.getEndButton().addMouseListener(this.mouseListener);
	}
	@Override
	public void createKeyListener(){
		this.keyListener = new KeyAdapter(){
			@Override
			public void keyPressed(KeyEvent e){
				if(e.getSource() == MainController.this.formulaEnterFrame){
					switch(e.getKeyCode()){
					case KeyEvent.VK_ESCAPE:
						System.exit(0);
					}
				}else if(e.getSource() == MainController.this.helpFrame){
					switch(e.getKeyCode()){
					case KeyEvent.VK_ESCAPE:
						MainController.this.helpFrame.setVisible(false);
					}
				}
			}
		};
		
		//Do that after creating the listener. 
		this.formulaEnterFrame.addKeyListener(this.keyListener);
		this.helpFrame.addKeyListener(this.keyListener);
	}
	@Override
	public void createActionListener(){
		this.actionListener = new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				//show help frame
				if(e.getSource() == MainController.this.formulaEnterFrame.getMenuItemShowHelp()){
					MainController.this.helpFrame.setVisible(true);
				}else if(e.getSource() == MainController.this.formulaEnterFrame.getMenuItemOpen()){ //open file
					checkFile();
				}else if(e.getSource() == MainController.this.formulaEnterFrame.getMenuItemEnd()){ //end game
					System.exit(0);
				}else if(e.getSource() == MainController.this.formulaEnterFrame.getMenuItemNormalMode()){
					Constants.GAME_MODE = GameMode.NORMAL;
				}else if(e.getSource() == MainController.this.formulaEnterFrame.getMenuItemModerateMode()){
					Constants.GAME_MODE = GameMode.MODERATE;
				}else if(e.getSource() == MainController.this.formulaEnterFrame.getMenuItemChallengingMode()){
					Constants.GAME_MODE = GameMode.CHALLENGING;
				}else if(e.getSource() == MainController.this.formulaEnterFrame.getMenuItemGermanLanguage()){
					Language.setLanguage(LanguageCode.DE);
					MainController.this.formulaEnterFrame.languageChanged();
					MainController.this.helpFrame.languageChanged();
					MainController.this.gameController.getGameFrame().languageChanged();
				}else if(e.getSource() == MainController.this.formulaEnterFrame.getMenuItemEnglishLanguage()){
					Language.setLanguage(LanguageCode.EN);
					MainController.this.formulaEnterFrame.languageChanged();
					MainController.this.helpFrame.languageChanged();
					MainController.this.gameController.getGameFrame().languageChanged();
				}else if(e.getSource() == MainController.this.formulaEnterFrame.getEndButton()){
					System.exit(0);
				}
			}
		};
		
		this.formulaEnterFrame.getMenuItemShowHelp().addActionListener(this.actionListener);
		this.formulaEnterFrame.getMenuItemOpen().addActionListener(this.actionListener);
		this.formulaEnterFrame.getMenuItemEnd().addActionListener(this.actionListener);
		this.formulaEnterFrame.getMenuItemNormalMode().addActionListener(this.actionListener);
		this.formulaEnterFrame.getMenuItemModerateMode().addActionListener(this.actionListener);
		this.formulaEnterFrame.getMenuItemChallengingMode().addActionListener(this.actionListener);
		this.formulaEnterFrame.getEndButton().addActionListener(this.actionListener);
		this.formulaEnterFrame.getMenuItemGermanLanguage().addActionListener(this.actionListener);
		this.formulaEnterFrame.getMenuItemEnglishLanguage().addActionListener(this.actionListener);
	}
	
	private void checkFile(){
		/* Code taken from: http://openbook.galileodesign.de/javainsel5/javainsel15_026.htm */
		
		fileChooser.setFileFilter(new FileFilter(){
			@Override
			public boolean accept(File file){
				return file.isDirectory() || file.getName().toLowerCase().endsWith(".frm") || 
						file.getName().toLowerCase().endsWith(".cnf");
			}
			
			@Override
			public String getDescription(){
				return "BoolTool-frm or DIMACS-cnf files";
			}
		});
		fileChooser.setMultiSelectionEnabled(true);
		
		int state = fileChooser.showOpenDialog(this.formulaEnterFrame);
		if(state == JFileChooser.APPROVE_OPTION){
			File files[] = fileChooser.getSelectedFiles();
			FormulaFileInfo fileInfo = Formula.getFormulaFileInfo(files);
			if(fileInfo.getFormulas() == null){ //invalid formulas in file
				this.formulaEnterFrame.getParseButton().setVisible(true);
				this.formulaEnterFrame.getStartGameButton().setVisible(false);
				this.formulaEnterFrame.getInfoTextArea().setForeground(Color.RED);
				this.formulaEnterFrame.getInfoTextArea().setText(fileInfo.getInfoString());
				System.out.println(fileInfo.getInfoString());
			}else{ //no problems with files
				this.cnfInfos = fileInfo.getFormulas();
				
				if(fileInfo.getFormulas() != null && !fileInfo.getFormulas().isEmpty()){
					this.formulaEnterFrame.getParseButton().setVisible(false);
					this.formulaEnterFrame.getStartGameButton().setVisible(true);
				}else{
					this.formulaEnterFrame.getParseButton().setVisible(true);
					this.formulaEnterFrame.getStartGameButton().setVisible(false);
				}
				
				if(fileInfo.getInfoString().isEmpty()){
					this.formulaEnterFrame.getInfoTextArea().setForeground(Color.GREEN);
					this.formulaEnterFrame.getInfoTextArea().setText("The files have been parsed successfully.");
				}else{
					this.formulaEnterFrame.getInfoTextArea().setForeground(fileInfo.getInfoColor());
					this.formulaEnterFrame.getInfoTextArea().setText(fileInfo.getInfoString());
				}
				System.out.println(fileInfo.getInfoString());
			}
			fileChooser.cancelSelection();
		}
	}
	private void checkFormula(){
		CnfInfo cnfInfo = Formula.getCnf(this.formulaEnterFrame.getFormulaTextArea().getText());
		switch(cnfInfo.getFormulaStateInfo().getState()){
		case VALID:
			this.cnfInfos.clear();
			this.cnfInfos.add(cnfInfo);
			
			this.formulaEnterFrame.getInfoTextArea().setForeground(Color.GREEN);
			if(cnfInfo.getQuantifierInfo() == null)
				this.formulaEnterFrame.getInfoTextArea().setText("CNF: \n" + cnfInfo.getFormulaStateInfo().getFormula());
			else
				this.formulaEnterFrame.getInfoTextArea().setText("QBF: \n" + cnfInfo.getQuantifierInfo() + 
						cnfInfo.getFormulaStateInfo().getFormula());
			this.formulaEnterFrame.getParseButton().setVisible(false);
			this.formulaEnterFrame.getStartGameButton().setVisible(true);
			break;
		case INVALID_MATRIX:
			this.formulaEnterFrame.getInfoTextArea().setForeground(Color.RED);
			this.formulaEnterFrame.getInfoTextArea().setText("The formula is invalid.");
			break;
		case INVALID_PREFIX:
			this.formulaEnterFrame.getInfoTextArea().setForeground(Color.RED);
			this.formulaEnterFrame.getInfoTextArea().setText("The prefix part is invalid.");
			break;
		case TAUTOLOGY:
			this.formulaEnterFrame.getInfoTextArea().setForeground(Color.RED);
			this.formulaEnterFrame.getInfoTextArea().setText("Tautologies are not going to be accepted.");
			break;
		}
	}
	private void startGame(){
		if(!this.cnfInfos.isEmpty()){
			deactivate();
			this.gameController.activate();
			this.formulaEnterFrame.getParseButton().setVisible(true);
			this.formulaEnterFrame.getStartGameButton().setVisible(false);
			
			this.gameController.newGame(this.cnfInfos);
		}else{
			this.formulaEnterFrame.getInfoTextArea().setForeground(Color.RED);
			this.formulaEnterFrame.getInfoTextArea().setText("Error: cnfInfo in MainController is null!");
		}
	}
	
	public static void main(String args[]){
		new MainController();
	}
}