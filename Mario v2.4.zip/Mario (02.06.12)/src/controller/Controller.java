package controller;

import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;

public abstract class Controller{
	protected Controller parentController;
	protected KeyListener keyListener;
	protected MouseListener mouseListener;
	protected ActionListener actionListener;
	
	public Controller(){
		this.parentController = null;
	}
	
	public abstract void activate();
	public abstract void deactivate();
	
	public void createKeyListener(){
		this.keyListener = null;
	}
	public void createMouseListener(){
		this.mouseListener = null;
	}
	public void createActionListener(){
		this.actionListener = null;
	}
	
	public Controller getParentController(){
		return this.parentController;
	}
}