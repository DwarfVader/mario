package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import model.Game;
import model.formula.CnfInfo;
import util.Constants;
import util.Constants.BlockType;
import util.Constants.Direction;
import util.GameState;
import util.ImageLoader;
import util.MapLoader;
import util.ObservableType;
import view.GameFrame;
import view.GameOverPanel;
import view.GamePanel;

public class GameController extends Controller implements Observer{
	private Game game;
	private GameFrame gameFrame;
	private MenuListener menuListener;
	
	public GameController(Controller parentController){
		initVisibleMapping();
		initPassableMapping();
		ImageLoader.initImages();
		MapLoader.init();
		
		this.parentController = parentController;
		this.game = null;
		this.gameFrame = new GameFrame();
		
		createKeyListener();
		createMouseListener();
		createActionListener();
		createMenuListener();
	}
	
	public void newGame(List<CnfInfo> formulas){
		//delete old game
		if(this.game != null){
			this.game.stop();
			this.game.deleteObservers();
		}
		
		this.game = new Game(formulas);
		this.gameFrame.setGame(this.game);
		this.game.addObserver(this.gameFrame);
		this.game.addObserver(this);
		this.game.getActionManager().addObserver(this.gameFrame);
		
		this.game.newGame();
	}
	
	private void initVisibleMapping(){
		Constants.typeVisibleMapping.put(BlockType.BORDER, false);
		Constants.typeVisibleMapping.put(BlockType.ENTRANCE, false);
		Constants.typeVisibleMapping.put(BlockType.EMPTY, false);
		Constants.typeVisibleMapping.put(BlockType.WALL, true);
		Constants.typeVisibleMapping.put(BlockType.KOOPA, false); //this is just the block, where Koopa spawns
		Constants.typeVisibleMapping.put(BlockType.MUSHROOM_BLOCK, true);
		Constants.typeVisibleMapping.put(BlockType.COIN_BLOCK, true);
		Constants.typeVisibleMapping.put(BlockType.USED_BLOCK, true);
		Constants.typeVisibleMapping.put(BlockType.LAVA, true);
		Constants.typeVisibleMapping.put(BlockType.POWER_BLOCK, true);
		Constants.typeVisibleMapping.put(BlockType.COIN, false); //this is just the block, where a coin is placed
		Constants.typeVisibleMapping.put(BlockType.VARIABLE_ASSIGNMENT_POSITIVE, false);
		Constants.typeVisibleMapping.put(BlockType.VARIABLE_ASSIGNMENT_NEGATIVE, false);
		Constants.typeVisibleMapping.put(BlockType.LABEL, false);
		Constants.typeVisibleMapping.put(BlockType.LABEL_LITERAL, false);
		Constants.typeVisibleMapping.put(BlockType.VARIABLE_ASSIGNMENT_POSITIVE, false);
		Constants.typeVisibleMapping.put(BlockType.VARIABLE_ASSIGNMENT_NEGATIVE, false);
		Constants.typeVisibleMapping.put(BlockType.VARIABLE_ASSIGNMENT_POSITIVE_LABEL, false);
		Constants.typeVisibleMapping.put(BlockType.VARIABLE_ASSIGNMENT_NEGATIVE_LABEL, false);
		Constants.typeVisibleMapping.put(BlockType.ARROW, true);
		
		Constants.typeVisibleMapping.put(BlockType.TELEPORT_START, true);
		Constants.typeVisibleMapping.put(BlockType.TELEPORT_DESTINATION, false);
		Constants.typeVisibleMapping.put(BlockType.TELEPORT_START_POSITIVE, true);
		Constants.typeVisibleMapping.put(BlockType.TELEPORT_DESTINATION_POSITIVE, false);
		Constants.typeVisibleMapping.put(BlockType.TELEPORT_START_NEGATIVE, true);
		Constants.typeVisibleMapping.put(BlockType.TELEPORT_DESTINATION_NEGATIVE, false);
		
		Constants.typeVisibleMapping.put(BlockType.VINE, true);
		Constants.typeVisibleMapping.put(BlockType.CROSSOVER_DOWN_LEFT_MAP, false);
		Constants.typeVisibleMapping.put(BlockType.CROSSOVER_DOWN_RIGHT_MAP, false);
		Constants.typeVisibleMapping.put(BlockType.CROSSOVER_UP_LEFT_MAP, false);
		Constants.typeVisibleMapping.put(BlockType.CROSSOVER_UP_RIGHT_MAP, false);
		Constants.typeVisibleMapping.put(BlockType.DOOR_MAP, false);
		Constants.typeVisibleMapping.put(BlockType.TRAMPOLINE, false);
		Constants.typeVisibleMapping.put(BlockType.TRAMPOLINE_DESTINATION, false);
		Constants.typeVisibleMapping.put(BlockType.ROTATE_BLOCK, true);
	}
	private void initPassableMapping(){
		Constants.typePassableMapping.put(BlockType.BORDER, false);
		Constants.typePassableMapping.put(BlockType.ENTRANCE, false); //Still without physical reaction.
		Constants.typePassableMapping.put(BlockType.EMPTY, true);
		Constants.typePassableMapping.put(BlockType.WALL, false);
		Constants.typePassableMapping.put(BlockType.KOOPA, true); //Irrelevant...
		Constants.typePassableMapping.put(BlockType.MUSHROOM_BLOCK, false);
		Constants.typePassableMapping.put(BlockType.COIN_BLOCK, false);
		Constants.typePassableMapping.put(BlockType.USED_BLOCK, false);
		Constants.typePassableMapping.put(BlockType.LAVA, false);
		Constants.typePassableMapping.put(BlockType.POWER_BLOCK, false);
		Constants.typePassableMapping.put(BlockType.COIN, true); //Irrelevant...
		Constants.typePassableMapping.put(BlockType.LABEL, true);
		Constants.typePassableMapping.put(BlockType.LABEL_LITERAL, true);
		Constants.typePassableMapping.put(BlockType.VARIABLE_ASSIGNMENT_POSITIVE, false);
		Constants.typePassableMapping.put(BlockType.VARIABLE_ASSIGNMENT_NEGATIVE, false);
		Constants.typePassableMapping.put(BlockType.VARIABLE_ASSIGNMENT_POSITIVE_LABEL, false);
		Constants.typePassableMapping.put(BlockType.VARIABLE_ASSIGNMENT_NEGATIVE_LABEL, false);
		Constants.typePassableMapping.put(BlockType.ARROW, true);
		
		Constants.typePassableMapping.put(BlockType.TELEPORT_START, false); //Still without physical reaction.
		Constants.typePassableMapping.put(BlockType.TELEPORT_DESTINATION, true);
		Constants.typePassableMapping.put(BlockType.TELEPORT_START_POSITIVE, false); //Still without physical reaction.
		Constants.typePassableMapping.put(BlockType.TELEPORT_DESTINATION_POSITIVE, true);
		Constants.typePassableMapping.put(BlockType.TELEPORT_START_NEGATIVE, false); //Still without physical reaction.
		Constants.typePassableMapping.put(BlockType.TELEPORT_DESTINATION_NEGATIVE, true);
		
		Constants.typePassableMapping.put(BlockType.VINE, false);
		Constants.typePassableMapping.put(BlockType.CROSSOVER_DOWN_LEFT_MAP, true); //Irrelevant...
		Constants.typePassableMapping.put(BlockType.CROSSOVER_DOWN_RIGHT_MAP, true); //Irrelevant...
		Constants.typePassableMapping.put(BlockType.CROSSOVER_UP_LEFT_MAP, true); //Irrelevant...
		Constants.typePassableMapping.put(BlockType.CROSSOVER_UP_RIGHT_MAP, true); //Irrelevant...
		Constants.typePassableMapping.put(BlockType.DOOR_MAP, true); //Irrelevant...
		Constants.typePassableMapping.put(BlockType.TRAMPOLINE, true); //Irrelevant...
		Constants.typePassableMapping.put(BlockType.TRAMPOLINE_DESTINATION, false); //Still without physical reaction.
		Constants.typePassableMapping.put(BlockType.ROTATE_BLOCK, false);
	}
	
	@Override
	public void activate(){
		this.gameFrame.setVisible(true);
	}
	@Override
	public void deactivate(){
		this.gameFrame.setVisible(false);
		this.gameFrame.getGamePanel().getGameOverPanel().setVisible(false);
	}
	@Override
	public void createKeyListener(){
		this.keyListener = new KeyAdapter(){
			@Override
			public void keyPressed(KeyEvent e){
				if(e.getSource().equals(GameController.this.gameFrame)){
					switch(e.getKeyCode()){
					case KeyEvent.VK_ESCAPE:
						if(GameController.this.parentController != null){
							GameController.this.game.stop();
							GameController.this.deactivate();
							GameController.this.parentController.activate();
						}else //cannot switch to a parent controller
							System.exit(0);
						
						break;
						
					//MINIMAP STUFF
					case KeyEvent.VK_M: //toggle show minimap
						GameController.this.game.toggleShowMinimap();
						break;
					case KeyEvent.VK_LEFT:
						GameController.this.game.setMinimapScrollDirection(Direction.WEST, true);
						break;
					case KeyEvent.VK_RIGHT:
						GameController.this.game.setMinimapScrollDirection(Direction.EAST, true);
						break;
					case KeyEvent.VK_UP:
						GameController.this.game.setMinimapScrollDirection(Direction.NORTH, true);
						break;
					case KeyEvent.VK_DOWN:
						GameController.this.game.setMinimapScrollDirection(Direction.SOUTH, true);
						break;
					case KeyEvent.VK_PERIOD:
						Constants.MAP_TRANSPARENCY -= 25;
						if(Constants.MAP_TRANSPARENCY < 0)
							Constants.MAP_TRANSPARENCY = 0;
						break;
					case KeyEvent.VK_COMMA:
						Constants.MAP_TRANSPARENCY += 25;
						if(Constants.MAP_TRANSPARENCY >= 255)
							Constants.MAP_TRANSPARENCY = 255;
						break;
					}
					
					if(!GameController.this.game.isOver()){
						switch(e.getKeyCode()){
						case KeyEvent.VK_A:
							game.getMario().setMoveDirection(Direction.WEST);
							break;
						case KeyEvent.VK_D:
							game.getMario().setMoveDirection(Direction.EAST);
							break;
						case KeyEvent.VK_S:
							if(!game.getMario().isClimbing()){
								game.getMario().setCrouching(true);
							}else{
								game.getMario().setIsClimbingDown(true);
								//if(game.getMario().isOnVine() && !game.getMario().hasFeetOnGround())
									//game.getMario().setIsClimbingDown(true);
							}
							break;
						case KeyEvent.VK_W:
							game.getMario().setIsClimbingUp(true);
							break;
						case KeyEvent.VK_SHIFT:
							game.getMario().setSpinJump(true);
							break;
						case KeyEvent.VK_SPACE:
							game.getMario().setJump(true);
							break;
						case KeyEvent.VK_K:
							game.getMario().setJump(true);
							break;
						case KeyEvent.VK_L:
							game.getMario().setSpinJump(true);
							game.getMario().setJump(true);
							break;
						case KeyEvent.VK_F:
							game.getMario().grabDropTrampoline();
							break;
							
					//SLOMO STUFF
						case KeyEvent.VK_PLUS:
							game.changeSlomoFactor(1.2f);
							break;
						case KeyEvent.VK_MINUS:
							game.changeSlomoFactor(0.8333f);
							break;
						case KeyEvent.VK_NUMPAD0:
						case KeyEvent.VK_0:
							game.setSlomoFactor(1.0f);
							break;
						case KeyEvent.VK_NUMPAD1:
						case KeyEvent.VK_1:
							game.setSlomoFactor(0.2f);
							break;
						case KeyEvent.VK_NUMPAD2:
						case KeyEvent.VK_2:
							game.setSlomoFactor(0.333f);
							break;
						case KeyEvent.VK_NUMPAD3:
						case KeyEvent.VK_3:
							game.setSlomoFactor(0.666f);
							break;
						case KeyEvent.VK_NUMPAD4:
						case KeyEvent.VK_4:
							game.setSlomoFactor(1.2f);
							break;
						case KeyEvent.VK_NUMPAD5:
						case KeyEvent.VK_5:
							game.setSlomoFactor(1.2f);
							break;
						case KeyEvent.VK_NUMPAD6:
						case KeyEvent.VK_6:
							game.setSlomoFactor(1.666f);
							break;
						case KeyEvent.VK_NUMPAD7:
						case KeyEvent.VK_7:
							game.setSlomoFactor(2.0f);
							break;
						case KeyEvent.VK_NUMPAD8:
						case KeyEvent.VK_8:
							game.setSlomoFactor(2.5f);
							break;
						case KeyEvent.VK_NUMPAD9:
						case KeyEvent.VK_9:
							game.setSlomoFactor(3.0f);
							break;
						}
					}
				}else if(e.getSource() == GameController.this.gameFrame.getGamePanel().getGameOverPanel()){
					switch(e.getKeyCode()){
					case KeyEvent.VK_ESCAPE:
						if(GameController.this.parentController != null){
							GameController.this.deactivate();
							GameController.this.parentController.activate();
						}else //cannot switch to a parent controller
							System.exit(0);
						
						break;
					}
				}
			}
			
			@Override
			public void keyReleased(KeyEvent e){
				if(e.getSource().equals(GameController.this.gameFrame)){
					switch(e.getKeyCode()){
					case KeyEvent.VK_LEFT:
						GameController.this.game.setMinimapScrollDirection(Direction.WEST, false);
						break;
					case KeyEvent.VK_RIGHT:
						GameController.this.game.setMinimapScrollDirection(Direction.EAST, false);
						break;
					case KeyEvent.VK_UP:
						GameController.this.game.setMinimapScrollDirection(Direction.NORTH, false);
						break;
					case KeyEvent.VK_DOWN:
						GameController.this.game.setMinimapScrollDirection(Direction.SOUTH, false);
						break;
					case KeyEvent.VK_T:
						GamePanel.isRendering.set(!GamePanel.isRendering.get());
						GameController.this.game.toggleTeleportEnabled();
						break;
					}
					
					if(!GameController.this.game.isOver()){
						switch(e.getKeyCode()){
						case KeyEvent.VK_A:
							game.getMario().resetMoveDirection(Direction.WEST);
							break;
						case KeyEvent.VK_D:
							game.getMario().resetMoveDirection(Direction.EAST);
							break;
						case KeyEvent.VK_S:
							if(!game.getMario().isClimbing()){
								game.getMario().setCrouching(false);
							}else{
								game.getMario().setIsClimbingDown(false);
							}
								
							//if(game.getMario().isOnVine() && game.getMario().hasFeetOnGround())
								//game.getMario().setIsClimbingDown(false);
							break;
						case KeyEvent.VK_W:
							game.getMario().setIsClimbingUp(false);
							break;
						case KeyEvent.VK_SHIFT:
							game.getMario().setSpinJump(false);
							break;
						case KeyEvent.VK_L:
							game.getMario().setSpinJump(false); //No break here!
						case KeyEvent.VK_SPACE:
						case KeyEvent.VK_K:
							game.getMario().setJump(false);
							game.getMario().setJumpReady(true);
							break;
						
						/* Cheater's Finest */
						case KeyEvent.VK_F6:
							game.getMario().toggleCheatInvincibility();
							break;
						case KeyEvent.VK_F7:
							game.getMario().toggleCheatMultiJump();
							break;
						case KeyEvent.VK_F8:
							game.getMario().toggleCheatNoCollision();
							break;
						}
					}
				}
			}
		};
		
		//Do that after creating the listener! 
		this.gameFrame.addKeyListener(this.keyListener);
		this.gameFrame.getGamePanel().getGameOverPanel().addKeyListener(this.keyListener);
	}
	@Override
	public void createActionListener(){
		final GameOverPanel gameOverPanel = this.gameFrame.getGamePanel().getGameOverPanel();
		
		this.actionListener = new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e){
				if(e.getSource() == gameOverPanel.getRestartButton()){
					GameController.this.game.reset();
					GameController.this.gameFrame.getGamePanel().getGameOverPanel().setVisible(false);
				}else if(e.getSource() == gameOverPanel.getNextLevelButton()){
					GameController.this.game.newGame();
					GameController.this.gameFrame.getGamePanel().getGameOverPanel().setVisible(false);
				}else if(e.getSource() == gameOverPanel.getEndButton()){
					if(GameController.this.parentController != null){
						GameController.this.deactivate();
						GameController.this.parentController.activate();
					}else //cannot switch to a parent controller
						System.exit(0);
				}else if(e.getSource() == GameController.this.gameFrame.getMenuItemEnd()){
					if(GameController.this.parentController != null){
						GameController.this.deactivate();
						GameController.this.parentController.activate();
					}else //cannot switch to a parent controller
						System.exit(0);
				}else if(e.getSource() == GameController.this.gameFrame.getMenuItemRestart()){
					GameController.this.game.reset();
					GameController.this.gameFrame.getGamePanel().getGameOverPanel().setVisible(false);
				}
			}
		};
		
		gameOverPanel.getRestartButton().addActionListener(this.actionListener);
		gameOverPanel.getNextLevelButton().addActionListener(this.actionListener);
		gameOverPanel.getEndButton().addActionListener(this.actionListener);
		this.gameFrame.getMenuItemEnd().addActionListener(this.actionListener);
		this.gameFrame.getMenuItemRestart().addActionListener(this.actionListener);
	}
	
	public void createMenuListener(){
		this.menuListener = new MenuListener(){
			@Override
			public void menuCanceled(MenuEvent arg0){}
			@Override
			public void menuDeselected(MenuEvent e){
				unpauseGame();
			}
			@Override
			public void menuSelected(MenuEvent e){
				pauseGame();
			}
		};
		
		this.gameFrame.getMenuFile().addMenuListener(this.menuListener);
		this.gameFrame.getMenuUndo().addMenuListener(this.menuListener);
	}
	
	private void pauseGame(){
		if(this.game.getState() != GameState.PAUSED)
			this.game.pause();
	}
	private void unpauseGame(){
		if(this.game.getState() == GameState.PAUSED)
			this.game.pause();
	}
	
	public GameFrame getGameFrame(){
		return this.gameFrame;
	}
	
	@Override
	public void update(Observable o, Object arg){
		if(o instanceof Game){
			if(arg != null && !(arg instanceof ObservableType))
				return; //ignore illegal arguments
			
			ObservableType type = (ObservableType)arg;
			if(type != ObservableType.GAME_STATE && type != ObservableType.GAME_ERROR_STATE)
				return; //ignore illegal types
			
			//close game, if error state is reached
			if(type == ObservableType.GAME_ERROR_STATE){
				if(GameController.this.parentController != null){
					GameController.this.deactivate();
					GameController.this.parentController.activate();
				}else //cannot switch to a parent controller
					System.exit(0);
			}
			
			Game game = (Game)o;
			if(game.isOver()){
				boolean nextLevel = false;
				if(this.game.getState() == GameState.WON && !this.game.getFormulas().isEmpty())
					nextLevel = true;
				this.gameFrame.getGamePanel().getGameOverPanel().showOptions(nextLevel);
			}
		}
	}
}