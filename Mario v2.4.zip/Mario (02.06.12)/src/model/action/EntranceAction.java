package model.action;

import model.Game;
import model.MapPart;
import util.MyPoint;

public class EntranceAction implements Action{
	protected Game game;
	protected String label;
	protected MapPart mapPart;
	protected MyPoint location;
	protected long time;
	protected long score;
	protected boolean isSuper;
	
	public EntranceAction(Game game, String label, MapPart mapPart, MyPoint location, long time, long score, boolean isSuper){
		this.game = game;
		this.label = label;
		this.mapPart = mapPart;
		this.location = new MyPoint(location);
		this.time = time;
		this.score = score;
		this.isSuper = isSuper;
	}
	
	@Override
	public void undo(){
		this.game.resetCurrentMap(this.mapPart, this.location);
		this.game.resetTime(this.time);
		this.game.resetScore(this.score);
		this.game.getMario().setSuper(this.isSuper);
	}
	@Override
	public String toString(){
		return this.label;
	}
	
	public Game getGame(){
		return this.game;
	}
	public String getLabel(){
		return this.label;
	}
	public MapPart getMapPart(){
		return this.mapPart;
	}
	public MyPoint getLocation(){
		return this.location;
	}
	public long getTime(){
		return this.time;
	}
	public long getScore(){
		return this.score;
	}
}