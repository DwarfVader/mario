package model.action;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Observable;

public class ActionManager extends Observable{
	private List<Action> actions;
	
	public ActionManager(){
		this.actions = new LinkedList<Action>();
	}
	
	public void addAction(Action action){
		//avoid multiple actions for the same Koopa and map entrance
		if(action instanceof KoopaAction){
			for(Action curAction : this.actions)
				if(curAction instanceof KoopaAction && 
						((KoopaAction)action).getKoopa() == ((KoopaAction)curAction).getKoopa())
					return;
		}else if(action instanceof EntranceAction){
			/* Update location and velocity of running Koopa actions. If a new variable/quantifier gadget 
			 * is entered, without having the previous clause gadget unlocked, but having a Koopa 
			 * running, the state is unstable. If the player now undoes until the latest entrance 
			 * action, after the previous gadgets have been unlocked, the gadget is locked again, 
			 * but Koopa disappeared. Therefore Koopa actions have to be updated here. */
			for(Action curAction : this.actions){
				if(curAction instanceof KoopaAction){
					((KoopaAction)curAction).updateValues();
				}
			}
			
			for(Action curAction : new LinkedList<Action>(this.actions))
				if(curAction instanceof EntranceAction &&
						((EntranceAction)action).getLabel().equals(((EntranceAction)curAction).getLabel())){
					/* Remove old entrance action and add it later on to the end of the list. This 
					 * is needed, if the player re-enters a variable/quantifier gadget, while some actions 
					 * have been performed (Koopa smashes bricks). Those additional actions will 
					 * now be in front of the entrance action and not be undone or lost, if the 
					 * entrance action is undone. */
					this.actions.remove(curAction);
					break;
				}
		}else if(action instanceof TrampolineAction){
			/* Check, whether the grabbed trampoline has already been grabbed before. If so, 
			 * ignore the new TrampolineAction as it could reset a trampoline at a wrong 
			 * point of time when the player carries the trampoline to the next quantifier gadget. */
			for(Action curAction : this.actions)
				if(curAction instanceof TrampolineAction && 
						((TrampolineAction)curAction).getTrampoline() == ((TrampolineAction)action).getTrampoline())
					return;
		}
		
		this.actions.add(action);
		update();
	}
	
	public void undoUntil(Action finalAction){
		if(finalAction == null)
			return;
		
		/* Run through list in reversed order and undo everything until the final action is reached. */
		List<Action> reversedList = new LinkedList<Action>(this.actions);
		Collections.reverse(reversedList);
		for(Action action : reversedList){
			action.undo();
			
			if(action == finalAction){
				/* Reset updated Koopa's location and velocity, when undoing following actions. 
				 * If everything is undone, reset remaining Koopa actions. */
				for(Action curAction : this.actions){
					if(curAction instanceof KoopaAction){
						((KoopaAction)curAction).resetValues();
					}
				}
				
				update();
				return;
			}else
				this.actions.remove(action); //drop undone action
		}
	}
	public void undoAll(){
		if(!this.actions.isEmpty())
			undoUntil(this.actions.get(0));
	}
	
	public void clear(){
		this.actions.clear();
	}
	
	private void update(){
		setChanged();
		notifyObservers();
	}
	
	public List<Action> getActions(){
		return this.actions;
	}
	public List<EntranceAction> getEntranceActions(){
		List<EntranceAction> entranceActions = new LinkedList<EntranceAction>();
		
		for(Action action : this.actions)
			if(action instanceof EntranceAction || action instanceof InitializationAction)
				entranceActions.add((EntranceAction)action);
		
		return entranceActions;
	}
}