package model.action;

import model.Game;
import model.MapPart;
import util.MyPoint;

public class InitializationAction extends EntranceAction{
	public InitializationAction(Game game, String label, MapPart mapPart, MyPoint location){
		super(game, label, mapPart, location, 0, 0, false);
	}
	
	@Override
	public void undo(){
		this.game.resetCurrentMap(this.mapPart, this.location);
		this.game.resetTime(0);
		this.game.resetScore(0);
		this.game.getMario().setSuper(false);
	}
	
	public Game getGame(){
		return this.game;
	}
	public MapPart getMapPart(){
		return this.mapPart;
	}
	public MyPoint getLocation(){
		return this.location;
	}
}