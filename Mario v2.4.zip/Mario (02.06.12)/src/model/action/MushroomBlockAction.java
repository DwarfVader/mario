package model.action;

import model.MapPart;
import model.blocks.Block;
import model.blocks.BlockHolder;
import util.Constants.BlockType;

public class MushroomBlockAction implements Action{
	private MapPart map;
	private BlockHolder blockHolder;
	
	public MushroomBlockAction(MapPart map, BlockHolder blockHolder){
		this.map = map;
		this.blockHolder = blockHolder;
	}
	
	@Override
	public void undo(){
		this.blockHolder.setBlock(new Block(this.map, BlockType.MUSHROOM_BLOCK));
	}
	@Override
	public String toString(){
		return "mushroom block action";
	}
	
	public MapPart getGameMap(){
		return this.map;
	}
	public BlockHolder getBlockHolder(){
		return this.blockHolder;
	}
}