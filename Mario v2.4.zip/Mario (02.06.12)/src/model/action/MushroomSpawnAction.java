package model.action;

import model.Game;
import model.Mushroom;

public class MushroomSpawnAction implements Action{
	private Game game;
	private Mushroom mushroom;
	
	public MushroomSpawnAction(Game game, Mushroom mushroom){
		this.game = game;
		this.mushroom = mushroom;
	}
	
	@Override
	public void undo(){
		this.game.removeMushroom(this.mushroom);
	}
	@Override
	public String toString(){
		return "mushroom spawn action";
	}
}