package model.action;

import util.VariableState;
import model.formula.Clause;

public class ClauseAction implements Action{
	private Clause clause;
	
	public ClauseAction(Clause clause){
		this.clause = clause;
	}
	
	@Override
	public void undo(){
		this.clause.setSatisfied(VariableState.UNDEFINED);
	}
	@Override
	public String toString(){
		return "clause action";
	}
	
	public Clause getClause(){
		return clause;
	}
}