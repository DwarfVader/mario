package model.action;

import model.Game;
import model.Koopa;
import model.MapPart;
import util.MyPoint;

public class KoopaAction implements Action{
	private Game game;
	private Koopa koopa;
	private MapPart map;
	private MyPoint location;
	private MapPart latestMap; //needed to reset Koopa to temporary values, when undoing later actions
	private MyPoint latestLocation; //needed to reset Koopa to temporary values, when undoing later actions
	private MyPoint latestVelocity; //needed to reset Koopa to temporary values, when undoing later actions
	
	public KoopaAction(Game game, Koopa koopa, MapPart map, MyPoint location){
		this.game = game;
		this.koopa = koopa;
		this.map = map;
		this.location = new MyPoint(location);
		this.latestMap = map;
		this.latestLocation = new MyPoint(location);
		this.latestVelocity = new MyPoint(koopa.getVelocity());
	}
	
	@Override
	public void undo(){
		//remove Koopa if it still exists and add a new one instead
		this.game.getKoopas().remove(this.koopa);
		this.game.addKoopa(this.map, this.location);
	}
	@Override
	public String toString(){
		return "Koopa action";
	}
	
	/** Update Koopa's latest location and velocity to reset after undoing following actions. */
	public void updateValues(){
		this.latestMap = this.koopa.getCurMap();
		this.latestLocation = new MyPoint(this.koopa.getLocation());
		this.latestVelocity = new MyPoint(this.koopa.getVelocity());
	}
	public void resetValues(){
		this.koopa.setCurMap(this.latestMap);
		this.koopa.setLocation(this.latestLocation);
		this.koopa.setVelocity(this.latestVelocity);
	}
	
	public Koopa getKoopa(){
		return this.koopa;
	}
	public MapPart getGameMap(){
		return this.map;
	}
	public MyPoint getLocation(){
		return this.location;
	}
	public MyPoint getLatestLocation(){
		return this.latestLocation;
	}
	public MyPoint getLatestVelocity(){
		return this.latestVelocity;
	}
}