package model.action;

import model.Trampoline;

public class TrampolineAction implements Action{
	private Trampoline trampoline;
	
	public TrampolineAction(Trampoline trampoline){
		this.trampoline = trampoline;
	}
	
	@Override
	public void undo(){
		this.trampoline.setLocation(this.trampoline.getInitLocation());
		this.trampoline.setCurMap(this.trampoline.getInitMap());
	}
	@Override
	public String toString(){
		return "trampoline action";
	}
	
	public Trampoline getTrampoline(){
		return this.trampoline;
	}
}