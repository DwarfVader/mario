package model.action;

public interface Action{
	public void undo();
}