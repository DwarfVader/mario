package model;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.util.List;

import util.Collidable;
import util.Constants;
import util.Constants.Direction;
import util.ImageLoader;
import util.MyPoint;

public class FinishBar implements Collidable{
	private MapPart map;
	private MyPoint location;
	private Image image;
	private int minHeight;
	private int maxHeight;
	
	private float barHeightPercentage; //bar moves up and down between min and max height
	private boolean isMovingUp;
	private float speed;
	
	private boolean touched;
	
	public FinishBar(MapPart map, MyPoint location, int height){
		this.map = map;
		this.location = location;
		this.image = ImageLoader.finishBarImage;
		this.minHeight = location.getY(); //starts at bottom location
		this.maxHeight = this.minHeight - height;
		
		this.barHeightPercentage = 0.5f;
		this.isMovingUp = true;
		this.speed = 0.2f;
		
		this.touched = false;
	}
	
	public void update(){
		this.barHeightPercentage += (this.isMovingUp ? 1 : -1) * this.speed / 1000f * Constants.TIMER_INTERVAL;
		if(this.barHeightPercentage >= 1){
			this.barHeightPercentage = 1;
			this.isMovingUp = false;
		}else if(this.barHeightPercentage < 0){
			this.barHeightPercentage = 0;
			this.isMovingUp = true;
		}
		
		this.location.y.value = this.minHeight - (this.minHeight - this.maxHeight) * this.barHeightPercentage;
	}
	
	public void reset(){
		this.touched = false;
		this.barHeightPercentage = 0.5f;
	}
	
	public void touch(){
		this.touched = true;
	}
	
	public MapPart getMap(){
		return this.map;
	}
	public MyPoint getRenderLocation(){
		return getCollisionLocation();
	}
	
	@Override
	public List<Direction> collides(Collidable collidable, Point offset){
		return null;
	}
	@Override
	public List<Direction> collides(Collidable collidable, Point offset, boolean ignorePassable){
		return null;
	}

	@Override
	public MyPoint getLocation(){
		return new MyPoint(this.location);
	}
	@Override
	public MyPoint getCollisionLocation(){
		return new MyPoint(this.location.x.value, this.location.y.value - getCollisionSize().height);
	}
	@Override
	public MyPoint getOldCollisionLocation(){
		return getCollisionLocation();
	}
	@Override
	public Dimension getCollisionSize(){
		return new Dimension(Constants.BLOCK_SIZE.width, Constants.BLOCK_SIZE.height/2); //TODO: maybe adjust these values
	}
	@Override
	public MapPart getCurMap(){
		return this.map;
	}
	@Override
	public Image getImage(){
		return this.image;
	}
	public boolean isTouched(){
		return this.touched;
	}
}