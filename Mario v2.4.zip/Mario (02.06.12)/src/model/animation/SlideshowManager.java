package model.animation;

import java.awt.Dimension;
import java.awt.Point;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import model.Game;
import model.MapPart;
import util.Constants;
import util.ImageLoader;
import util.Constants.Direction;

public class SlideshowManager{
	private static SlideshowManager instance;
	
	private Queue<Slideshow> marioSlideshows;
	private Queue<Slideshow> backgroundSlideshows;
	private Map<MapPart, Queue<Slideshow>> slideshowMapping;
	
	public Slideshow coinSlideshow;
	public Slideshow questionBlockSlideshow;
	public Slideshow teleportBlockSlideshow1;
	public Slideshow teleportBlockSlideshow2;
	public Slideshow koopaShellSlideshow;
	public Slideshow koopaRunLeftSlideshow;
	public Slideshow koopaRunRightSlideshow;
	
	private SlideshowManager(){
		this.marioSlideshows = new ConcurrentLinkedQueue<Slideshow>();
		this.backgroundSlideshows = new ConcurrentLinkedQueue<Slideshow>();
		this.slideshowMapping = new HashMap<MapPart, Queue<Slideshow>>();
		
		this.coinSlideshow = new Slideshow(ImageLoader.coinImages, 500);
		this.questionBlockSlideshow = new Slideshow(ImageLoader.questionBlockImages, 800);
		this.teleportBlockSlideshow1 = new Slideshow(ImageLoader.teleportImages1, 600);
		this.teleportBlockSlideshow2 = new Slideshow(ImageLoader.teleportImages2, 600);
		this.koopaShellSlideshow = new Slideshow(ImageLoader.koopaShellImages, 250);
		this.koopaRunLeftSlideshow = new Slideshow(ImageLoader.koopaRunImages.get(Direction.WEST), 400);
		this.koopaRunRightSlideshow = new Slideshow(ImageLoader.koopaRunImages.get(Direction.EAST), 400);
	}
	public static SlideshowManager getInstance(){
		if(instance == null)
			instance = new SlideshowManager();
		
		return instance;
	}
	
	public static void reset(){
		instance = new SlideshowManager();
	}
	
	public void addMarioSlideshow(Slideshow slideshow){
		this.marioSlideshows.add(slideshow);
	}
	public void addMarioSlideshows(Collection<Slideshow> slideshows){
		this.marioSlideshows.addAll(slideshows);
	}
	public void removeMarioSlideshow(Slideshow slideshow){
		this.marioSlideshows.remove(slideshow);
	}
	public void removeMarioSlideshows(Collection<Slideshow> slideshows){
		this.marioSlideshows.removeAll(slideshows);
	}
	
	public void addBackgroundSlideshow(Slideshow slideshow){
		this.backgroundSlideshows.add(slideshow);
	}
	public void addBackgroundSlideshows(Collection<Slideshow> slideshows){
		this.backgroundSlideshows.addAll(slideshows);
	}
	public void removeBackgroundSlideshow(Slideshow slideshow){
		this.backgroundSlideshows.remove(slideshow);
	}
	public void removeBackgroundSlideshows(Collection<Slideshow> slideshows){
		this.backgroundSlideshows.removeAll(slideshows);
	}
	
	public void addSlideshow(MapPart map, Slideshow slideshow){
		if(!this.slideshowMapping.keySet().contains(map))
			this.slideshowMapping.put(map, new ConcurrentLinkedQueue<Slideshow>());
		
		this.slideshowMapping.get(map).add(slideshow);
	}
	public void addSlideshows(MapPart map, Collection<Slideshow> slideshows){
		if(!this.slideshowMapping.keySet().contains(map))
			this.slideshowMapping.put(map, new ConcurrentLinkedQueue<Slideshow>());
		
		this.slideshowMapping.get(map).addAll(slideshows);
	}
	public void removeSlideshow(MapPart map, Slideshow slideshow){
		if(this.slideshowMapping.keySet().contains(map))
			this.slideshowMapping.get(map).remove(slideshow);
	}
	public void removeSlideshows(MapPart map, Collection<Slideshow> slideshows){
		if(this.slideshowMapping.keySet().contains(map))
			this.slideshowMapping.get(map).removeAll(slideshows);
	}
	
	public void incrementTime(Game game, int value){
		for(Slideshow slideshow : this.marioSlideshows)
			slideshow.incrementTime(value);
		for(Slideshow slideshow : this.backgroundSlideshows)
			slideshow.incrementTime(value);
		
		this.coinSlideshow.incrementTime(value);
		this.questionBlockSlideshow.incrementTime(value);
		this.teleportBlockSlideshow1.incrementTime(value);
		this.teleportBlockSlideshow2.incrementTime(value);
		this.koopaShellSlideshow.incrementTime(value);
		this.koopaRunLeftSlideshow.incrementTime(value);
		this.koopaRunRightSlideshow.incrementTime(value);
		
		//consider all neighboring blocks for rendering
		Dimension numMapsToRender = Constants.NUM_MAPS_TO_RENDER;
		Point offset = new Point(-numMapsToRender.width/2, -numMapsToRender.height/2);
		if(game.getCurMap().getIndex().x + offset.x < 0)
			offset.x = -game.getCurMap().getIndex().x;
		else if(game.getCurMap().getIndex().x + offset.x + numMapsToRender.width >= game.getNumMapParts().width)
			offset.x = game.getNumMapParts().width - game.getCurMap().getIndex().x - numMapsToRender.width;
		if(game.getCurMap().getIndex().y + offset.y < 0)
			offset.y = -game.getCurMap().getIndex().y;
		else if(game.getCurMap().getIndex().y + offset.y + numMapsToRender.height >= game.getNumMapParts().height)
			offset.y = game.getNumMapParts().height - game.getCurMap().getIndex().y - numMapsToRender.height;
		for(int ii = 0 + offset.x; ii < numMapsToRender.width + offset.x; ii++)
			for(int jj = 0 + offset.y; jj < numMapsToRender.height + offset.y; jj++){
				MapPart map = game.getMap(game.getCurMap().getIndex().x + ii, game.getCurMap().getIndex().y + jj);
				if(map == null || !this.slideshowMapping.containsKey(map))
					continue;
				
				for(Slideshow slideshow : this.slideshowMapping.get(map))
					slideshow.incrementTime(value);
			}
	}
}