package model.animation;

import java.util.LinkedList;
import java.util.List;

public class Animation{
	public List<AnimationStep> steps;
	
	public Animation(){
		this.steps = new LinkedList<AnimationStep>();
	}
	
	public void addAnimationStep(AnimationStep step){
		this.steps.add(step);
	}
	
	public AnimationStep getStep(){
		if(this.steps.isEmpty())
			return null;
		else{
			if(this.steps.get(0).isDone()){
				this.steps.remove(0);
				return getStep();
			}else
				return this.steps.get(0);
		}
	}
}