package model.animation;

import util.MyDouble;

public class DoubleCondition implements Condition{
	private MyDouble value;
	private String operator;
	private double compareValue;
	
	public DoubleCondition(MyDouble value, String operator, double compareValue){
		this.value = value;
		this.operator = operator;
		this.compareValue = compareValue;
	}
	
	@Override
	public boolean getState(){
		if(this.operator.equals("<"))
			return this.value.value < this.compareValue;
		if(this.operator.equals(">"))
			return this.value.value > this.compareValue;
		if(this.operator.equals("!="))
			return this.value.value != this.compareValue;
		if(this.operator.equals("=="))
			return this.value.value == this.compareValue;
		
		return false; //nonsensical operator
	}
}