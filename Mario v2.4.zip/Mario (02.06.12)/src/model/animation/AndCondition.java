package model.animation;

public class AndCondition implements Condition{
	private Condition operand1;
	private Condition operand2;
	
	public AndCondition(Condition operand1, Condition operand2){
		this.operand1 = operand1;
		this.operand2 = operand2;
	}
	
	@Override
	public boolean getState(){
		return this.operand1.getState() && this.operand2.getState();
	} 
}