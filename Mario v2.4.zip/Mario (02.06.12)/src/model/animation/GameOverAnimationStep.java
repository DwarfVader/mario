package model.animation;

import util.GameState;

public class GameOverAnimationStep extends AnimationStep{
	private GameState state;
	
	public GameOverAnimationStep(GameState state){
		super(0, 0, false);
		
		this.state = state;
	}
	
	@Override
	public void checkFinishCondition(Object destinationValue){
		this.isDone = true;
	}
	
	public GameState getState(){
		return this.state;
	}
}