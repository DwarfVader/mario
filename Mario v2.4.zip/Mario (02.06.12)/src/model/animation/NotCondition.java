package model.animation;

public class NotCondition implements Condition{
	private Condition operand;
	
	public NotCondition(Condition operand){
		this.operand = operand;
	}
	
	@Override
	public boolean getState(){
		return !this.operand.getState();
	} 
}