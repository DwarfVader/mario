package model.animation;

public interface Condition{
	public abstract boolean getState();
}