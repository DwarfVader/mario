package model.blocks;

import model.MapPart;
import util.Constants;
import util.Constants.BlockType;
import util.Movable;
import util.MyPoint;

public class TeleportBlock extends Block{
	private String label;
	private MyPoint location;
	private boolean isStart;
	
	public TeleportBlock(MapPart map, BlockType type, String label, MyPoint location, boolean isStart){
		super(map, type);
		
		this.label = label;
		this.location = location;
		this.isStart = isStart; //false denotes destination block
	}
	
	public String getLabel(){
		return this.label;
	}
	public MyPoint getDestinationLocation(Movable movable){
		return new MyPoint(this.location.getX() + Constants.MARIO_SIZE_OFFSET, 
				this.location.getY() + movable.getCollisionSize().height - Constants.MARIO_SIZE_OFFSET);
	}
	public boolean isStart(){
		return this.isStart;
	}
}