package model.blocks;

import model.MapPart;
import model.formula.Clause;
import model.formula.Formula;
import model.formula.Variable;
import util.Constants.BlockType;
import util.MyPoint;
import util.VariableState;

public class TrampolineDestinationBlock extends Block{
	private MyPoint location;
	private Variable variable;
	
	public TrampolineDestinationBlock(MapPart map, BlockType type, MyPoint location, Clause clause, Variable variable){
		super(map, type);
		
		this.location = new MyPoint(location);
		this.variable = variable;
	}
	
	public void satisfyLiteral(Formula formula){
		if(this.variable != null){
			this.variable.setSatisfied(VariableState.TRUE);
		}
	}
	
	public MyPoint getLocation(){
		return this.location;
	}
	public Variable getVariable(){
		return this.variable;
	}
}