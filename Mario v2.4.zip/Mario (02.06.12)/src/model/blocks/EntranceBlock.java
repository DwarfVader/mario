package model.blocks;

import model.MapPart;
import util.Constants.BlockType;

public class EntranceBlock extends Block{
	private String label;
	
	public EntranceBlock(MapPart map, BlockType type, String label){
		super(map, type);
		
		this.label = label;
	}
	
	public String getLabel(){
		return this.label;
	}
}