package model.blocks;

import java.awt.Dimension;
import java.awt.Image;

import model.MapPart;
import model.animation.Slideshow;
import model.animation.SlideshowManager;
import util.Constants;
import util.Constants.BlockType;
import util.ImageLoader;

public class Block{
	protected MapPart map;
	protected BlockType type;
	protected Slideshow slideshow;
	protected Image image;
	
	public Block(MapPart map, BlockType type){
		this.map = map;
		this.type = type;
		this.image = null;
		
		updateSlideshow();
	}
	
	public void updateSlideshow(){
		switch(type){
		case ROTATE_BLOCK:
			this.slideshow = null; //set in RotateBlock constructor
			break;
		case COIN_BLOCK:
		case MUSHROOM_BLOCK:
		case POWER_BLOCK:
			this.slideshow = SlideshowManager.getInstance().questionBlockSlideshow;
			break;
		case TELEPORT_START:
		case TELEPORT_START_POSITIVE:
		case TELEPORT_START_NEGATIVE:
			this.slideshow = SlideshowManager.getInstance().teleportBlockSlideshow;
			break;
		default:
			this.image = ImageLoader.getBlockImage(this.type);
		}
	}
	
	public boolean passable(){
		return Constants.typePassableMapping.get(this.type);
	}
	
	public MapPart getMap(){
		return this.map;
	}
	public BlockType getType(){
		return this.type;
	}
	public Dimension getCollisionSize(){
		return Constants.BLOCK_SIZE;
	}
	public Image getImage(){
		if(this.image != null)
			return this.image;
		else if(this.slideshow != null)
			return getSlideshow().getCurrentImage();
		else
			return ImageLoader.dummyImage;
	}
	public Slideshow getSlideshow(){
		return this.slideshow;
	}
}