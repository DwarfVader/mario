package model.blocks;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import util.TeleportBlockGroup;
import util.TimerDepending;

public class BlockManager{
	private static BlockManager instance;
	
	private List<TimerDepending> timedBlocks;
	private Map<String, List<TeleportBlockGroup>> startTeleportBlockMap;
	private Map<String, List<TeleportBlockGroup>> destinationTeleportBlockMap; //use of block group is inefficient but comfortable
	
	private BlockManager(){
		this.timedBlocks = new LinkedList<TimerDepending>();
		this.startTeleportBlockMap = new HashMap<String, List<TeleportBlockGroup>>();
		this.destinationTeleportBlockMap = new HashMap<String, List<TeleportBlockGroup>>();
	}
	
	public static BlockManager getInstance(){
		if(instance == null)
			instance = new BlockManager();
		
		return instance;
	}
	public static void reset(){
		if(instance != null)
			instance.clear();
	}
	public void clear(){
		this.timedBlocks.clear();
		this.startTeleportBlockMap.clear();
		this.destinationTeleportBlockMap.clear();
	}
	
	public void incrementTime(int timerInterval){
		for(TimerDepending timedBlock : this.timedBlocks)
			timedBlock.incrementTime(timerInterval);
	}
	public void registerTimedBlock(TimerDepending timedBlock){
		if(!this.timedBlocks.contains(timedBlock))
			this.timedBlocks.add(timedBlock);
	}
	public void unregisterTimedBlock(TimerDepending timedBlock){
		this.timedBlocks.remove(timedBlock);
	}
	
	public void addTeleportBlocks(TeleportBlockGroup blockGroup, boolean isStart, boolean addFirst){
		Map<String, List<TeleportBlockGroup>> map = isStart ? this.startTeleportBlockMap : this.destinationTeleportBlockMap;
		
		if(!map.containsKey(blockGroup.getLabel())){
			List<TeleportBlockGroup> list = new LinkedList<TeleportBlockGroup>();
			if(addFirst)
				list.add(0, blockGroup);
			else
				list.add(blockGroup);
			map.put(blockGroup.getLabel(), list);
		}else{
			map.get(blockGroup.getLabel()).add(blockGroup);
		}
	}
	public TeleportBlock getDestinationBlock(TeleportBlock startBlock, boolean isPSPACE){
		List<TeleportBlockGroup> teleportBlockGroups = this.startTeleportBlockMap.get(startBlock.getLabel());
		for(int i = 0; i < teleportBlockGroups.size(); i++)
			if(teleportBlockGroups.get(i).getBlocks().contains(startBlock))
				return this.destinationTeleportBlockMap.get(startBlock.getLabel()).get((i + (isPSPACE ? 1 : 0)) % 
						teleportBlockGroups.size()).getBlocks().get(0);
		
		return null; //dummy; hopefully won't reach that
	}
	
	/*public int getIndex(TeleportBlock block){
		Map<String, List<TeleportBlockGroup>> map = block.isStart() ? this.startTeleportBlockMap : this.destinationTeleportBlockMap;
		List<TeleportBlockGroup> list = map.get(block.getLabel());
		if(list != null)
			for(int i = 0; i < list.size(); i++)
				if(list.get(i).getBlocks().contains(block))
					return i;
		return -1;
	}*/
}