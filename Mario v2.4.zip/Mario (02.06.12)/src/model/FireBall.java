package model;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.util.List;

import util.Collidable;
import util.Constants;
import util.Constants.Direction;
import util.ImageLoader;
import util.MyPoint;

public class FireBall implements Collidable{
	private MapPart curMap;
	private MyPoint location;
	
	public FireBall(MapPart map, MyPoint location){
		this.curMap = map;
		this.location = new MyPoint(location);
	}
	
	public void setLocation(int x, int y){
		this.location.x.value = x;
		this.location.y.value = y;
	}
	
	@Override
	public MyPoint getCollisionLocation(){
		return this.location;
	}
	@Override
	public MyPoint getOldCollisionLocation(){
		return this.location;
	}
	@Override
	public Dimension getCollisionSize(){
		return Constants.FIREBALL_SIZE;
	}
	@Override
	public Image getImage(){
		return ImageLoader.fireBallImage;
	}
	@Override
	public MapPart getCurMap(){
		return this.curMap;
	}
	@Override
	public MyPoint getLocation(){
		return this.location;
	}
	
	@Override
	public List<Direction> collides(Collidable collidable, Point offset){
		return null;
	}
	@Override
	public List<Direction> collides(Collidable collidable, Point offset, boolean ignorePassable){
		return null;
	}
}