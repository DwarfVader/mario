package model;

import java.awt.Dimension;
import java.awt.Point;
import java.util.HashMap;
import java.util.Map;

import util.Constants.BlockType;

public class MapTemplate{
	private BlockType types[][];
	private Dimension size;
	private Map<Point, String> labels;
		
	public MapTemplate(BlockType types[][], Dimension size){
		this(types, size, null);
	}
	public MapTemplate(BlockType types[][], Dimension size, Map<Point, String> labels){
		this.types = types;
		this.size = size;
		if(labels != null)
			this.labels = new HashMap<Point, String>(labels);
		else
			this.labels = new HashMap<Point, String>();
	}
	
	public void mirrorHorizontally(){
		BlockType help;
		for(int i = 0; i < this.size.width/2; i++)
			for(int j = 0; j < this.size.height; j++){
				help = this.types[i][j];
				this.types[i][j] = this.types[this.size.width-1 - i][j];
				this.types[this.size.width-1 - i][j] = help;
			}
	}
	
	public BlockType[][] getTypes(){
		return this.types;
	}
	public Dimension getSize(){
		return this.size;
	}
	public Map<Point, String> getLabels(){
		return this.labels;
	}
	public String getLabel(Point index){
		return this.labels.get(index);
	}
}