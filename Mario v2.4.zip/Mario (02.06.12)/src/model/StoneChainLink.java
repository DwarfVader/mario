package model;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.util.LinkedList;
import java.util.List;

import util.Collidable;
import util.Constants;
import util.Constants.Direction;
import util.ImageLoader;
import util.MyPoint;

public class StoneChainLink implements Collidable{
	private MapPart curMap;
	private String type;
	private MyPoint location;
	
	public StoneChainLink(MapPart map, String type, MyPoint location){
		this.curMap = map;
		this.type = type;
		this.location = new MyPoint(location);
	}
	
	public void setLocation(int x, int y){
		this.location.x.value = x;
		this.location.y.value = y;
	}
	
	@Override
	public MyPoint getCollisionLocation(){
		return this.location;
	}
	@Override
	public MyPoint getOldCollisionLocation(){
		return this.location;
	}
	@Override
	public Dimension getCollisionSize(){
		if(type.equals("chain"))
			return Constants.BLOCK_SIZE;
		else if(type.equals("ball"))
			return Constants.STONEBALL_SIZE;
		
		//should not reach this code
		System.out.println("Invalid chain link type!");
		return Constants.BLOCK_SIZE; //dummy
	}
	@Override
	public Image getImage(){
		if(type.equals("chain"))
			return ImageLoader.stoneChainImage;
		else if(type.equals("ball"))
			return ImageLoader.stoneBallImage;
		
		//should not reach this code
		System.out.println("Invalid chain link type!");
		return ImageLoader.dummyImage; //dummy
	}
	@Override
	public MapPart getCurMap(){
		return this.curMap;
	}
	public String getType(){
		return this.type;
	}
	@Override
	public MyPoint getLocation(){
		return this.location;
	}

	@Override
	public List<Direction> collides(Collidable collidable, Point offset){
		return collides(collidable, offset, false);
	}
	@Override
	public List<Direction> collides(Collidable collidable, Point offset, boolean ignorePassable){
		List<Direction> directions = new LinkedList<Direction>();
		if(Math.sqrt(Math.pow(collidable.getCollisionLocation().x.value - getCollisionLocation().x.value - offset.x + 
				collidable.getCollisionSize().width/2 - getCollisionSize().width/2, 2) + 
				Math.pow(collidable.getCollisionLocation().y.value - getCollisionLocation().y.value - offset.y + 
				collidable.getCollisionSize().height/2- getCollisionSize().height/2, 2)) < (getCollisionSize().width + collidable.getCollisionSize().width)/2)
			directions.add(Direction.NORTH);
		return directions;
	}
}