package model;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.util.List;

import model.animation.SlideshowManager;
import util.Collidable;
import util.Constants;
import util.Constants.Direction;
import util.MyPoint;

public class Coin implements Collidable{
	private MapPart map;
	private MyPoint location;
	
	public Coin(MapPart map, MyPoint location){
		this.map = map;
		this.location = new MyPoint(location);
	}
	
	public MapPart getCurMap(){
		return this.map;
	}
	public MyPoint getLocation(){
		return this.location;
	}
	
	@Override
	public MyPoint getCollisionLocation(){
		return new MyPoint(this.location.x.value, this.location.y.value);
	}
	@Override
	public MyPoint getOldCollisionLocation(){
		return new MyPoint(this.location.x.value, this.location.y.value);
	}
	@Override
	public Dimension getCollisionSize(){
		return new Dimension(Constants.BLOCK_SIZE);
	}
	public Image getImage(){
		return SlideshowManager.getInstance().coinSlideshow.getCurrentImage();
	}
	
	@Override
	public List<Direction> collides(Collidable collidable, Point offset){
		return null;
	}
	@Override
	public List<Direction> collides(Collidable collidable, Point offset, boolean ignorePassable){
		return null;
	}
}