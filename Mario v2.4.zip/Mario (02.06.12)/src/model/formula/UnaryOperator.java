package model.formula;

public interface UnaryOperator extends Operator{}