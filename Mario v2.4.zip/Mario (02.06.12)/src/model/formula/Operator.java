package model.formula;

public interface Operator extends Token{}