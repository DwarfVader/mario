package model.formula;

public enum FormulaState{
	VALID,
	TAUTOLOGY,
	INVALID_MATRIX,
	INVALID_PREFIX
}