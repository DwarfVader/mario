package model.formula;

import java.awt.Color;
import java.util.List;

public class FormulaFileInfo{
	private List<CnfInfo> formulas;
	private String infoString;
	private Color infoColor;
	
	public FormulaFileInfo(List<CnfInfo> formulas, String infoString){
		this(formulas, infoString, Color.RED);
	}
	public FormulaFileInfo(List<CnfInfo> formulas, String infoString, Color infoColor){
		this.formulas = formulas;
		this.infoString = infoString;
		this.infoColor = infoColor;
	}
	
	public List<CnfInfo> getFormulas(){
		return this.formulas;
	}
	public String getInfoString(){
		return this.infoString;
	}
	public Color getInfoColor(){
		return this.infoColor;
	}
}