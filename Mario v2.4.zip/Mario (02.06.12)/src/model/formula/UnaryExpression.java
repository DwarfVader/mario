package model.formula;

import java.awt.Color;
import java.util.LinkedList;
import java.util.List;

import util.ColoredString;

public class UnaryExpression implements Expression{
	private UnaryOperator operator;
	private Expression expression;
	
	public UnaryExpression(UnaryOperator operator, Expression expression){
		this.operator = operator;
		this.expression = expression;
	}
	
	public UnaryOperator getOperator(){
		return this.operator;
	}
	public Expression getExpression(){
		return this.expression;
	}
	
	@Override
	public List<ColoredString> getColoredStrings(Formula formula){
		List<ColoredString> coloredStrings = new LinkedList<ColoredString>();
		
		coloredStrings.add(new ColoredString(this.operator.toString(), Color.WHITE));
		if(this.expression instanceof Atom || this.expression instanceof UnaryExpression)
			coloredStrings.addAll(this.expression.getColoredStrings(formula));
		else{
			coloredStrings.add(new ColoredString("(", Color.WHITE));
			coloredStrings.addAll(this.expression.getColoredStrings(formula));
			coloredStrings.add(new ColoredString(")", Color.WHITE));
		}
		
		return coloredStrings;
	}
	
	@Override
	public String toString(){
		return this.operator.toString() + 
				(this.expression instanceof Atom || this.expression instanceof UnaryExpression ? 
				this.expression.toString() : "(" + this.expression.toString() + ")");
	}
}