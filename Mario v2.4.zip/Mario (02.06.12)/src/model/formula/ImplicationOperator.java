package model.formula;

import util.Constants;

public class ImplicationOperator implements BinaryOperator{
	public ImplicationOperator(){}
	
	@Override
	public String toString(){
		return Constants.IMPLICATION + "";
	}
}