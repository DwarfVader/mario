package model.formula;

public class FormulaStateInfo{
	private String formula;
	private Expression originalExpression;
	private FormulaState state;
	
	public FormulaStateInfo(String formula, Expression originalExpression, FormulaState state){
		this.formula = (formula == null || formula.isEmpty() ? null : formula);
		this.originalExpression = originalExpression;
		this.state = state;
	}
	
	public String getFormula(){
		return this.formula;
	}
	public Expression getOriginalExpression(){
		return this.originalExpression;
	}
	public FormulaState getState(){
		return this.state;
	}
}