package model.formula;

import util.VariableState;

public class NormalVariable extends Variable{
	public NormalVariable(String name){
		this(name, VariableState.UNDEFINED);
	}
	public NormalVariable(String name, VariableState state){
		super(name, state);
	}
}