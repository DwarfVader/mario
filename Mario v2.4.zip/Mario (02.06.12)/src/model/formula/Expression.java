package model.formula;

import java.util.List;

import util.ColoredString;

public interface Expression extends Token{
	public List<ColoredString> getColoredStrings(Formula formula);
}