package model.formula;

public interface BinaryOperator extends Operator{}