package model.formula;

import util.VariableState;

public abstract class Variable{
	protected String name;
	protected VariableState state;
	protected VariableState satisfied;
	
	public Variable(String name){
		this(name, VariableState.UNDEFINED);
	}
	public Variable(String name, VariableState state){
		this.name = name;
		this.state = state;
		this.satisfied = VariableState.UNDEFINED;
	}
	
	public void setState(VariableState state){
		//if(this.state == VariableState.UNDEFINED) //avoid multiple decisions
			this.state = state;
	}
	public void setSatisfied(VariableState satisfied){
		this.satisfied = satisfied;
	}
	
	public String getName(){
		return this.name;
	}
	public VariableState getState(){
		return this.state;
	}
	public VariableState getSatisfied(){
		return this.satisfied;
	}
	
	@Override
	public boolean equals(Object o){
		if(o == null || !(o instanceof Variable))
			return false;
		
		Variable other = (Variable)o;
		if(!other.name.equals(this.name) || other.state != this.state)
			return false;
		
		return true;
	}
}