package model.formula;

import util.Constants;

public class NotOperator implements UnaryOperator{
	public NotOperator(){}
	
	@Override
	public String toString(){
		return Constants.NOT + "";
	}
}