package model.formula;

import java.util.List;

public class SplitExtraVariables{
	private List<String> positiveExtraVariables;
	private List<String> negativeExtraVariables;
	
	public SplitExtraVariables(List<String> positiveExtraVariables, List<String> negativeExtraVariables){
		this.positiveExtraVariables = positiveExtraVariables;
		this.negativeExtraVariables = negativeExtraVariables;
	}
	
	public List<String> getPositiveExtraVariables(){
		return this.positiveExtraVariables;
	}
	public List<String> getNegativeExtraVariables(){
		return this.negativeExtraVariables;
	}
}