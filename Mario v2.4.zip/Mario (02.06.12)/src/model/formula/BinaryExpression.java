package model.formula;

import java.awt.Color;
import java.util.LinkedList;
import java.util.List;

import util.ColoredString;

public class BinaryExpression implements Expression{
	public BinaryOperator operator;
	public Expression expression1;
	public Expression expression2;
	
	public BinaryExpression(BinaryOperator operator, Expression expression1, Expression expression2){
		this.operator = operator;
		this.expression1 = expression1;
		this.expression2 = expression2;
	}
	
	public BinaryOperator getOperator(){
		return this.operator;
	}
	public Expression getExpression1(){
		return this.expression1;
	}
	public Expression getExpression2(){
		return this.expression2;
	}
	
	@Override
	public List<ColoredString> getColoredStrings(Formula formula){
		List<ColoredString> coloredStrings = new LinkedList<ColoredString>();
		
		if(this.expression1 instanceof BinaryExpression && !this.operator.getClass().equals(
				((BinaryExpression)this.expression1).getOperator().getClass())){
			coloredStrings.add(new ColoredString("(", Color.WHITE));
			coloredStrings.addAll(this.expression1.getColoredStrings(formula));
			coloredStrings.add(new ColoredString(")", Color.WHITE));
		}else
			coloredStrings.addAll(this.expression1.getColoredStrings(formula));
		
		coloredStrings.add(new ColoredString(" " + this.operator.toString() + " ", Color.WHITE));
		
		if(this.expression2 instanceof BinaryExpression && !this.operator.getClass().equals(
				((BinaryExpression)this.expression2).getOperator().getClass())){
			coloredStrings.add(new ColoredString("(", Color.WHITE));
			coloredStrings.addAll(this.expression2.getColoredStrings(formula));
			coloredStrings.add(new ColoredString(")", Color.WHITE));
		}else
			coloredStrings.addAll(this.expression2.getColoredStrings(formula));
		
		return coloredStrings;
	}
	
	@Override
	public String toString(){
		return ((this.expression1 instanceof BinaryExpression) && 
				!this.operator.getClass().equals(((BinaryExpression)this.expression1).getOperator().getClass()) ? 
				"(" + this.expression1.toString() + ")" : this.expression1.toString()) + 
				" " + this.operator.toString() + " " + 
				((this.expression2 instanceof BinaryExpression) && 
						!this.operator.getClass().equals(((BinaryExpression)this.expression2).getOperator().getClass()) ? 
						"(" + this.expression2.toString() + ")" : this.expression2.toString());
	}
}