package util;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.FilteredImageSource;
import java.awt.image.ImageFilter;
import java.awt.image.ImageProducer;
import java.awt.image.RGBImageFilter;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import util.Constants.BlockType;
import util.Constants.Direction;

public class ImageLoader{
	private ImageLoader(){}
	
	public static Image dummyImage;
	public static ImageIcon dummyImageIcon;
	public static final Map<BlockType, Image> itemMapImages = new HashMap<BlockType, Image>();
	public static final Map<BlockType, Image> itemMapImagesSmall = new HashMap<BlockType, Image>();

	public static final Map<Direction, List<Image>> marioSmallRunImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioSmallJumpImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioSmallRunGrabImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioSmallJumpGrabImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioSmallSpinJumpImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioBigRunImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioBigJumpImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioBigRunGrabImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioBigJumpGrabImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioBigSpinJumpImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioCrouchImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> marioCrouchGrabImages = new HashMap<Direction, List<Image>>();
	public static final Map<Direction, List<Image>> koopaRunImages = new HashMap<Direction, List<Image>>();
	
	public static final List<Image> marioBigClimbImages = new LinkedList<Image>();
	public static final List<Image> marioSmallClimbImages = new LinkedList<Image>();
	public static final List<Image> koopaShellImages = new LinkedList<Image>();
	
	public static final List<Image> lavaImages = new LinkedList<Image>();
	public static final List<Image> coinImages = new LinkedList<Image>();
	public static final List<Image> questionBlockImages = new LinkedList<Image>();
	public static final List<Image> rotateBlockImages = new LinkedList<Image>();
	public static final List<Image> background2Images = new LinkedList<Image>();
	public static final List<Image> teleportImages = new LinkedList<Image>();
	
	public static Image marioSmallImageSmall; //used in minimap
	public static Image marioBigImageSmall; //used in minimap
	public static Image mushroomImage;
	public static Image finishFrontImage;
	public static Image finishBackImage;
	public static Image finishFrontImageSmall;
	public static Image finishBackImageSmall;
	public static Image finishBarImage;
	public static Image trampolineImage;
	public static Image fireBallImage;
	public static Image stoneChainImage;
	public static Image stoneBallImage;
	public static Image background1;
	
	public static Image arrowLeft;
	public static Image arrowRight;
	public static Image arrowUp;
	public static Image arrowDown;
	
	public static Image cheatIconInvincibilty;
	public static Image cheatIconMultiJump;
	public static Image cheatIconNoCollision;
	
	public static ImageIcon languageDEIcon;
	public static ImageIcon languageENIcon;
	
	public static Color transparencyColor = Color.MAGENTA;
	
	public static void initImages(){
		//load dummy image
		try{
			dummyImage = ImageIO.read(ImageLoader.class.getResource("/res/dummy.png")).getScaledInstance(
					Constants.BLOCK_SIZE.width, Constants.BLOCK_SIZE.height, Image.SCALE_SMOOTH);
			dummyImageIcon = new ImageIcon(dummyImage);
		}catch(Exception e){
			e.printStackTrace();
		}

		marioSmallImageSmall = loadImage("mario_small_walk_0_right", "", 0, Constants.BLOCK_SIZE_MINIMAP.width);
		marioBigImageSmall = loadImage("mario_big_walk_0_right", "", 0, Constants.BLOCK_SIZE_MINIMAP.width);
		mushroomImage = loadImage("mushroom", "", Constants.MARIO_SIZE_OFFSET, Constants.BLOCK_SIZE.width);
		finishFrontImage = loadImage("finish_front", "", 0, Constants.BLOCK_SIZE.width);
		finishBackImage = loadImage("finish_back", "", 0, Constants.BLOCK_SIZE.width);
		finishFrontImageSmall = loadImage("finish_front", "", 0, Constants.BLOCK_SIZE_MINIMAP.width);
		finishBackImageSmall = loadImage("finish_back", "", 0, Constants.BLOCK_SIZE_MINIMAP.width);
		finishBarImage = loadImage("finish_bar", "", 0, (int)(Constants.BLOCK_SIZE.width*25f/16f));
		trampolineImage = loadImage("TRAMPOLINE_FIXED", "", 0, (int)(Constants.BLOCK_SIZE.width*7f/8f));
		fireBallImage = loadImage("fire_ball", "", 0, Constants.FIREBALL_SIZE.width);
		stoneChainImage = loadImage("stone_chain", "", 0, Constants.STONECHAIN_SIZE.width);
		stoneBallImage = loadImage("stone_ball", "", 0, Constants.STONEBALL_SIZE.width);
		background1 = loadImage("background1", "", 0, Constants.BLOCK_SIZE.width * 45);
		arrowLeft = loadImage("ARROW", "_LEFT", 0, Constants.BLOCK_SIZE.width*2);
		arrowRight = loadImage("ARROW", "_RIGHT", 0, Constants.BLOCK_SIZE.width*2);
		arrowUp = loadImage("ARROW", "_UP", 0, Constants.BLOCK_SIZE.width*2);
		arrowDown = loadImage("ARROW", "_DOWN", 0, Constants.BLOCK_SIZE.width*2);
		cheatIconInvincibilty = loadImage("cheat_invincibility_1", "", 0, Constants.BLOCK_SIZE.width);
		cheatIconMultiJump = loadImage("cheat_multi_jump_1", "", 0, Constants.BLOCK_SIZE.width);
		cheatIconNoCollision = loadImage("cheat_no_collision", "", 0, Constants.BLOCK_SIZE.width);
		languageDEIcon = new ImageIcon(loadImage("DE_icon", "", 0, 20));
		languageENIcon = new ImageIcon(loadImage("EN_icon", "", 0, 20));
		
		itemMapImagesSmall.put(BlockType.ROTATE_BLOCK, 
				loadImage("rotate_block_1", "", 0, Constants.BLOCK_SIZE_MINIMAP.width));
		
		marioSmallRunImages.put(Direction.EAST, new LinkedList<Image>());
		marioSmallRunImages.put(Direction.WEST, new LinkedList<Image>());
		marioSmallJumpImages.put(Direction.EAST, new LinkedList<Image>());
		marioSmallJumpImages.put(Direction.WEST, new LinkedList<Image>());
		marioSmallRunGrabImages.put(Direction.EAST, new LinkedList<Image>());
		marioSmallRunGrabImages.put(Direction.WEST, new LinkedList<Image>());
		marioSmallJumpGrabImages.put(Direction.EAST, new LinkedList<Image>());
		marioSmallJumpGrabImages.put(Direction.WEST, new LinkedList<Image>());
		marioSmallSpinJumpImages.put(Direction.EAST, new LinkedList<Image>());
		marioSmallSpinJumpImages.put(Direction.WEST, new LinkedList<Image>());
		marioBigRunImages.put(Direction.EAST, new LinkedList<Image>());
		marioBigRunImages.put(Direction.WEST, new LinkedList<Image>());
		marioBigJumpImages.put(Direction.EAST, new LinkedList<Image>());
		marioBigJumpImages.put(Direction.WEST, new LinkedList<Image>());
		marioBigRunGrabImages.put(Direction.EAST, new LinkedList<Image>());
		marioBigRunGrabImages.put(Direction.WEST, new LinkedList<Image>());
		marioBigJumpGrabImages.put(Direction.EAST, new LinkedList<Image>());
		marioBigJumpGrabImages.put(Direction.WEST, new LinkedList<Image>());
		marioBigSpinJumpImages.put(Direction.EAST, new LinkedList<Image>());
		marioBigSpinJumpImages.put(Direction.WEST, new LinkedList<Image>());
		marioCrouchImages.put(Direction.EAST, new LinkedList<Image>());
		marioCrouchImages.put(Direction.WEST, new LinkedList<Image>());
		marioCrouchGrabImages.put(Direction.EAST, new LinkedList<Image>());
		marioCrouchGrabImages.put(Direction.WEST, new LinkedList<Image>());
		koopaRunImages.put(Direction.EAST, new LinkedList<Image>());
		koopaRunImages.put(Direction.WEST, new LinkedList<Image>());
		
		List<String> imageNames = new LinkedList<String>();
		int marioWidth = Constants.BLOCK_SIZE.width-1*Constants.MARIO_SIZE_OFFSET;
		int koopaWidth = Constants.BLOCK_SIZE.width-1*Constants.KOOPA_SIZE_OFFSET;
		
		//load small Mario run images
		imageNames.clear();
		imageNames.add("mario_small_walk_0");
		imageNames.add("mario_small_walk_1");
		loadImages(marioSmallRunImages.get(Direction.EAST), imageNames, "_right", marioWidth);
		loadImages(marioSmallRunImages.get(Direction.WEST), imageNames, "_left", marioWidth);
		
		//load small Mario jump images
		imageNames.clear();
		imageNames.add("mario_small_jump_0");
		loadImages(marioSmallJumpImages.get(Direction.EAST), imageNames, "_right", marioWidth);
		loadImages(marioSmallJumpImages.get(Direction.WEST), imageNames, "_left", marioWidth);
		
		//load small Mario run grab images
		imageNames.clear();
		imageNames.add("mario_small_walk_grab_0");
		imageNames.add("mario_small_walk_grab_1");
		loadImages(marioSmallRunGrabImages.get(Direction.EAST), imageNames, "_right", marioWidth);
		loadImages(marioSmallRunGrabImages.get(Direction.WEST), imageNames, "_left", marioWidth);
		
		//load small Mario jump grab images
		imageNames.clear();
		imageNames.add("mario_small_walk_grab_1");
		loadImages(marioSmallJumpGrabImages.get(Direction.EAST), imageNames, "_right", marioWidth);
		loadImages(marioSmallJumpGrabImages.get(Direction.WEST), imageNames, "_left", marioWidth);
		
		//load small Mario spin jump images
		imageNames.clear();
		imageNames.add("mario_small_walk_0_right");
		imageNames.add("mario_small_back");
		imageNames.add("mario_small_walk_0_left");
		imageNames.add("mario_small_front");
		loadImages(marioSmallSpinJumpImages.get(Direction.EAST), imageNames, "", marioWidth);
		imageNames.clear();
		imageNames.add("mario_small_walk_0_left");
		imageNames.add("mario_small_front");
		imageNames.add("mario_small_walk_0_right");
		imageNames.add("mario_small_back");
		loadImages(marioSmallSpinJumpImages.get(Direction.WEST), imageNames, "", marioWidth);
		
		//load big Mario run images
		imageNames.clear();
		imageNames.add("mario_big_walk_0");
		imageNames.add("mario_big_walk_1");
		loadImages(marioBigRunImages.get(Direction.EAST), imageNames, "_right", marioWidth);
		loadImages(marioBigRunImages.get(Direction.WEST), imageNames, "_left", marioWidth);
		
		//load big Mario jump images
		imageNames.clear();
		imageNames.add("mario_big_jump_0");
		loadImages(marioBigJumpImages.get(Direction.EAST), imageNames, "_right", marioWidth);
		loadImages(marioBigJumpImages.get(Direction.WEST), imageNames, "_left", marioWidth);
		
		//load big Mario run grab images
		imageNames.clear();
		imageNames.add("mario_big_walk_grab_0");
		imageNames.add("mario_big_walk_grab_1");
		loadImages(marioBigRunGrabImages.get(Direction.EAST), imageNames, "_right", marioWidth);
		loadImages(marioBigRunGrabImages.get(Direction.WEST), imageNames, "_left", marioWidth);
		
		//load big Mario jump grab images
		imageNames.clear();
		imageNames.add("mario_big_walk_grab_1");
		loadImages(marioBigJumpGrabImages.get(Direction.EAST), imageNames, "_right", marioWidth);
		loadImages(marioBigJumpGrabImages.get(Direction.WEST), imageNames, "_left", marioWidth);
		
		//load big Mario spin jump images
		imageNames.clear();
		imageNames.add("mario_big_walk_0_right");
		imageNames.add("mario_big_back");
		imageNames.add("mario_big_walk_0_left");
		imageNames.add("mario_big_front");
		loadImages(marioBigSpinJumpImages.get(Direction.EAST), imageNames, "", marioWidth);
		imageNames.clear();
		imageNames.add("mario_big_walk_0_left");
		imageNames.add("mario_big_front");
		imageNames.add("mario_big_walk_0_right");
		imageNames.add("mario_big_back");
		loadImages(marioBigSpinJumpImages.get(Direction.WEST), imageNames, "", marioWidth);
		
		//load Mario crouch images
		imageNames.clear();
		imageNames.add("mario_crouch");
		loadImages(marioCrouchImages.get(Direction.EAST), imageNames, "_right", marioWidth);
		loadImages(marioCrouchImages.get(Direction.WEST), imageNames, "_left", marioWidth);
		
		//load Mario crouch images
		imageNames.clear();
		imageNames.add("mario_crouch_grab");
		loadImages(marioCrouchGrabImages.get(Direction.EAST), imageNames, "_right", marioWidth);
		loadImages(marioCrouchGrabImages.get(Direction.WEST), imageNames, "_left", marioWidth);
		
		//load Mario climb images
		imageNames.clear();
		imageNames.add("mario_big_climb_0");
		imageNames.add("mario_big_climb_1");
		loadImages(marioBigClimbImages, imageNames, "", marioWidth);
		imageNames.clear();
		imageNames.add("mario_small_climb_0");
		imageNames.add("mario_small_climb_1");
		loadImages(marioSmallClimbImages, imageNames, "", marioWidth);
		
		//load Koopa images
		imageNames.clear();
		imageNames.add("koopa_walk_0");
		imageNames.add("koopa_walk_1");
		loadImages(koopaRunImages.get(Direction.EAST), imageNames, "_right", koopaWidth);
		loadImages(koopaRunImages.get(Direction.WEST), imageNames, "_left", koopaWidth);
				
		//load Koopa shell images
		imageNames.clear();
		imageNames.add("koopa_shell_0");
		imageNames.add("koopa_shell_1");
		imageNames.add("koopa_shell_2");
		imageNames.add("koopa_shell_3");
		loadImages(koopaShellImages, imageNames, "", koopaWidth);
		
		//load lava images
		imageNames.clear();
		imageNames.add("lava_1");
		imageNames.add("lava_2");
		loadImages(lavaImages, imageNames, "");
		
		//load coin images
		imageNames.clear();
		imageNames.add("coin_1");
		imageNames.add("coin_2");
		imageNames.add("coin_3");
		imageNames.add("coin_4");
		loadImages(coinImages, imageNames, "");
		
		//load question block images
		imageNames.clear();
		imageNames.add("question_block_1");
		imageNames.add("question_block_2");
		imageNames.add("question_block_3");
		imageNames.add("question_block_4");
		loadImages(questionBlockImages, imageNames, "");
		
		//load rotate block images
		imageNames.clear();
		imageNames.add("rotate_block_1");
		imageNames.add("rotate_block_2");
		imageNames.add("rotate_block_3");
		imageNames.add("rotate_block_2");
		loadImages(rotateBlockImages, imageNames, "");
		
		//load background sky images
		imageNames.clear();
		imageNames.add("background2_1");
		imageNames.add("background2_2");
		imageNames.add("background2_3");
		loadImages(background2Images, imageNames, "", Constants.BLOCK_SIZE.width * 40);
		
		//load teleport block images
		imageNames.clear();
		imageNames.add("teleport_1");
		imageNames.add("teleport_2");
		imageNames.add("teleport_3");
		imageNames.add("teleport_4");
		imageNames.add("teleport_5");
		loadImages(teleportImages, imageNames, "");
		
		//load remaining images
		List<BlockType> primitiveBlockTypes = new LinkedList<BlockType>();
		primitiveBlockTypes.add(BlockType.WALL);
		primitiveBlockTypes.add(BlockType.USED_BLOCK);
		primitiveBlockTypes.add(BlockType.VINE);
		
		URL imageFile;
		Image itemMapImage;
		Image itemMapImageSmall;
		for(BlockType blockType : primitiveBlockTypes){
			if(Constants.typeVisibleMapping.get(blockType)){
				try{
					imageFile = ImageLoader.class.getResource("/res/" + blockType.toString() + ".png");
					itemMapImage = makeColorTransparent(ImageIO.read(imageFile), transparencyColor).getScaledInstance(
							Constants.BLOCK_SIZE.width, Constants.BLOCK_SIZE.height, Image.SCALE_SMOOTH);
					itemMapImageSmall = makeColorTransparent(ImageIO.read(imageFile), transparencyColor).getScaledInstance(
							Constants.BLOCK_SIZE_MINIMAP.width, Constants.BLOCK_SIZE_MINIMAP.height, Image.SCALE_SMOOTH);
				}catch(Exception e){
					itemMapImage = dummyImage;
					itemMapImageSmall = dummyImage;
					
					e.printStackTrace();
				}
				
				itemMapImages.put(blockType, itemMapImage);
				itemMapImagesSmall.put(blockType, itemMapImageSmall);
			}
		}
	}
	
	private static void loadImages(List<Image> images, List<String> imageNames, String suffix){
		loadImages(images, imageNames, suffix, Constants.BLOCK_SIZE.width);
	}
	private static void loadImages(List<Image> images, List<String> imageNames, String suffix, int width){
		for(String imageName : imageNames)
			images.add(loadImage(imageName, suffix, 0, width));
	}
	public static Image loadImage(String imageName, String suffix, int sizeOffset, int scaledWidth){
		try{
			Image image = makeColorTransparent(
					ImageIO.read(ImageLoader.class.getResource("/res/" + imageName + suffix + ".png")), transparencyColor);
			return image.getScaledInstance(scaledWidth - 2*sizeOffset, 
							(int)(((float)(scaledWidth - 2*sizeOffset)/image.getWidth(null)) * image.getHeight(null)), 
							Image.SCALE_SMOOTH);
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Problems while loading image '" + imageName + suffix + ".png'.");
		}
		
		return dummyImage;
	}
	
	private static Image makeColorTransparent(BufferedImage im, final Color color){
		/* Code taken from: 
		 * http://stackoverflow.com/questions/665406/how-to-make-a-color-transparent-in-a-bufferedimage-and-save-as-png */
		
		ImageFilter imageFilter = new RGBImageFilter(){
			//make alpha bits transparent
			public int transparencyColor = color.getRGB() | 0xFF000000;
			
			public final int filterRGB(int x, int y, int rgb){
				if((rgb | 0xFF000000) == transparencyColor){ //
					return rgb & 0x00FFFFFF;
				}else{ //do nothing
					return rgb;
				}
			}
		};
		
		ImageProducer imageProducer = new FilteredImageSource(im.getSource(), imageFilter);
		return Toolkit.getDefaultToolkit().createImage(imageProducer);
    }
	
	public static Image getBlockImage(BlockType blockType){
		Image image = itemMapImages.get(blockType);
		
		return image != null ? image : dummyImage;
	}
	public static Image getBlockImageSmall(BlockType blockType){
		Image image = itemMapImagesSmall.get(blockType);
		
		return image; //return null, if no image found; treat as empty block
	}
	
	public static List<Image> makeImageList(Image image){
		List<Image> images = new LinkedList<Image>();
		images.add(image);
		return images;
	}
}