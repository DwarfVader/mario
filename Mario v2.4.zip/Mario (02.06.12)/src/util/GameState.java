package util;

public enum GameState{
	RUNNING,
	PAUSED,
	WON,
	LOST
}