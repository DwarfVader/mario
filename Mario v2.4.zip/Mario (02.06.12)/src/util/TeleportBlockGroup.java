package util;

import java.util.List;

import model.blocks.TeleportBlock;

public class TeleportBlockGroup{
	private List<TeleportBlock> blocks;
	private String label;
	
	public TeleportBlockGroup(List<TeleportBlock> blocks, String label){
		this.blocks = blocks;
		this.label = label;
	}
	
	public List<TeleportBlock> getBlocks(){
		return this.blocks;
	}
	public String getLabel(){
		return this.label;
	}
}