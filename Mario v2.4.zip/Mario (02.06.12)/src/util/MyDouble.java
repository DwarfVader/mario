package util;

public class MyDouble{
	public double value;
	
	public MyDouble(MyDouble other){
		this(other.value);
	}
	public MyDouble(double value){
		this.value = value;
	}
	
	public void setValue(double value){
		this.value = value;
	}
}