package util;

public enum GameMode{
	NORMAL, 
	MODERATE,
	CHALLENGING
}