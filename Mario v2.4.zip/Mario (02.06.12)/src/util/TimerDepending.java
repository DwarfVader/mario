package util;

public interface TimerDepending{
	public void incrementTime(int timerInterval);
}