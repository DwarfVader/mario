package util;

import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import model.MapTemplate;
import util.Constants.BlockType;

public class MapLoader{
	private MapLoader(){}
	
	private static String path = "/maps/";
	private static boolean ok = false;
	
	private static Map<Character, BlockType> charMapping = new HashMap<Character, BlockType>();
	public static Map<String, MapTemplate> mapMapping = new HashMap<String, MapTemplate>();
	
	public static void init(){
		if(!loadMapsFromFiles()){
			System.out.println("MapLoader: Probleme beim Laden der Karten!");
			return;
		}
		mapMapping.get("crossover2").mirrorHorizontally();
		mapMapping.get("finish").mirrorHorizontally();
		mapMapping.get("finish_pspace").mirrorHorizontally();
		ok = true;
	}
	
	public static boolean isOk(){
		return ok;
	}
	
	public static void initCharMapping(){
		if(charMapping.isEmpty()){ //avoid multiple initializations
			charMapping.put('e', BlockType.ENTRANCE);
			charMapping.put('.', BlockType.EMPTY);
			charMapping.put('w', BlockType.WALL);
			charMapping.put('k', BlockType.KOOPA);
			charMapping.put('m', BlockType.MUSHROOM_BLOCK);
			charMapping.put('c', BlockType.COIN_BLOCK);
			charMapping.put('f', BlockType.FINISH_GATE);
			charMapping.put('a', BlockType.COIN);
			charMapping.put('l', BlockType.LABEL);
			charMapping.put('j', BlockType.LABEL_LITERAL);
			charMapping.put('p', BlockType.VARIABLE_ASSIGNMENT_POSITIVE);
			charMapping.put('n', BlockType.VARIABLE_ASSIGNMENT_NEGATIVE);
			charMapping.put('+', BlockType.VARIABLE_ASSIGNMENT_POSITIVE_LABEL);
			charMapping.put('-', BlockType.VARIABLE_ASSIGNMENT_NEGATIVE_LABEL);
			charMapping.put('_', BlockType.ARROW);
			
			charMapping.put('>', BlockType.TELEPORT_START_1);
			charMapping.put('<', BlockType.TELEPORT_DESTINATION_1);
			charMapping.put(')', BlockType.TELEPORT_START_2);
			charMapping.put('(', BlockType.TELEPORT_DESTINATION_2);
			charMapping.put(']', BlockType.TELEPORT_START_3);
			charMapping.put('[', BlockType.TELEPORT_DESTINATION_3);
			
			charMapping.put('x', BlockType.VINE);
			charMapping.put('y', BlockType.FIREBALL);
			charMapping.put('i', BlockType.STONE);
			charMapping.put('r', BlockType.ROTATE_BLOCK);
			charMapping.put('t', BlockType.TRAMPOLINE);
			charMapping.put('d', BlockType.TRAMPOLINE_DESTINATION);
			
			charMapping.put('0', BlockType.CROSSOVER_UP_LEFT_MAP);
			charMapping.put('1', BlockType.CROSSOVER_DOWN_LEFT_MAP);
			charMapping.put('2', BlockType.CROSSOVER_UP_RIGHT_MAP);
			charMapping.put('3', BlockType.CROSSOVER_DOWN_RIGHT_MAP);
			charMapping.put('4', BlockType.DOOR_MAP);
		}
	}
	
	public static boolean loadMapsFromFiles(){
		if(charMapping.isEmpty())
			initCharMapping();
		
		//if there are problems, false will be returned
		return loadMapFromFile(path + "start.map") && loadMapFromFile(path + "finish.map") && 
				loadMapFromFile(path + "variable.map") && loadMapFromFile(path + "clause_entrance.part") && 
				loadMapFromFile(path + "crossover1.map") && loadMapFromFile(path + "crossover2.map") && 
				loadMapFromFile(path + "jump_down.map") && 
				loadMapFromFile(path + "start_pspace.map") && loadMapFromFile(path + "finish_pspace.map") && 
				loadMapFromFile(path + "crossover_up.map") && loadMapFromFile(path + "crossover_down.map") && 
				loadMapFromFile(path + "door.map") && loadMapFromFile(path + "ex_quantifier_control.part") && 
				loadMapFromFile(path + "ex_quantifier.part") && loadMapFromFile(path + "un_quantifier_control.part") && 
				loadMapFromFile(path + "un_quantifier.part") && loadMapFromFile(path + "generalized_door.map") && 
				loadMapFromFile(path + "path1.part") && loadMapFromFile(path + "path2.part") && 
				loadMapFromFile(path + "path3.part") && loadMapFromFile(path + "path4.part") && 
				loadMapFromFile(path + "path5.part") && loadMapFromFile(path + "path6.part") && 
				loadMapFromFile(path + "path7.part") && loadMapFromFile(path + "path8.part") && 
				loadMapFromFile(path + "path9.part") && loadMapFromFile(path + "path10.part") && 
				loadMapFromFile(path + "path11.part") && loadMapFromFile(path + "path12.part") && 
				loadMapFromFile(path + "path13.part") && loadMapFromFile(path + "path14.part") && 
				loadMapFromFile(path + "path15.part") && loadMapFromFile(path + "path17.part") && 
				loadMapFromFile(path + "path19.part") && loadMapFromFile(path + "path20.part") && 
				loadMapFromFile(path + "path21.part") && loadMapFromFile(path + "path22.part") && 
				loadMapFromFile(path + "path23.part") && loadMapFromFile(path + "path25.part") && 
				loadMapFromFile(path + "path27.part") && loadMapFromFile(path + "path28.part") && 
				loadMapFromFile(path + "path29.part") && loadMapFromFile(path + "path30.part") && 
				loadMapFromFile(path + "path31.part") && loadMapFromFile(path + "path34.part") && 
				loadMapFromFile(path + "path36.part") && loadMapFromFile(path + "path40.part") && 
				loadMapFromFile(path + "path49.part") && loadMapFromFile(path + "path57.part") && 
				loadMapFromFile(path + "path65.part") && loadMapFromFile(path + "path66.part") && 
				loadMapFromFile(path + "path72.part") && loadMapFromFile(path + "path75.part") && 
				loadMapFromFile(path + "path84.part") && loadMapFromFile(path + "path87.part") && 
				loadMapFromFile(path + "seppl.part") && loadMapFromFile(path + "easteregg.part");
	}
	
	private static boolean loadMapFromFile(String file){
		try{
			Dimension mapSize = new Dimension(-1, -1); //dummy
			String mapName = ""; //dummy
			BlockType types[][] = null;
			int currentMapLine = 0;
			
			BufferedReader inStream = new BufferedReader(new InputStreamReader(MapLoader.class.getResource(file).openStream()));
			
			String line, tokens[];
			while((line = inStream.readLine()) != null){
				if(line.isEmpty() || line.charAt(0) == '#') //ignore empty and comment lines
					continue;
				
				//read in size and initialize map
				//definition line of format ': width height name'
				if(line.charAt(0) == ':' && types == null){ //only allow one initialization
					tokens = line.split(" "); //split will lead to [:, width, height, name]
					mapSize = new Dimension(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]));
					types = new BlockType [mapSize.width][mapSize.height];
					mapName = tokens[3];
					if(mapMapping.containsKey(mapName)){
						inStream.close();
						return true; //avoid duplicates
					}
					continue; //continue with next line; don't use the same line again in the next if-block
				}
				
				if(types != null){
					tokens = line.split(" ");
					
					for(int i = 0; i < mapSize.width; i++)
						types[i][currentMapLine] = charMapping.get(tokens[i].charAt(0)); //single-letter string
					
					currentMapLine++;
				}else
					System.out.println("Datei '" + file + "' ist fehlerhaft: Definition der Kartengr��e (mit ':') " +
							"muss als erste Anweisung erfolgen!");
			}
			
			mapMapping.put(mapName, new MapTemplate(types, mapSize));
			inStream.close();
		}catch(Exception e){
			e.printStackTrace();
			return false; //in case of exception -> problems in loading files
		}
		
		return true; //no exception thrown; fine
	}
}