package util;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.util.List;

import model.MapPart;
import util.Constants.Direction;

public interface Collidable{
	public List<Direction> collides(Collidable collidable, Point offset);
	public List<Direction> collides(Collidable collidable, Point offset, boolean ignorePassable);
	
	public MyPoint getLocation();
	
	public MyPoint getCollisionLocation();
	public MyPoint getOldCollisionLocation();
	public Dimension getCollisionSize();
	
	public Image getImage();
	
	public MapPart getCurMap();
}