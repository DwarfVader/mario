package util;

public class MyBoolean{
	public boolean value;
	
	public MyBoolean(MyBoolean other){
		this(other.value);
	}
	public MyBoolean(boolean value){
		this.value = value;
	}
	
	public void setValue(boolean value){
		this.value = value;
	}
}