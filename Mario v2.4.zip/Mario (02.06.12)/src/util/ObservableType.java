package util;

public enum ObservableType{
	GUI_DEFAULT,
	GAME_STATE,
	GAME_ERROR_STATE,
	FORMULA
}