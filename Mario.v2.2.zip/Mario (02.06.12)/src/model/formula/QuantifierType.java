package model.formula;

public enum QuantifierType{
	EXISTENTIAL,
	UNIVERSAL
}