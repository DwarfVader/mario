package model.formula;

import util.Constants;

public class AndOperator implements BinaryOperator{
	public AndOperator(){}
	
	@Override
	public String toString(){
		return Constants.AND + "";
	}
}