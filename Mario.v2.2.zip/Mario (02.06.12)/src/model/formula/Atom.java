package model.formula;

import java.awt.Color;
import java.util.LinkedList;
import java.util.List;

import util.ColoredString;

public class Atom implements Expression{
	private String name;
	
	public Atom(String name){
		this.name = name;
	}
	
	public String getName(){
		return this.name;
	}
	
	@Override
	public List<ColoredString> getColoredStrings(Formula formula){
		List<ColoredString> coloredStrings = new LinkedList<ColoredString>();
		
		Color color = null;
		switch(formula.getVariable(this.name).getSatisfied()){
		case TRUE:
			color = Color.GREEN;
			break;
		case FALSE:
			color = Color.RED;
			break;
		case UNDEFINED:
			color = Color.WHITE;
			break;
		}
		coloredStrings.add(new ColoredString(name, color));
		
		return coloredStrings;
	}
	
	@Override
	public String toString(){
		if(this.name.charAt(0) == '_')
			return this.name.substring(1);
		
		return this.name;
	}
}