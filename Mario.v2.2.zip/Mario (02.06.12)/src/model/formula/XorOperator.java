package model.formula;

import util.Constants;

public class XorOperator implements BinaryOperator{
	public XorOperator(){}
	
	@Override
	public String toString(){
		return Constants.XOR + "";
	}
}