package model.animation;

import util.MyInteger;

public class IntegerCondition implements Condition{
	private MyInteger value;
	private String operator;
	private int compareValue;
	
	public IntegerCondition(MyInteger value, String operator, int compareValue){
		this.value = value;
		this.operator = operator;
		this.compareValue = compareValue;
	}
	
	@Override
	public boolean getState(){
		if(this.operator.equals("<"))
			return this.value.value < this.compareValue;
		if(this.operator.equals(">"))
			return this.value.value > this.compareValue;
		if(this.operator.equals("!="))
			return this.value.value != this.compareValue;
		if(this.operator.equals("=="))
			return this.value.value == this.compareValue;
		
		return false; //nonsensical operator
	}
}