package model.animation;

import java.util.List;

import model.Flag;
import util.Constants.Direction;
import util.MyPoint;

public class FlagAnimationStep extends CollisionAnimationStep{
	private Flag flag;
	
	public FlagAnimationStep(Flag flag){
		super(Direction.SOUTH, 0, 150, true);
		
		this.flag = flag;
	}
	
	@Override
	public void checkFinishCondition(Object destinationValue){
		if(destinationValue instanceof List<?> && !((List<?>)destinationValue).isEmpty() && 
				((List<?>)destinationValue).get(0) instanceof Direction){
			for(Object collisionDirection : (List<?>)destinationValue)
				if(collisionDirection instanceof Direction && collisionDirection == this.desiredCollisionDirection)
					this.isDone = true;
		}
		
		if(!this.isDone) //not finished yet
			this.flag.fuckingStartToMove(new MyPoint(0, 150));
		else
			this.flag.fuckingStopMoving();
	}
}