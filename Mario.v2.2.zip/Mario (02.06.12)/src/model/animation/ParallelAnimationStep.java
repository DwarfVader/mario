package model.animation;


public class ParallelAnimationStep /*extends AnimationStep*/{
	/*private List<AnimationStep> animationSteps;
	
	public ParallelAnimationStep(){
		super(0, 0, false); //Dummy?
		
		this.animationSteps = new LinkedList<AnimationStep>();
	}
	
	public void update(Mario mario){
		for(AnimationStep animationStep : this.animationSteps)
			if(!animationStep.isDone()){
				if(animationStep instanceof FlagAnimationStep)
					
				else
					animationStep.updateVelocity(mario);	
			}
	}
	
	@Override
	public void checkFinishCondition(Object destinationValue){
		for(AnimationStep animationStep : this.animationSteps)
			if(!animationStep.isDone())
				return;
		
		this.isDone = true;
	}*/
}