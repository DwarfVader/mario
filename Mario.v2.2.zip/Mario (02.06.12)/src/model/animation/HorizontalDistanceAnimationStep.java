package model.animation;

import model.MapPart;
import model.Mario;
import util.Constants;
import util.MyPoint;

public class HorizontalDistanceAnimationStep extends AnimationStep{
	private int horizontalDistance;
	private MyPoint oldLocation;
	private MapPart oldMap;
	private boolean ignoreHorizontalCollision;
	
	public HorizontalDistanceAnimationStep(int horizontalDistance, MyPoint oldLocation, MapPart map, 
			float vx, float vy, boolean ignoreGravity, boolean ignoreHorizontalCollision){
		super(vx, vy, ignoreGravity);
		
		this.horizontalDistance = horizontalDistance;
		this.oldLocation = new MyPoint(oldLocation);
		this.oldMap = map;
		this.ignoreHorizontalCollision = ignoreHorizontalCollision;
	}
	
	@Override
	public void checkFinishCondition(Object destinationValue){
		if(destinationValue instanceof Mario){
			Mario mario = (Mario)destinationValue;
			double dX = mario.getLocation().x.value - this.oldLocation.x.value + 
					(mario.getCurMap().getIndex().x - this.oldMap.getIndex().x) * 
					Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
			if(Math.abs(dX) >= Math.abs(this.horizontalDistance) && Math.signum(dX) == Math.signum(this.horizontalDistance))
				this.isDone = true;
		}
	}
	
	@Override
	public boolean isIgnoreHorizontalCollision(){
		return this.ignoreHorizontalCollision;
	}
}