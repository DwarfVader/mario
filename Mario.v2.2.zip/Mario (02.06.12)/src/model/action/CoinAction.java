package model.action;

import model.Coin;
import model.Game;

public class CoinAction implements Action{
	private Game game;
	private Coin coin;
	
	public CoinAction(Game game, Coin coin){
		this.game = game;
		this.coin = coin;
	}
	
	@Override
	public void undo(){
		this.game.getCoins().add(new Coin(this.coin.getCurMap(), this.coin.getLocation()));
	}
	@Override
	public String toString(){
		return "coin action";
	}
	
	public Coin getCoin(){
		return this.coin;
	}
}