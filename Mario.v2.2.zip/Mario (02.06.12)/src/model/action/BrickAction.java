package model.action;

import model.MapPart;
import model.animation.SlideshowManager;
import model.blocks.BlockHolder;
import model.blocks.BrickBlock;
import model.formula.Clause;
import util.Constants.BlockType;

public class BrickAction implements Action{
	private MapPart map;
	private BlockHolder blockHolder;
	private Clause clause;
	
	public BrickAction(MapPart map, BlockHolder blockHolder, Clause clause){
		this.map = map;
		this.blockHolder = blockHolder;
		this.clause = clause;
	}
	
	@Override
	public void undo(){
		SlideshowManager.getInstance().removeSlideshow(this.blockHolder.getBlock().getMap(), 
				this.blockHolder.getBlock().getSlideshow());
		this.blockHolder.setBlock(new BrickBlock(this.map, BlockType.BRICK, clause));
		//won't need the next line; addSlideshow() is called by the constructor of Block
		//SlideshowManager.getInstance().addSlideshow(this.blockHolder.getBlock().getMap(), this.blockHolder.getBlock().getSlideshow());
	}
	@Override
	public String toString(){
		return "brick action";
	}
	
	public MapPart getGameMap(){
		return this.map;
	}
	public BlockHolder getBlockHolder(){
		return this.blockHolder;
	}
}