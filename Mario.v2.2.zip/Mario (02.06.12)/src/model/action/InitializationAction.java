package model.action;

import model.Game;
import model.MapPart;
import model.animation.SlideshowManager;
import model.blocks.Block;
import model.blocks.BlockHolder;
import util.Constants.BlockType;
import util.MyPoint;

public class InitializationAction extends EntranceAction{
	private BlockHolder mushroomBlockHolder;
	
	public InitializationAction(Game game, String label, MapPart mapPart, MyPoint location, BlockHolder mushroomBlockHolder){
		super(game, label, mapPart, location, 0, 0, false);
		this.mushroomBlockHolder = mushroomBlockHolder;
	}
	
	@Override
	public void undo(){
		this.game.resetCurrentMap(this.mapPart, this.location);
		this.game.resetTime(0);
		this.game.resetScore(0);
		this.game.getMario().setSuper(false);
		if(this.mushroomBlockHolder != null){
			SlideshowManager.getInstance().removeSlideshow(this.mushroomBlockHolder.getBlock().getMap(), 
					this.mushroomBlockHolder.getBlock().getSlideshow());
			this.mushroomBlockHolder.setBlock(new Block(this.mapPart, BlockType.MUSHROOM_BLOCK));
			//wont need the next line; addSlideshow() is called by the constructor of Block
			//SlideshowManager.getInstance().addSlideshow(this.blockHolder.getBlock().getMap(), this.blockHolder.getBlock().getSlideshow());
		}
		//this.game.updateSlideshows();
	}
	
	public Game getGame(){
		return this.game;
	}
	public MapPart getMapPart(){
		return this.mapPart;
	}
	public MyPoint getLocation(){
		return this.location;
	}
	public BlockHolder getMushroomBlockHolder(){
		return this.mushroomBlockHolder;
	}
}