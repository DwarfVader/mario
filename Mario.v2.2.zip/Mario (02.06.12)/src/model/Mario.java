package model;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import model.action.TrampolineAction;
import model.animation.AndCondition;
import model.animation.Animation;
import model.animation.BooleanCondition;
import model.animation.Condition;
import model.animation.DoubleCondition;
import model.animation.GameOverAnimationStep;
import model.animation.OrCondition;
import model.animation.Slideshow;
import model.animation.SlideshowManager;
import model.blocks.BlockHolder;
import util.Collidable;
import util.Constants;
import util.Constants.Direction;
import util.GameState;
import util.ImageLoader;
import util.Movable;
import util.MyBoolean;
import util.MyPoint;

public class Mario implements Movable{
	private MyPoint location; //Mario's location is based on his feet!
	private MyPoint oldLocation;
	private MyPoint velocity;
	private Stack<Direction> moveDirections;
	private Direction lastMoveDirection;
	private Direction oldLastMoveDirection;
	private boolean isDead;
	private boolean isSuper;
	private boolean isCrouching;
	private boolean isCrouchingDelayed;
	private MyBoolean hasFeetOnGround;
	private MyBoolean hasFeetOnTrampoline;
	private boolean isOnVine; //climbing vine
	private MyBoolean climbUp;
	private MyBoolean climbDown;
	private boolean jump;
	private boolean isClimbing;
	private boolean isJumping;
	private Animation animation;
	private int invincibleTimer; //in ms
	private Trampoline grabbedTrampoline;
	
	private Image image;
	private Map<Direction, Slideshow> runAnimationsSmall;
	private Map<Direction, Slideshow> runAnimationsBig;
	private Map<Direction, Slideshow> jumpAnimationsSmall;
	private Map<Direction, Slideshow> jumpAnimationsBig;
	private Map<Direction, Slideshow> crouchAnimation;
	private Slideshow climbAnimationBig;
	private Slideshow climbAnimationSmall;
	private List<Slideshow> animations;
	
	private Game game;
	private MapPart curMap;

	private boolean cheatInvincibility;
	private boolean cheatMultiJump;
	private boolean cheatNoCollision;
	
	public Mario(Game game){
		this.game = game;
		this.curMap = null;
		
		this.location = new MyPoint(0, 0); //Dummy?
		this.oldLocation = new MyPoint(0, 0);
		this.velocity = new MyPoint(0, 0);
		this.moveDirections = new Stack<Direction>();
		this.lastMoveDirection = Direction.EAST;
		this.oldLastMoveDirection = this.lastMoveDirection;

		this.cheatInvincibility = false;
		this.cheatMultiJump = false;
		this.cheatNoCollision = false;
		
		this.hasFeetOnGround = new MyBoolean(false);
		this.hasFeetOnTrampoline = new MyBoolean(false);
		this.climbUp = new MyBoolean(false);
		this.climbDown = new MyBoolean(false);
		
		setupSlideshows();
		reset();
	}
	
	public void reset(){
		this.isDead = false;
		this.isSuper = false;
		this.isCrouching = false;
		this.isCrouchingDelayed = false;
		this.isJumping = false;
		this.jump = false;
		this.climbUp.value = false;
		this.climbDown.value = false;
		this.isClimbing = false;
		this.invincibleTimer = 0;
		this.grabbedTrampoline = null;
		
		resetMovement();
	}
	public void resetMovement(){
		this.velocity.x.value = this.velocity.y.value = 0; //stop moving
		this.hasFeetOnGround.value = false; //avoids jumping
		this.hasFeetOnTrampoline.value = false;
		this.isOnVine = false;
	}
	public void clearMoveDirections(){
		this.moveDirections.clear();
	}
	
	public void setupSlideshows(){
		if(this.animations != null && !this.animations.isEmpty())
			SlideshowManager.getInstance().removeMovableSlideshows(this.animations);
		
		this.image = ImageLoader.marioSmallRunImages.get(Direction.EAST).get(0);
		Condition startCondition;
		//run images
		startCondition = new AndCondition(new DoubleCondition(this.velocity.x, "!=", 0), 
				new OrCondition(new BooleanCondition(this.hasFeetOnGround), new BooleanCondition(this.hasFeetOnTrampoline)));
		this.runAnimationsSmall = new HashMap<Direction, Slideshow>();
		this.runAnimationsSmall.put(Direction.EAST, new Slideshow(ImageLoader.marioSmallRunImages.get(Direction.EAST), 300, startCondition));
		this.runAnimationsSmall.put(Direction.WEST, new Slideshow(ImageLoader.marioSmallRunImages.get(Direction.WEST), 300, startCondition));
		this.runAnimationsBig = new HashMap<Direction, Slideshow>();
		this.runAnimationsBig.put(Direction.EAST, new Slideshow(ImageLoader.marioBigRunImages.get(Direction.EAST), 300, startCondition));
		this.runAnimationsBig.put(Direction.WEST, new Slideshow(ImageLoader.marioBigRunImages.get(Direction.WEST), 300, startCondition));
		//jump images
		this.jumpAnimationsSmall = new HashMap<Direction, Slideshow>();
		this.jumpAnimationsSmall.put(Direction.EAST, new Slideshow(ImageLoader.marioSmallJumpImages.get(Direction.EAST), 300, null));
		this.jumpAnimationsSmall.put(Direction.WEST, new Slideshow(ImageLoader.marioSmallJumpImages.get(Direction.WEST), 300, null));
		this.jumpAnimationsBig = new HashMap<Direction, Slideshow>();
		this.jumpAnimationsBig.put(Direction.EAST, new Slideshow(ImageLoader.marioBigJumpImages.get(Direction.EAST), 300, null));
		this.jumpAnimationsBig.put(Direction.WEST, new Slideshow(ImageLoader.marioBigJumpImages.get(Direction.WEST), 300, null));
		//crouch images
		this.crouchAnimation = new HashMap<Direction, Slideshow>();
		this.crouchAnimation.put(Direction.EAST, new Slideshow(ImageLoader.marioCrouchImages.get(Direction.EAST), 300, null));
		this.crouchAnimation.put(Direction.WEST, new Slideshow(ImageLoader.marioCrouchImages.get(Direction.WEST), 300, null));
		//climb images
		startCondition = new OrCondition(new BooleanCondition(this.climbUp), new BooleanCondition(this.climbDown));
		this.climbAnimationBig = new Slideshow(ImageLoader.marioBigClimbImages, 750, startCondition, false);
		this.climbAnimationSmall = new Slideshow(ImageLoader.marioSmallClimbImages, 750, startCondition, false);
		
		//add all animations to a separate list
		this.animations = new LinkedList<Slideshow>();
		this.animations.addAll(this.runAnimationsSmall.values());
		this.animations.addAll(this.runAnimationsBig.values());
		this.animations.addAll(this.jumpAnimationsSmall.values());
		this.animations.addAll(this.jumpAnimationsBig.values());
		this.animations.addAll(this.crouchAnimation.values());
		this.animations.add(this.climbAnimationBig);
		this.animations.add(this.climbAnimationSmall);
		
		SlideshowManager.getInstance().addMovableSlideshows(this.animations);
	}
	
	@Override
	public void updateImage(){
		incrementAnimationTimes(Constants.TIMER_INTERVAL);
		//setAnimationState(this.velocity.x != 0 && (this.hasFeetOnGround || this.hasFeetOnTrampoline)); //TODO: maybe not correct
		
		if(this.isCrouching)
			this.image = this.crouchAnimation.get(this.lastMoveDirection).getCurrentImage(); //crouching Mario
		else if(this.isJumping){
			if(this.isSuper)
				this.image = this.jumpAnimationsBig.get(this.lastMoveDirection).getCurrentImage();
			else //small Mario
				this.image = this.jumpAnimationsSmall.get(this.lastMoveDirection).getCurrentImage();
		}else if(this.isClimbing){
			if(this.isSuper)
				this.image = this.climbAnimationBig.getCurrentImage();
			else
				this.image = this.climbAnimationSmall.getCurrentImage();
		}else{ //normal moving or falling
			if(this.isSuper)
				this.image = this.runAnimationsBig.get(this.lastMoveDirection).getCurrentImage();
			else //small Mario
				this.image = this.runAnimationsSmall.get(this.lastMoveDirection).getCurrentImage();
		}
	}
	private void incrementAnimationTimes(int increment){
		for(Slideshow animation : this.animations)
			animation.incrementTime(increment);
	}
	/*private void setAnimationState(boolean running){
		for(Slideshow animation : this.animations)
			if(running)
				animation.start();
			else
				animation.stop();
	}*/
	
	public void setCurMap(MapPart map){
		this.curMap = map;
	}
	
	@Override
	public void move(){
		if(this.velocity.y.value != 0){
			this.hasFeetOnGround.value = false; //TODO: Correct?
			this.hasFeetOnTrampoline.value = false;
		}
		
		if(this.animation != null)
			moveAnimation();
		else
			moveNormal();
		
		checkMapChange();
		updateTrampolineLocation();
		
		//do timer dependent stuff
		updateImage();
		if(this.invincibleTimer > 0)
			this.invincibleTimer -= Constants.TIMER_INTERVAL;
		else
			this.invincibleTimer = 0;
	}
	private void moveNormal(){
		setOldLocation(this.location);
		this.oldLastMoveDirection = this.lastMoveDirection;
		
		this.jump();
		
		//move left or right
		if(this.moveDirections.size() > 0 && (!isCrouching || !(hasFeetOnGround.value || hasFeetOnTrampoline.value))){ //no acceleration while crouching
			//float oldVelocityX = this.velocity.x;
			this.velocity.x.value += (this.moveDirections.lastElement() == Direction.WEST ? -1 : 1) * 
					(Constants.MARIO_ACCELERATION / 1000 * Constants.TIMER_INTERVAL) / 1000 * Constants.TIMER_INTERVAL;
			/*//no acceleration while in air //TODO: Senseless?
			if(!hasFeetOnGround && Math.abs(this.velocity.x) > Math.abs(oldVelocityX))
				this.velocity.x = oldVelocityX;*/
			
			//limit speed
			if(Math.abs(this.velocity.x.value) > Constants.MAX_MARIO_MOVE_SPEED / 1000 * Constants.TIMER_INTERVAL)
				this.velocity.x.value = Math.signum(this.velocity.x.value) * Constants.MAX_MARIO_MOVE_SPEED / 1000 * Constants.TIMER_INTERVAL;
		}else{ //stop moving horizontally
			if(this.hasFeetOnGround.value || this.hasFeetOnTrampoline.value || this.isOnVine){ //no deceleration while in air
				double oldVelocityX = this.velocity.x.value;
				this.velocity.x.value -= (this.velocity.x.value < 0 ? -1 : 1) * 
						(Constants.MARIO_ACCELERATION / 1000 * Constants.TIMER_INTERVAL) / 1000 * Constants.TIMER_INTERVAL;
				if(Math.signum(oldVelocityX) != Math.signum(this.velocity.x.value)) //move direction changed -> stop movement
					this.velocity.x.value = 0;
			}
		}
		
		//no climbing with grabbed trampoline
		if(this.isOnVine && this.grabbedTrampoline == null && this.isClimbing){
			if(this.climbUp.value)
				this.velocity.y.value = -(Constants.MAX_FALLING_SPEED/5 / 1000 * Constants.TIMER_INTERVAL);
			else if(this.climbDown.value)
				this.velocity.y.value = Constants.MAX_FALLING_SPEED/5 / 1000 * Constants.TIMER_INTERVAL;
			else
				this.velocity.y.value = 0;
		}else{ //not touching vine or not climbing
			if(this.velocity.y.value < Constants.MAX_FALLING_SPEED / 1000 * Constants.TIMER_INTERVAL) //define a maximum falling speed
				this.velocity.y.value += (Constants.GRAVITY / 1000 * Constants.TIMER_INTERVAL) / 1000 * Constants.TIMER_INTERVAL; //increase falling speed until it reaches its limit
		}
		
		//change location by velocity values on every method call
		this.location.x.value += this.velocity.x.value;
		this.location.y.value += this.velocity.y.value;
	}
	private void moveAnimation(){
		if(this.animation != null && this.animation.getStep() != null && !this.animation.getStep().isDone()){
			setOldLocation(this.location);
			
			//apply gravity
			if(!this.animation.getStep().isIgnoreGravity())
				if(this.velocity.y.value < Constants.MAX_FALLING_SPEED / 1000 * Constants.TIMER_INTERVAL) //define a maximum falling speed
					this.velocity.y.value += (Constants.GRAVITY / 1000 * Constants.TIMER_INTERVAL) / 1000 * Constants.TIMER_INTERVAL; //increase falling speed until it reaches its limit
			
			//move
			this.location.x.value += this.velocity.x.value;
			this.location.y.value += this.velocity.y.value;
		}else if(this.animation != null && this.animation.getStep() == null){
			this.animation = null;
			//stop moving
			this.velocity.x.value = 0;
			this.velocity.y.value = 0;
			moveNormal();
		}
	}
	
	private void checkMapChange(){
		if(this.location.x.value >= Constants.MAP_PART_SIZE.width*Constants.BLOCK_SIZE.width)
			changeMap(this.curMap.getIndex().x + 1, this.curMap.getIndex().y);
		else if(this.location.x.value < 0)
			changeMap(this.curMap.getIndex().x - 1, this.curMap.getIndex().y);
		
		if(this.location.y.value >= Constants.MAP_PART_SIZE.height*Constants.BLOCK_SIZE.height)
			changeMap(this.curMap.getIndex().x, this.curMap.getIndex().y + 1);
		else if(this.location.y.value < 0)
			changeMap(this.curMap.getIndex().x, this.curMap.getIndex().y - 1);
	}
	private void changeMap(int i, int j){
		MapPart newMap = this.game.getMap(i, j);
		int maxWidth = Constants.MAP_PART_SIZE.width*Constants.BLOCK_SIZE.width;
		int maxHeight = Constants.MAP_PART_SIZE.height*Constants.BLOCK_SIZE.height;
		if(newMap != null){
			int dx = this.curMap.getIndex().x - i;
			int dy = this.curMap.getIndex().y - j;
			this.location.x.value += dx * maxWidth;
			this.location.y.value += dy * maxHeight;
			
			//need to change old location as well
			this.oldLocation.x.value += dx * maxWidth;
			this.oldLocation.y.value += dy * maxHeight;

			this.curMap = newMap;
			//System.out.println("Map changed to " + i + ", " + j);
		}
	}
	
	public void setIsClimbingUp(boolean isClimbingUp){
		this.climbUp.value = isClimbingUp;
		this.climbDown.value = false;
		if(isClimbingUp && this.isOnVine){
			this.isClimbing = true;
			this.isJumping = false;
		}
	}
	public void setIsClimbingDown(boolean isClimbingDown){
		this.climbDown.value = isClimbingDown;
		this.climbUp.value = false;
		if(isClimbingDown && this.isOnVine){
			this.isClimbing = true;
			this.isJumping = false;
		}
	}
	
	public void jump(){
		if(this.jump){
			if(this.cheatMultiJump /*&& !this.isClimbing*/){
				this.isJumping = true;
				this.hasFeetOnGround.value = false;
				this.hasFeetOnTrampoline.value = false;
				if(this.hasFeetOnTrampoline.value)
					this.velocity.y.value = -Constants.TRAMPOLINE_JUMP_SPEED / 1000 * Constants.TIMER_INTERVAL;
				else
					if(this.velocity.y.value > -Constants.MIN_JUMP_SPEED / 1000 * Constants.TIMER_INTERVAL)
						this.velocity.y.value = -Constants.MIN_JUMP_SPEED / 1000 * Constants.TIMER_INTERVAL - 
								Math.abs(this.velocity.x.value)/3.5f; //involve running speed in jump speed
			}else{
				if(this.animation == null && !this.isClimbing){
					//can only jump, if feet are on the ground; velocity check is not strong enough (head collision...)
					if(this.hasFeetOnGround.value && this.velocity.y.value == 0){ //TODO: A better solution... (velocity.y == 0?)
						this.isJumping = true;
						this.hasFeetOnGround.value = false;
						this.hasFeetOnTrampoline.value = false;
						//set Mario's vertical speed
						this.velocity.y.value = -Constants.MIN_JUMP_SPEED / 1000 * Constants.TIMER_INTERVAL - 
								Math.abs(this.velocity.x.value)/3.5f; //involve running speed in jump speed
					}else if(this.hasFeetOnTrampoline.value && this.velocity.y.value == 0){ //jump from trampoline
						this.isJumping = true;
						this.hasFeetOnGround.value = false;
						this.hasFeetOnTrampoline.value = false;
						this.velocity.y.value = -Constants.TRAMPOLINE_JUMP_SPEED / 1000 * Constants.TIMER_INTERVAL;
					}
				}
			}
			
			if(this.isOnVine && this.isClimbing){
				if(this.climbUp.value){
					this.velocity.y.value = -Constants.MIN_JUMP_SPEED / 1000 * Constants.TIMER_INTERVAL;
					this.isJumping = true;
				}
				//this.isOnVine = false;
				this.climbUp.value = false;
				this.climbDown.value = false;
				this.isClimbing = false;
			}
		}
	}
	
	public void grabDropTrampoline(){
		/* Without considering the location offset, wrong trampolines could fit the location constraint 
		 * be removed from their original locations and inserted next to the currently visited one which 
		 * looks like the visited trampoline has been cloned. */
		Point offset = new Point();
		
		if(this.grabbedTrampoline == null){ //grab trampoline
			for(Trampoline trampoline : this.game.getTrampolines()){
				offset.x = (trampoline.getCurMap().getIndex().x - this.curMap.getIndex().x) * 
						Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
				offset.y = (trampoline.getCurMap().getIndex().y - this.curMap.getIndex().y) * 
						Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height;
				
				//check if movable and fitting vertical location
				if(!trampoline.isFixed() && 
						Math.abs(trampoline.getCollisionLocation().getY()+offset.y - 
								getCollisionLocation().getY()) <= Constants.BLOCK_SIZE.height/2){
					//check horizontal direction and location
					if(this.lastMoveDirection == Direction.EAST && 
							//trampoline.getCollisionLocation().getX()+offset.x - this.location.x.value > Constants.BLOCK_SIZE.width/2f && 
							trampoline.getCollisionLocation().getX()+offset.x - this.location.x.value < Constants.BLOCK_SIZE.width/2f*3 || 
							this.lastMoveDirection == Direction.WEST && 
							//this.location.x.value - trampoline.getCollisionLocation().getX()+offset.x > Constants.BLOCK_SIZE.width/2f && 
							this.location.x.value - trampoline.getCollisionLocation().getX()+offset.x < Constants.BLOCK_SIZE.width/2f*3){
						this.grabbedTrampoline = trampoline;
						this.grabbedTrampoline.setGrabbed(true);
						
						this.game.getActionManager().addAction(new TrampolineAction(this.grabbedTrampoline));
						
						return;
					}
				}
			}
		}else{ //drop trampoline
			//this.grabbedTrampoline.setLocation(this.location.getX() + 
			//		(this.lastMoveDirection == Direction.EAST ? 1 : -1) * Constants.BLOCK_SIZE.width, 
			//		this.location.getY());
			this.grabbedTrampoline.setGrabbed(false);
			this.grabbedTrampoline = null;
		}
	}
	
	/**
	 * Checks, whether this player collides with a field, which is non-empty. 
	 * 
	 * @param oldLocation the players location before moving
	 * @param blockHolder the field to check against collision 
	 * @return a list containing all directions, in which Mario collides with blockHolder
	 */
	@Override
	public List<Direction> collides(Collidable collidable, Point offset){
		return collides(collidable, offset, false);
	}
	@Override
	public List<Direction> collides(Collidable collidable, Point offset, boolean ignorePassable){
		List<Direction> collisionDirections = new LinkedList<Direction>();
		
		if(this.cheatNoCollision){
			collisionDirections.add(Direction.NONE);
		}else{
			//collision with block holder containing a passable block
			if(!ignorePassable && collidable instanceof BlockHolder && 
					Constants.typePassableMapping.get(((BlockHolder)collidable).getBlock().getType()))
				collisionDirections.add(Direction.NONE);
			else{ //collision
				/* Fuck that integer cast within getCollisionLocation().getX()! Use the values directly!!! */
				collisionDirections.add(collides(new MyPoint(getOldCollisionLocation().x.value, getCollisionLocation().y.value), collidable, offset, Direction.VERTICAL));
				collisionDirections.add(collides(new MyPoint(getCollisionLocation().x.value, getOldCollisionLocation().y.value), collidable, offset, Direction.HORIZONTAL));
			}
		}
		
		return collisionDirections;
	}
	public Direction collides(MyPoint location, Collidable collidable, Point offset, Direction collisionDirection){
		//have to check for both vertical and horizontal collision
		if(collisionDirection == Direction.HORIZONTAL && collidesVertical(location, collidable, offset.y) != Direction.NONE)
			return collidesHorizontal(location, collidable, offset.x); //EAST or WEST or HORIZONTAL_CENTER or NONE
		else if(collisionDirection == Direction.VERTICAL && collidesHorizontal(location, collidable, offset.x) != Direction.NONE)
			return collidesVertical(location, collidable, offset.y); //NORTH or SOUTH or VERTICAL_CENTER or NONE
		
		return Direction.NONE;
	}
	private Direction collidesHorizontal(MyPoint location, Collidable collidable, int offsetX){
		/** Attention: Doesn't make sense without parallel vertical collision check! */
		if(location.x.value + getCollisionSize().width > collidable.getCollisionLocation().x.value + offsetX + 0 && 
				location.x.value < collidable.getCollisionLocation().x.value + offsetX + collidable.getCollisionSize().width - 0){
			//Mario's right side is in the left half of collidable
			if(location.x.value < collidable.getCollisionLocation().x.value + offsetX)
				return Direction.EAST;
			else if(location.x.value + getCollisionSize().width > collidable.getCollisionLocation().x.value + offsetX + 
					collidable.getCollisionSize().width)
				return Direction.WEST;
			else
				return Direction.HORIZONTAL_CENTER;
		}
		return Direction.NONE;
	}
	private Direction collidesVertical(MyPoint location, Collidable collidable, int offsetY){
		/** Attention: Doesn't make sense without parallel horizontal collision check! */
		/** Attention: Mario's location is based on his feet! */
		//there is a vertical collision
		if(location.y.value + getCollisionSize().height > collidable.getCollisionLocation().y.value + offsetY + 0 && 
				location.y.value < 
				//(isSuper && !isCrouching ? 2 : 1)*Constants.BLOCK_SIZE.height < 
				collidable.getCollisionLocation().y.value + offsetY + collidable.getCollisionSize().height){
			//???
			if(location.y.value < collidable.getCollisionLocation().y.value + offsetY)
				return Direction.SOUTH;
			else if(location.y.value + getCollisionSize().height > collidable.getCollisionLocation().y.value + offsetY + 
					collidable.getCollisionSize().height)
				return Direction.NORTH;
			else
				return Direction.VERTICAL_CENTER;
		}
		
		//no vertical collision
		return Direction.NONE;
	}
	
	public void eatMushroom(){
		this.isSuper = true;
	}
	
	public void hurt(){
		if(this.cheatInvincibility) //god mode active
			return;
		
		//When animation steps are left, ignore collisions!
		if(this.invincibleTimer <= 0 && (this.animation == null || this.animation.getStep() == null)){
			System.out.println("Ouch!");
			if(this.isSuper){
				this.isSuper = false;
				this.invincibleTimer = 3000;
			}else{
				die();
			}
		}
	}
	public void die(){
		//When animation steps are left, ignore collisions!
		if(!this.isDead && (this.animation == null || this.animation.getStep() == null)){
			this.isDead = true;
			this.moveDirections.clear(); //No dead man's walking!
			
			Animation animation = new Animation();
			animation.addAnimationStep(new GameOverAnimationStep(GameState.LOST));
			this.animation = animation;
		}
	}
	
	private void updateTrampolineLocation(){
		if(this.grabbedTrampoline != null){
			this.grabbedTrampoline.setLocation(this.location.getX() + 
					(this.lastMoveDirection == Direction.EAST ? 1 : -1) * this.grabbedTrampoline.getCollisionSize().width*1.2, 
					this.location.getY());
			this.grabbedTrampoline.setOldLocation(this.grabbedTrampoline.getLocation());
			this.grabbedTrampoline.setCurMap(this.curMap);
			this.grabbedTrampoline.checkMapChange();
		}
	}
	
	@Override
	public void setLocation(MyPoint location){
		setLocation(location.x.value, location.y.value);
	}
	@Override
	public void setLocation(double x, double y){
		this.location.x.value = x;
		this.location.y.value = y;
		
		//this.oldLocation.x = x;
		//this.oldLocation.y = y;
		//checkMapChange();
		
		updateTrampolineLocation();
	}
	@Override
	public void setLocationX(double x){
		setLocation(x, this.location.y.value);
		setOldLocation(x, this.oldLocation.y.value);
		//checkMapChange()
	}
	@Override
	public void setLocationY(double y){
		setLocation(this.location.x.value, y);
		setOldLocation(this.oldLocation.x.value, y);
		//checkMapChange();
	}
	@Override
	public void setOldLocation(MyPoint oldLocation){
		setOldLocation(oldLocation.x.value, oldLocation.y.value);
	}
	@Override
	public void setOldLocation(double x, double y){
		this.oldLocation.x.value = x;
		this.oldLocation.y.value = y;
	}
	@Override
	public void setVelocityX(double vx){
		this.velocity.x.value = vx;
	}
	@Override
	public void setVelocityY(double vy){
		this.velocity.y.value = vy;
	}
	public void setMoveDirection(Direction moveDirection){
		if(!this.moveDirections.contains(moveDirection)){
			this.moveDirections.add(moveDirection);
			this.lastMoveDirection = moveDirection;
		}
	}
	public void resetMoveDirection(Direction moveDirection){
		this.moveDirections.remove(moveDirection);
		if(!this.moveDirections.isEmpty()) //avoid moonwalking by setting last move direction after old move ended
			this.lastMoveDirection = this.moveDirections.lastElement();
	}
	public void setDead(boolean isDead){
		this.isDead = isDead;
	}
	public void setCrouching(boolean isCrouching){
		if(this.hasFeetOnGround.value)
			this.isCrouching = isCrouching;
		else
			this.isCrouchingDelayed = true;
	}
	/** Do NOT call this method outside of Action-subclasses. */
	public void setSuper(boolean isSuper){
		this.isSuper = isSuper;
	}
	@Override
	public void setFeetOnGround(){
		this.hasFeetOnGround.value = true;
		this.hasFeetOnTrampoline.value = false;
		this.isJumping = false;
		this.isClimbing = false;
		
		if(this.isCrouchingDelayed){
			this.isCrouching = false;
			this.isCrouchingDelayed = false;
		}
	}
	public void setFeetOnTrampoline(){
		this.hasFeetOnTrampoline.value = true;
		this.hasFeetOnGround.value = false;
		this.isJumping = false;
		this.isClimbing = false;
		
		if(this.isCrouchingDelayed){
			this.isCrouching = false;
			this.isCrouchingDelayed = false;
		}
	}
	public void setJump(boolean jump){
		this.jump = jump;
	}
	public void setIsOnVine(boolean isOnVine){
		this.isOnVine = isOnVine;
	}
	public void setAnimation(Animation animation){
		this.animation = animation;
	}
	public void toggleCheatInvincibility(){
		this.cheatInvincibility = !this.cheatInvincibility;
	}
	public void toggleCheatMultiJump(){
		this.cheatMultiJump = !this.cheatMultiJump;
	}
	public void toggleCheatNoCollision(){
		this.cheatNoCollision = !this.cheatNoCollision;
	}
	public void restoreOldMoveDirection(){
		this.lastMoveDirection = this.oldLastMoveDirection;
	}
	
	public Game getGame(){
		return this.game;
	}
	public MapPart getCurMap(){
		return this.curMap;
	}
	public MyPoint getLocation(){
		return this.location;
	}
	public MyPoint getOldLocation(){
		return this.oldLocation;
	}
	public MyPoint getVelocity(){
		return this.velocity;
	}
	public boolean isDead(){
		return this.isDead;
	}
	public boolean isSuper(){
		return this.isSuper;
	}
	public boolean isCrouching(){
		return this.isCrouching;
	}
	public boolean isOnVine(){
		return this.isOnVine;
	}
	public boolean hasFeetOnGround(){
		return this.hasFeetOnGround.value;
	}
	public boolean hasFeetOnTrampoline(){
		return this.hasFeetOnTrampoline.value;
	}
	public Animation getAnimation(){
		return this.animation;
	}
	public Trampoline getGrabbedTrampoline(){
		return this.grabbedTrampoline;
	}
	/*public boolean isCheatInvincibilityActive(){
		return this.cheatInvincibility;
	}
	public boolean isCheatMultiJumpActive(){
		return this.cheatMultiJump;
	}
	public boolean isCheatNoCollisionActive(){
		return this.cheatNoCollision;
	}
	public int getActiveCheatCount(){
		return (this.cheatInvincibility ? 1 : 0) + (this.cheatMultiJump ? 1 : 0) + (this.cheatNoCollision ? 1 : 0);
	}*/
	public List<Image> getActiveCheatImages(){
		List<Image> images = new LinkedList<Image>();
		
		//Strangest piece of code in a while, but why not... (Seppl, 22.12.2015 23:04)
		Object a = (this.cheatInvincibility ? images.add(ImageLoader.cheatIconInvincibilty) : null);
		a = (this.cheatMultiJump ? images.add(ImageLoader.cheatIconMultiJump) : null);
		a = (this.cheatNoCollision ? images.add(ImageLoader.cheatIconNoCollision) : null);
		
		return images;
	}
	
	@Override
	public MyPoint getCollisionLocation(){
		return new MyPoint(this.location.x.value, this.location.y.value - getCollisionSize().height);
	}
	@Override
	public MyPoint getOldCollisionLocation(){
		return new MyPoint(this.oldLocation.x.value, this.oldLocation.y.value - getCollisionSize().height);
	}
	@Override
	public Dimension getCollisionSize(){
		float width = Constants.BLOCK_SIZE.width-2*Constants.DEFAULT_MARIO_SIZE_OFFSET;
		
		if(this.isCrouching)
			return new Dimension((int)width, (int)(width*Constants.MARIO_CROUCH_SIZE_RATIO));
		else if(this.isSuper)
			return new Dimension((int)width, (int)(width*Constants.MARIO_BIG_SIZE_RATIO));
		//else if(this.grabbedTrampoline != null) //consider size of trampoline while carrying it
		//	return new Dimension((int)width + Constants.BLOCK_SIZE.width, (int)(width*Constants.MARIO_SMALL_SIZE_RATIO));
		else //small
			return new Dimension((int)width, (int)(width*Constants.MARIO_SMALL_SIZE_RATIO));
	}
	@Override
	public double getVelocityX(){
		return this.velocity.x.value;
	}
	@Override
	public double getVelocityY(){
		return this.velocity.y.value;
	}
	@Override
	public Direction getLastMoveDirection(){
		return this.lastMoveDirection;
	}
	public Direction getOldLastMoveDirection(){
		return this.oldLastMoveDirection;
	}
	@Override
	public Image getImage(){
		return this.image;
	}
}