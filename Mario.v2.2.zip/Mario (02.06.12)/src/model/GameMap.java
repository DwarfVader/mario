package model;
//
//import java.awt.Dimension;
//import java.util.LinkedList;
//import java.util.List;
//
//import model.action.BrickAction;
//import model.action.ClauseAction;
//import model.action.CoinAction;
//import model.action.CoinBlockAction;
//import model.action.EntranceAction;
//import model.action.FlagAction;
//import model.action.KoopaAction;
//import model.action.PowerBlockAction;
//import model.action.PowerCoinToBlockAction;
//import model.animation.Animation;
//import model.animation.AnimationStep;
//import model.animation.CollisionAnimationStep;
//import model.animation.FlagAnimationStep;
//import model.animation.GameOverAnimationStep;
//import model.animation.HorizontalDistanceAnimationStep;
//import model.animation.SlideshowManager;
//import model.blocks.Block;
//import model.blocks.BlockHolder;
//import model.blocks.LinkBlock;
//import model.blocks.VariableLinkBlock;
//import model.gadgets.ClauseGadget;
//import model.gadgets.ClauseGadget.ClauseGadgetStyle;
//import model.gadgets.Gadget;
//import model.gadgets.VariableGadget;
//import util.Collidable;
//import util.Constants;
//import util.Constants.BlockType;
//import util.Constants.Direction;
//import util.GameState;
//import util.ImageInfo;
//import util.Movable;
//import util.MyPoint;
//
public class GameMap{
//	private Game game;
//	private Gadget gadget;
//	private BlockHolder blockHolders[][];
//	private Dimension size;
//	private List<Koopa> koopas;
//	private List<Mushroom> mushrooms;
//	private List<Coin> coins;
//	
//	private Flag flag;
//	
//	private List<ImageInfo> background;
//	
//	public GameMap(Game game, Gadget gadget, GameMapTemplate mapTemplate){
//		this.game = game;
//		this.gadget = gadget;
//		this.size = new Dimension(mapTemplate.getSize().width+2, mapTemplate.getSize().height+2);
//		this.blockHolders = new BlockHolder [this.size.width][this.size.height];
//		this.koopas = new LinkedList<Koopa>();
//		this.mushrooms = new LinkedList<Mushroom>();
//		this.coins = new LinkedList<Coin>();
//		this.background = new LinkedList<ImageInfo>();
//		this.flag = null;
//		
//		initBlocks();
//		
//		for(int i = 0; i < mapTemplate.getSize().width; i++){
//			for(int j = 0; j < mapTemplate.getSize().height; j++)
//				replaceBlock(this.blockHolders[i+1][j+1], new Block(this, mapTemplate.getTypes()[i][j]));
//		}
//	}
//	
//	private void initBlocks(){
//		/*
//		 * Insert invisible blocks as outer border. The location has to be corrected by -1, since 
//		 * those blocks should not be noticeable by the player. 
//		 */
//		for(int i = 0; i < this.size.width; i++)
//			for(int j = 0; j < this.size.height; j++){
//				this.blockHolders[i][j] = new BlockHolder(
//						new MyPoint((i-1)*Constants.DEFAULT_BLOCK_SIZE.width, (j-1)*Constants.DEFAULT_BLOCK_SIZE.height));
//				
//				if(i == 0 || i == this.size.width-1 || j == 0 || j == this.size.height-1)
//					replaceBlock(this.blockHolders[i][j], new Block(this, BlockType.BORDER));
//			}
//	}
//	
//	/** Only call in Gadget-subclasses. */
//	public void placeCoins(){
//		for(int i = 0; i < this.size.width; i++)
//			for(int j = 0; j < this.size.height; j++)
//				if(this.blockHolders[i][j].getBlock().getType() == BlockType.COIN){
//					this.coins.add(new Coin(this, new MyPoint(this.blockHolders[i][j].getLocation())));
//				}
//	}
//	
//	public void mirrorHorizontally(){
//		for(int i = 0; i < this.size.width/2; i++)
//			for(int j = 0; j < this.size.height; j++){
//				this.blockHolders[i][j].interchangeLocation(this.blockHolders[this.size.width-1 - i][j]);
//				BlockHolder help = this.blockHolders[i][j];
//				this.blockHolders[i][j] = this.blockHolders[this.size.width-1 - i][j];
//				this.blockHolders[this.size.width-1 - i][j] = help;
//			}
//		
//		resetBlockHolderLocations();
//
//		if(this.flag != null)
//			insertFlag(); //reinsert flag
//	}
//	
//	public void move(){
//		List<Movable> movables = new LinkedList<Movable>();
//		//if(this.game.getCurrentMap() == this)
//		//	movables.add(this.game.getMario());
//		
//		//If animation steps are left, ONLY move Mario!
//		if(this.game.getMario().getAnimation() == null || this.game.getMario().getAnimation().getStep() == null){
//			movables.addAll(this.koopas);
//			movables.addAll(this.mushrooms);
//		}
//		
//		for(Movable movable : movables){
//			movable.move();
//			checkCollision(movable);
//		}
//		
//		if(this.flag != null)
//			this.flag.move();
//		
//		/* Scrolling is now performed, where it should always have been done, when drawing stuff! */
//	}
//	private void checkCollision(Movable movable){
//		MyPoint oldLocation = movable.getOldLocation();
//
//		List<Direction> collisionDirections;
//		BlockHolder curBlockHolder;
//		
//		//check for collision with Koopas and mushrooms; only check, if no animation steps are left for Mario
//		if(movable instanceof Mario && (this.game.getMario().getAnimation() == null || 
//				this.game.getMario().getAnimation().getStep() == null)){
//			//Koopas
//			for(Koopa koopa : this.koopas){
//				collisionDirections = movable.collides(oldLocation, koopa);
//				
//				//for the player's advantage isolate SOUTH-collision-check
//				if(collisionDirections.contains(Direction.SOUTH)){
//					movable.setLocationY(oldLocation.y);
//					movable.setVelocityY(-0.5f*Constants.MAX_MARIO_MOVE_SPEED / 1000 * Constants.TIMER_INTERVAL);
//					
//					if(!koopa.isStunned()){
//						koopa.stun();
//						//only add action on first contact, further actions will be ignored
//						//this.game.getActionManager().addAction(new KoopaAction(koopa, this, koopa.getLocation()));
//						this.game.addScore(Constants.KOOPA_STUN_SCORE);
//					}else{
//						if(koopa.getVelocityX() == 0){
//							koopa.kick(movable.getOldLocation().x > koopa.getOldLocation().x ? Direction.WEST : Direction.EAST);
//							
//							//this.game.addToKoopaMoveMapping(koopa, this); //XXX: Performance approach applied here!
//							
//						}else
//							koopa.setVelocityX(0);
//					}
//				}else{ //no SOUTH-collision
//					for(Direction direction : collisionDirections){
//						switch(direction){
//						case WEST:
//						case EAST:
//							if(!koopa.isStunned() || Math.abs(koopa.getVelocity().x) > 0){
//								((Mario)movable).hurt();
//								koopa.setVelocityX(-koopa.getVelocityX());
//								return; //maybe not necessary
//							}else{
//								koopa.kick(direction);
//								movable.setLocationX(oldLocation.x);
//								movable.setVelocityX(movable.getVelocityX()/4);
//							}
//							break;
//						default:
//							break;
//						}
//					}
//				}
//			}
//			
//			//mushrooms
//			for(Mushroom mushroom : new LinkedList<Mushroom>(this.mushrooms)){
//				collisionDirections = movable.collides(oldLocation, mushroom);
//				
//				for(Direction direction : collisionDirections)
//					if(direction != Direction.NONE){ //Mario touched mushroom
//						this.mushrooms.remove(mushroom);
//						((Mario)movable).eatMushroom();
//						this.game.addScore(Constants.MUSHROOM_EAT_SCORE);
//						break;
//					}
//			}
//			
//			//coins
//			for(Coin coin : new LinkedList<Coin>(this.coins)){
//				collisionDirections = movable.collides(oldLocation, coin);
//				
//				for(Direction direction : collisionDirections)
//					if(direction != Direction.NONE){ //touched a coin
//						this.coins.remove(coin);
//						this.game.addScore(Constants.COIN_SCORE);
//						//this.game.getActionManager().addAction(new CoinAction(this, coin));
//						break;
//					}
//			}
//		}
//		
//		//check, whether movable collides with any block
//		for(int i = 0; i < this.size.width; i++)
//			for(int j = 0; j < this.size.height; j++){
//				curBlockHolder = this.blockHolders[i][j];
//				collisionDirections = movable.collides(oldLocation, curBlockHolder);
//				
//				//check for animation steps
//				if(movable instanceof Mario && ((Mario)movable).getAnimation() != null && 
//						((Mario)movable).getAnimation().getStep() != null){
//					AnimationStep animationStep = ((Mario)movable).getAnimation().getStep();
//					animationStep.updateVelocity(this.game.getMario());
//					if(((Mario)movable).getAnimation().getStep() instanceof CollisionAnimationStep){
//						animationStep.checkFinishCondition(collisionDirections);
//					}else if(((Mario)movable).getAnimation().getStep() instanceof HorizontalDistanceAnimationStep){
//						animationStep.checkFinishCondition(((Mario)movable).getLocation());
//					}else if(((Mario)movable).getAnimation().getStep() instanceof GameOverAnimationStep){
//						animationStep.checkFinishCondition(((Mario)movable).getLocation());
//						
//						//Mario reached finish and animation ended
//						switch(((GameOverAnimationStep)animationStep).getState()){
//						case WON:
//							this.game.win();
//							break;
//						case LOST:
//							this.game.lose();
//							break;
//						default:
//							//nothing to do
//						}
//					}
//					
//					//in case of gravity
//					if(!animationStep.isIgnoreGravity()){
//						for(Direction direction : collisionDirections)
//							switch(direction){
//							case EAST:
//							case WEST:
//								if(!animationStep.isIgnoreHorizontalCollision()){
//									movable.setVelocityX(0);
//									movable.setLocationX(oldLocation.x);
//								}
//								break;
//							case SOUTH:
//								movable.setFeetOnGround(true); //do that only on SOUTH collision; No break!
//							case NORTH:
//								if(!animationStep.isIgnoreVerticalCollision()){
//									movable.setVelocityY(0);
//									movable.setLocationY(oldLocation.y);
//								}
//								break;
//							default:
//								break;
//							}
//					}
//				}else{ //no amination steps left
//					for(Direction direction : collisionDirections){
//						if(direction != Direction.NONE){
//							//movable collides with a LinkBlock
//							if(this.blockHolders[i][j].getBlock() instanceof LinkBlock && 
//									((LinkBlock)this.blockHolders[i][j].getBlock()).getLink() != null){
//								if(movable instanceof Mario){
//									//this.game.setCurrentMapByLink(((LinkBlock)this.blockHolders[i][j].getBlock()));
//									((LinkBlock)this.blockHolders[i][j].getBlock()).updateLatestLinkBlock();
//									
//									/*if(this.game.getCurrentMap().getGadget() instanceof VariableGadget){
//										//get new map from game TODO: Is that working?
//										this.game.getActionManager().addAction(new EntranceAction(this.game, 
//												this.game.getCurrentMap(), this.game.getMario().getLocation(), 
//												this.game.getTime(), this.game.getScore(), this.game.getMario().isSuper()));
//									}*/
//									
//									//set variable state on collision with variable link block
//									if(this.blockHolders[i][j].getBlock() instanceof VariableLinkBlock){
//										
//										//XXX: Changes made here, for alternative assignment represenation model. 
//										//this.game.getFormula().setVariables((VariableLinkBlock)this.blockHolders[i][j].getBlock());
//										this.game.getCurFormula().updateClauses((VariableLinkBlock)this.blockHolders[i][j].getBlock());
//										
//										System.out.println(this.game.getCurFormula().print());
//									}
//									
//									return; //ARRRGHHH!!! Without that, further collisions could be detected and Mario's location would be set wrongly.
//								}else if(movable instanceof Koopa){
//									this.koopas.remove((Koopa)movable); //Koopa leaves map and disappears
//									return;
//								}else if(movable instanceof Mushroom){
//									this.mushrooms.remove(((Mushroom)movable));
//									return;
//								}
//							}else if(this.blockHolders[i][j].getBlock().getType() == BlockType.LAVA){ //falling into lava
//								if(movable instanceof Mario){
//									((Mario)movable).die();
//								}else if(movable instanceof Koopa){
//									this.koopas.remove((Koopa)movable);
//								}else if(movable instanceof Mushroom){
//									this.mushrooms.remove((Mushroom)movable);
//								}
//								//return;
//							}else{
//								switch(direction){ //check for collision with blocks of other types
//								case EAST:
//								case WEST:
//								case HORIZONTAL_CENTER:
//									movable.setLocationX(oldLocation.x);
//									if(movable instanceof Mario){
//										movable.setVelocityX(0);
//										
//										switch(curBlockHolder.getBlock().getType()){
//										case FLAG:
//										case FLAG_HEAD:
//											//if(this.flag != null)
//											//	this.game.getActionManager().addAction(new FlagAction(this.flag));
//											Animation animation = new Animation();
//											//animation.addAnimationStep(new CollisionAnimationStep(Direction.SOUTH, 0, 150, true));
//											animation.addAnimationStep(new FlagAnimationStep(this.flag));
//											animation.addAnimationStep(new HorizontalDistanceAnimationStep(
//													(int)(-6.5*Constants.DEFAULT_BLOCK_SIZE.width), 
//													this.game.getMario().getLocation(), -Constants.MAX_MOVE_SPEED*0.7f, 0, false, true));
//											animation.addAnimationStep(new GameOverAnimationStep(GameState.WON));
//											this.game.getMario().setAnimation(animation);
//											this.game.addScore((curBlockHolder.getBlock().getType() == BlockType.FLAG_HEAD ? 
//													Constants.FINISH_HEAD_SCORE : Constants.FINISH_SCORE));
//											break;
//										default:
//											break;
//										}
//									}else if(movable instanceof Koopa){
//										movable.setVelocityX(-movable.getVelocityX()); //reflect from wall
//										if(curBlockHolder.getBlock().getType() == BlockType.BRICK){ //smash brick
//											replaceBlock(curBlockHolder, new Block(this, BlockType.EMPTY));
//											this.game.addScore(Constants.BRICK_SMASH_SCORE);
//											//this.game.getActionManager().addAction(new BrickAction(this, curBlockHolder));
//											checkBricks();
//										}else if(curBlockHolder.getBlock().getType() == BlockType.POWER_BLOCK){ //smash brick
//											replaceBlock(curBlockHolder, new Block(this, BlockType.USED_BLOCK));
//											this.game.addScore(Constants.COIN_SCORE);
//											//this.game.getActionManager().addAction(new PowerBlockAction(this, curBlockHolder));
//											usePowerBlock();
//											checkBricks();
//										}
//									}else if(movable instanceof Mushroom){
//										movable.setVelocityX(-movable.getVelocityX()); //reflect from wall
//									}
//									break;
//								case NORTH: //jump from below
//									movable.setVelocityY(-0.5f * movable.getVelocityY());
//									movable.setLocationY(oldLocation.y);
//									
//									if(movable instanceof Mario){
//										if(((Mario)movable).isSuper() && ((Mario)movable).hasFeetOnGround())
//											((Mario)movable).setCrouching(true); //TODO: Shit!!!
//										else
//											switch(curBlockHolder.getBlock().getType()){
//											case BRICK:
//												if(((Mario)movable).isSuper()){ //smash brick
//													replaceBlock(curBlockHolder, new Block(this, BlockType.EMPTY));
//													this.game.addScore(Constants.BRICK_SMASH_SCORE);
//													//this.game.getActionManager().addAction(new BrickAction(this, curBlockHolder));
//													checkBricks();
//												}
//												break;
//											case MUSHROOM_BLOCK:
//												replaceBlock(curBlockHolder, new Block(this, BlockType.USED_BLOCK));
//												this.mushrooms.add(new Mushroom(new MyPoint(curBlockHolder.getLocation().x, 
//														curBlockHolder.getLocation().y)));
//												break;
//											case COIN_BLOCK:
//												replaceBlock(curBlockHolder, new Block(this, BlockType.USED_BLOCK));
//												this.game.addScore(50);
//												//this.game.getActionManager().addAction(new CoinBlockAction(this, curBlockHolder));
//												break;
//											default:
//												break;
//											}
//									}
//									break;
//								case SOUTH:
//									//check for collision with neighboring empty block to avoid falling down
//									if(movable instanceof Koopa && !((Koopa)movable).isStunned()){
//										BlockHolder neighbor = 
//												this.blockHolders[i + (movable.getLastMoveDirection() == Direction.EAST ? 1 : -1)][j];
//										if(Constants.typePassableMapping.get(neighbor.getBlock().getType())){
//											List<Direction> neighborCollisionDirections = movable.collides(oldLocation, neighbor, true);
//											for(Direction neighborCollisionDirection : neighborCollisionDirections)
//												if(neighborCollisionDirection != Direction.NONE){
//													movable.setVelocityX(-movable.getVelocityX()); //turn around
//													break; //avoid possible multiple turn-arounds
//												}
//										}
//									}
//									
//									//Reset location AFTER empty-neighbor-check!!!
//									movable.setVelocityY(0);
//									//movable.setLocationY(oldLocation.y);
//									movable.setLocationY(curBlockHolder.getLocation().y); //avoid "rebouncing"...
//									movable.setFeetOnGround(true);
//									
//									break;
//								case VERTICAL_CENTER:
//									movable.setVelocityY(0);
//									movable.setLocationY(oldLocation.y);
//									break;
//								default:
//									break;
//								}
//							}
//							
//							//Don't react for further collisions on one block. Diagonal collision causes Mario to get stuck in block. 
//							break;
//						}
//					}
//				}
//			}
//	}
//	
//	private void replaceBlock(BlockHolder blockHolder, Block newBlock){
//		if(blockHolder.getBlock() != null){
//			SlideshowManager.getInstance().removeSlideshow(blockHolder.getBlock().getMap(), blockHolder.getBlock().getSlideshow());
//			blockHolder.setBlock(newBlock);
//			SlideshowManager.getInstance().addSlideshow(newBlock.getMap(), newBlock.getSlideshow());
//		}else
//			blockHolder.setBlock(newBlock);
//	}
//	
//	private void usePowerBlock(){
//		for(int i = 0; i < this.size.width; i++)
//			for(int j = 0; j < this.size.height; j++)
//				if(this.blockHolders[i][j].getBlock().getType() == BlockType.COIN){
//					replaceBlock(this.blockHolders[i][j], new Block(this, BlockType.COIN_BLOCK));
//					//this.game.getActionManager().addAction(new PowerCoinToBlockAction(this, this.blockHolders[i][j]));
//				}
//		
//		//remove coins
//		this.coins.clear();
//		
//		//clause is unlocked
//		this.game.getCurFormula().updateClauses(((ClauseGadget)this.gadget).getClause());
//		//this.game.getActionManager().addAction(new ClauseAction(((ClauseGadget)this.gadget).getClause()));
//	}
//	private void checkBricks(){
//		if(this.gadget instanceof ClauseGadget){
//			if(((ClauseGadget)this.gadget).getClauseGadgetStyle() == ClauseGadgetStyle.BRICKS){
//				for(int i = 0; i < this.size.width; i++)
//					for(int j = 0; j < this.size.height; j++)
//						if(this.blockHolders[i][j].getBlock().getType() == BlockType.BRICK)
//							return; //bricks left; do nothing
//			}else //wrong gadget style; is treated separately
//				return;
//			
//			//no more bricks in this clause gadget -> unlocked; update clause
//			this.game.getCurFormula().updateClauses(((ClauseGadget)this.gadget).getClause());
//			//this.game.getActionManager().addAction(new ClauseAction(((ClauseGadget)this.gadget).getClause()));
//		}
//	}
//	
//	public void updateSlideshows(){
//		for(int i = 0; i < this.size.width; i++)
//			for(int j = 0; j < this.size.height; j++)
//				this.blockHolders[i][j].getBlock().updateSlideshow();
//		
//		for(Koopa koopa : this.koopas)
//			koopa.updateSlideshow();
//		for(Coin coin : this.coins)
//			coin.updateSlideshow();
//		for(Mushroom mushroom : this.mushrooms)
//			mushroom.updateImage();
//	}
//	
//	public void addKoopa(MyPoint location){
//		this.koopas.add(new Koopa(this, location));
//	}
//	public void addKoopa(Koopa koopa){
//		this.koopas.add(koopa);
//	}
//	public void addCoin(Coin coin){
//		this.coins.add(coin);
//	}
//	public void removeKoopa(Koopa koopa){
//		if(koopa != null)
//			this.koopas.remove(koopa);
//	}
//	public void removeCoin(Coin coin){
//		this.coins.remove(coin);
//	}
//	public void addBackground(ImageInfo background){
//		this.background.add(background);
//	}
//	public void clearBackground(){
//		this.background.clear();
//	}
//	
//	public void insertFlag(){
//		for(int i = 0; i < this.size.width; i++)
//			for(int j = 0; j < this.size.height; j++)
//				if(this.blockHolders[i][j].getBlock().getType() == BlockType.FLAG_HEAD && j < this.size.height-1){
//					this.flag = new Flag(this.blockHolders[i][j+1].getLocation(), 
//							this.blockHolders[i][this.size.height-4].getLocation());
//					return;
//				}
//	}
//	
//	/**
//	 * Sets the location of all block holders to their default location. 
//	 * Needed to reset scrolling. 
//	 */
//	public void resetBlockHolderLocations(){
//		for(int i = 0; i < this.size.width; i++)
//			for(int j = 0; j < this.size.height; j++)
//				this.blockHolders[i][j].resetLocation();
//	}
//	
//	public Gadget getGadget(){
//		return this.gadget;
//	}
//	public BlockHolder [][] getBlockHoldersReal(){
//		return this.blockHolders;
//	}
//	/**
//	 * Attention: This does not include border-blocks!
//	 */
//	public BlockHolder [][] getBlockHolders(){
//		BlockHolder temp[][] = new BlockHolder [this.size.width-2][this.size.height-2];
//		for(int i = 1; i < this.size.width-1; i++)
//			for(int j = 1; j < this.size.height-1; j++)
//				temp[i-1][j-1] = this.blockHolders[i][j];
//		return temp;
//	}
//	/**
//	 * Attention: This method ignores border-blocks!
//	 */
//	public BlockHolder getBlockHolder(int i, int j){
//		if(i < 0 || i >= this.size.width-2 || j < 0 || j >= this.size.height-2)
//			return null;
//		return this.blockHolders[i+1][j+1];
//	}
//	public Dimension getSizeReal(){
//		return this.size;
//	}
//	public Dimension getSize(){
//		return new Dimension(this.size.width-2, this.size.height-2);
//	}
//	public List<Koopa> getKoopas(){
//		return this.koopas;
//	}
//	public List<Mushroom> getMushrooms(){
//		return this.mushrooms;
//	}
//	public Flag getFlag(){
//		return this.flag;
//	}
//	public List<Collidable> getCollidables(){
//		List<Collidable> movables = new LinkedList<Collidable>();
//		movables.add(this.game.getMario());
//		movables.addAll(this.koopas);
//		movables.addAll(this.mushrooms);
//		movables.addAll(this.coins);
//		return movables;
//	}
//	public List<ImageInfo> getBackground(){
//		return this.background;
//	}
}