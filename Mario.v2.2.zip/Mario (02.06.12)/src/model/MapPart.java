package model;

import java.awt.Point;

import model.animation.SlideshowManager;
import model.blocks.Block;
import model.blocks.BlockHolder;
import util.Constants;
import util.Constants.BlockType;
import util.MyPoint;

public class MapPart{
	private Point index;
	private MyPoint offset;
	private BlockHolder blockHolders[][];
	//private List<Coin> coins;
	
	public MapPart(int x, int y){
		this.index = new Point(x, y);
		this.offset = new MyPoint(x * Constants.MAP_PART_SIZE.width * Constants.DEFAULT_BLOCK_SIZE.width,
				y * Constants.MAP_PART_SIZE.height * Constants.DEFAULT_BLOCK_SIZE.height);
		this.blockHolders = new BlockHolder [Constants.MAP_PART_SIZE.width][Constants.MAP_PART_SIZE.height];
		
		for(int i = 0; i < Constants.MAP_PART_SIZE.width; i++)
			for(int j = 0; j < Constants.MAP_PART_SIZE.height; j++){
				this.blockHolders[i][j] = new BlockHolder(new MyPoint(i * Constants.DEFAULT_BLOCK_SIZE.width, 
						j * Constants.DEFAULT_BLOCK_SIZE.height));
				replaceBlock(i, j, new Block(this, BlockType.EMPTY));
			}
		
		//this.coins = new LinkedList<Coin>();
	}
	
	public void replaceBlock(int i, int j, Block newBlock){
		BlockHolder blockHolder = this.blockHolders[i][j];
		if(blockHolder.getBlock() != null){
			SlideshowManager.getInstance().removeSlideshow(blockHolder.getBlock().getMap(), blockHolder.getBlock().getSlideshow());
			blockHolder.setBlock(newBlock);
			SlideshowManager.getInstance().addSlideshow(newBlock.getMap(), newBlock.getSlideshow());
		}else
			blockHolder.setBlock(newBlock);
	}
	
	public Point getIndex(){
		return this.index;
	}
	public MyPoint getOffset(){
		return this.offset;
	}
	public BlockHolder [][] getBlockHolders(){
		return this.blockHolders;
	}
	public BlockHolder getBlockHolder(int x, int y){
		if(x < 0 || x >= Constants.MAP_PART_SIZE.width || y < 0 || y >= Constants.MAP_PART_SIZE.height)
			return null;
		
		return this.blockHolders[x][y];
	}
	
	/*public void addCoin(Coin coin){
		this.coins.add(coin);
	}
	public void removeCoin(Coin coin){
		this.coins.remove(coin);
	}*/
}