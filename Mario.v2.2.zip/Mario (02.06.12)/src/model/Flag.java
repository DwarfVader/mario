package model;

import util.Constants;
import util.MyPoint;

public class Flag{
	private MapPart map;
	private MyPoint location;
	private MyPoint velocity;
	private MyPoint destinationLocation;
	private MapPart destinationMap;
	
	public Flag(MyPoint location, MapPart map, MyPoint destinationLocation, MapPart destinationMap){
		this.map = map;
		this.location = new MyPoint(location);
		this.velocity = new MyPoint(0, 0);
		this.destinationLocation = new MyPoint(destinationLocation);
		this.destinationMap = destinationMap;
	}
	
	public void move(){
		if(this.location.y.value < this.destinationLocation.y.value + (this.destinationMap.getIndex().y - this.map.getIndex().y) * 
				Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height)
			this.location.y.value += this.velocity.y.value;
	}
	
	public void fuckingStartToMove(MyPoint velocity){
		this.velocity.x.value = velocity.x.value / 1000 * Constants.TIMER_INTERVAL;
		this.velocity.y.value = velocity.y.value / 1000 * Constants.TIMER_INTERVAL;
	}
	public void fuckingStopMoving(){
		this.velocity.x.value = 0;
		this.velocity.y.value = 0;
	}
	
	public void setMap(MapPart map){
		this.map = map;
	}
	public void setLocation(MyPoint location){
		this.location.x = location.x;
		this.location.y = location.y;
	}
	
	public MapPart getMap(){
		return this.map;
	}
	public MyPoint getLocation(){
		return this.location;
	}
	public MyPoint getVelocity(){
		return this.velocity;
	}
}