package model;

import java.awt.Image;

import util.Constants;
import util.ImageLoader;
import util.MyPoint;

public class FinishGate{
	private MapPart map;
	private MyPoint blockLocation;
	private Image image;
	
	public FinishGate(MapPart map, MyPoint location){
		this.map = map;
		this.blockLocation = location;
		this.image = ImageLoader.finishGateImage;
	}
	
	public MapPart getMap(){
		return this.map;
	}
	public MyPoint getBlockLocation(){
		return this.blockLocation;
	}
	public MyPoint getRenderLocation(){
		return new MyPoint(this.blockLocation.x.value - (this.image.getWidth(null)-Constants.BLOCK_SIZE.width)/2, 
				this.blockLocation.y.value - this.image.getHeight(null) + Constants.BLOCK_SIZE.height);
	}
	public Image getImage(){
		return this.image;
	}
}