package model.blocks;

import java.awt.Dimension;
import java.awt.Image;
import java.util.LinkedList;

import model.MapPart;
import model.animation.Slideshow;
import model.animation.SlideshowManager;
import util.Constants;
import util.Constants.BlockType;
import util.ImageLoader;

public class Block{
	protected MapPart map;
	protected BlockType type;
	//private Dimension collisionSize;
	protected Slideshow slideshow;
	
	public Block(MapPart map, BlockType type){
		this.map = map;
		this.type = type;
		
		updateSlideshow();
	}
	
	public void updateSlideshow(){
		if(this.slideshow != null)
			SlideshowManager.getInstance().removeSlideshow(this.map, this.slideshow);
		
		switch(type){
		case FLAG:
			this.slideshow = new Slideshow(ImageLoader.getBlockImage(this.type), 0);
			break;
		case FLAG_HEAD:
			this.slideshow = new Slideshow(ImageLoader.getBlockImage(this.type), 0);
			break;
		case LAVA:
			this.slideshow = new Slideshow(ImageLoader.lavaImages, 250);
			break;
		case ROTATE_BLOCK:
			this.slideshow = null; //set in RotateBlock constructor
			break;
		case COIN_BLOCK:
		case MUSHROOM_BLOCK:
		case POWER_BLOCK:
			this.slideshow = new Slideshow(ImageLoader.questionBlockImages, 800);
			break;
		default:
			this.slideshow = new Slideshow(ImageLoader.getBlockImage(this.type), 0);
		}
		
		if(this.slideshow == null)
			this.slideshow = new Slideshow(new LinkedList<Image>(), 0);
		
		SlideshowManager.getInstance().addSlideshow(this.map, this.slideshow);
	}
	
	public boolean passable(){
		return Constants.typePassableMapping.get(this.type);
	}
	
	public MapPart getMap(){
		return this.map;
	}
	public BlockType getType(){
		return this.type;
	}
	public Dimension getCollisionSize(){
		switch(type){
		case FLAG:
			return Constants.DEFAULT_FLAG_SIZE;
		case FLAG_HEAD:
			return Constants.DEFAULT_FLAG_HEAD_SIZE;
		default:
			return Constants.DEFAULT_BLOCK_SIZE;
		}
	}
	public Image getImage(){
		return getSlideshow().getCurrentImage();
	}
	public Slideshow getSlideshow(){
		return this.slideshow;
	}
}