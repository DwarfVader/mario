package model.blocks;

import java.awt.Image;

import model.MapPart;
import model.formula.Variable;
import util.Constants.BlockType;
import util.ImageLoader;

public class ArrowBlock extends Block{
	private Variable variable;
	
	public ArrowBlock(MapPart map, BlockType type, Variable variable){
		super(map, type);
		
		this.variable = variable;
	}
	
	@Override
	public Image getImage(){
		if(this.variable == null)
			return ImageLoader.dummyImage;
		
		Image image = null;
		
		switch(this.variable.getSatisfied()){
		case TRUE:
			image = ImageLoader.arrowLeft;
			break;
		case FALSE:
			image = ImageLoader.arrowUp;
			break;
		default:
		}
		
		return image;
	}
}