package model.blocks;

import java.util.LinkedList;
import java.util.List;

import util.TimerDepending;

public class BlockManager{
	private static BlockManager instance;
	
	private List<TimerDepending> timedBlocks;
	
	private BlockManager(){
		this.timedBlocks = new LinkedList<TimerDepending>();
	}
	
	public static BlockManager getInstance(){
		if(instance == null)
			instance = new BlockManager();
		
		return instance;
	}
	public static void reset(){
		if(instance != null)
			instance.clear();
	}
	
	public void incrementTime(int timerInterval){
		for(TimerDepending timedBlock : this.timedBlocks)
			timedBlock.incrementTime(timerInterval);
	}
	
	public void registerBlock(TimerDepending timedBlock){
		if(!this.timedBlocks.contains(timedBlock))
			this.timedBlocks.add(timedBlock);
	}
	public void unregisterBlock(TimerDepending timedBlock){
		this.timedBlocks.remove(timedBlock);
	}
	
	public void clear(){
		this.timedBlocks.clear();
	}
}