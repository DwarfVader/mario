package model.blocks;

import model.MapPart;
import model.animation.Condition;
import model.animation.IntegerCondition;
import model.animation.Slideshow;
import model.formula.Clause;
import model.formula.Formula;
import model.formula.Variable;
import util.Constants;
import util.Constants.BlockType;
import util.ImageLoader;
import util.MyInteger;
import util.TimerDepending;
import util.VariableState;

public class RotateBlock extends Block implements TimerDepending{
	private MyInteger rotateTime;
	private Variable variable;
	
	public RotateBlock(MapPart map, BlockType type){
		this(map, type, null, null);
	}
	public RotateBlock(MapPart map, BlockType type, Clause clause, Variable variable){
		super(map, type);

		this.rotateTime = new MyInteger(0);
		this.variable = variable;
		
		Condition startCondition = new IntegerCondition(((RotateBlock)this).getRotatingTime(), ">", 0);
		this.slideshow = new Slideshow(ImageLoader.rotateBlockImages, 500, startCondition);
	}
	
	public void rotate(Formula formula){
		if(this.rotateTime.value == 0)
			this.rotateTime.value += Constants.ROTATING_TIME;
		
		if(this.variable != null)
			this.variable.setSatisfied(VariableState.FALSE);
	}
	
	public MyInteger getRotatingTime(){
		return this.rotateTime;
	}
	public Variable getVariable(){
		return this.variable;
	}
	
	@Override
	public boolean passable(){
		return rotateTime.value > 0;
	}
	
	@Override
	public void incrementTime(int timerInterval){
		this.rotateTime.value -= timerInterval;
		if(this.rotateTime.value <= 0)
			this.rotateTime.value = 0;
	}
}