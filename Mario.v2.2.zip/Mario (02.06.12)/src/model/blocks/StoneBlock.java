package model.blocks;

import java.util.LinkedList;
import java.util.List;

import model.MapPart;
import model.StoneChainLink;
import util.Constants;
import util.Constants.BlockType;
import util.MyPoint;
import util.TimerDepending;

public class StoneBlock extends Block implements TimerDepending{
	public int numChainLinks;
	public int rotateSpeed = 90; //degrees / s
	
	private MyPoint location;
	private float angle; //angle in degrees
	private boolean turnRight;
	private List<StoneChainLink> chainLinks;
	private List<StoneChainLink> doubleChainLinks; //counter part rotating on opposite side of normal stone balls if needed
	private boolean doubleStone; //stating whether there is a countering stone chain on opposite direction
	
	public StoneBlock(MapPart map, BlockType type, MyPoint location){
		this(map, type, location, false, 3);
	}
	public StoneBlock(MapPart map, BlockType type, MyPoint location, boolean doubleSize){
		this(map, type, location, doubleSize, 3);
	}
	public StoneBlock(MapPart map, BlockType type, MyPoint location, int numFireballs){
		this(map, type, location, false, numFireballs);
	}
	public StoneBlock(MapPart map, BlockType type, MyPoint location, boolean doubleStone, int numChainLinks){
		super(map, type);
		
		this.location = new MyPoint(location);
		this.angle = 0;
		this.turnRight = true; //default value
		this.numChainLinks = numChainLinks;
		this.chainLinks = new LinkedList<StoneChainLink>();
		for(int i = 0; i < this.numChainLinks; i++)
			this.chainLinks.add(new StoneChainLink(map, i < this.numChainLinks-1 ? "chain" : "ball", location));
		this.doubleStone = doubleStone;
		this.doubleChainLinks = new LinkedList<StoneChainLink>();
		if(doubleStone){
			for(int i = 0; i < this.numChainLinks; i++)
				this.doubleChainLinks.add(new StoneChainLink(map, i < this.numChainLinks-1 ? "chain" : "ball", location));
		}
		arrangeChainLinks();
	}
	
	private void arrangeChainLinks(){
		float offset = 0;
		float oldLinkRadius = Constants.STONECHAIN_SIZE.width/2;
		float curLinkRadius;
		for(int i = 0; i < this.numChainLinks; i++){
			curLinkRadius = (i < this.numChainLinks-1 ? Constants.STONECHAIN_SIZE.width : Constants.STONEBALL_SIZE.width)/2f;
			
			this.chainLinks.get(i).setLocation(
					(int)(offset*Math.sin(this.angle/180f*Math.PI) + 
					this.location.x.value + Constants.BLOCK_SIZE.width/2 - curLinkRadius), 
					(int)(offset*Math.cos(this.angle/180f*Math.PI) + 
					this.location.y.value + Constants.BLOCK_SIZE.height/2 - curLinkRadius));
			
			if(this.doubleStone)
				this.doubleChainLinks.get(i).setLocation(
						(int)(offset*Math.sin((this.angle + 180)/180f*Math.PI) + 
						this.location.x.value + Constants.BLOCK_SIZE.width/2 - curLinkRadius), 
						(int)(offset*Math.cos((this.angle + 180)/180f*Math.PI) + 
						this.location.y.value + Constants.BLOCK_SIZE.height/2 - curLinkRadius));

			offset += (oldLinkRadius + curLinkRadius)*1.05f;
			oldLinkRadius = curLinkRadius;
		}
	}
	
	@Override
	public void incrementTime(int timerInterval){
		this.angle += (this.turnRight ? -1 : 1) * rotateSpeed * timerInterval / 1000f;
		this.angle = (this.angle + 360) % 360;
		
		arrangeChainLinks();
	}
	
	public void setNumFireballs(int numFireballs){
		this.numChainLinks = numFireballs;
	}
	public void setRotateSpeed(int speed){
		this.rotateSpeed = speed;
	}
	public void setAngle(float angle){
		this.angle = angle;
	}
	public void setTurnRight(boolean turnRight){
		this.turnRight = turnRight;
		
		if(!turnRight)
			this.angle *= -1;
	}
	
	public List<StoneChainLink> getChainLinks(){
		List<StoneChainLink> chainLinks = new LinkedList<StoneChainLink>();
		chainLinks.addAll(this.chainLinks);
		chainLinks.addAll(this.doubleChainLinks);
		
		return chainLinks;
	}
	/*public List<StoneChainLink> getChainLinksAt(int index){
		List<StoneChainLink> chainLinks = new LinkedList<StoneChainLink>();
		
		if(index < 0 || index >= this.chainLinks.size())
			index = 0;
		chainLinks.add(this.chainLinks.get(index));
		if(this.doubleStone)
			chainLinks.add(this.doubleChainLinks.get(index));
		
		return chainLinks;
	}*/
	public List<StoneChainLink> getStoneBalls(){
		List<StoneChainLink> stoneBalls = new LinkedList<StoneChainLink>();
		
		for(StoneChainLink chainLink : this.chainLinks)
			if(chainLink.getType().equals("ball"))
				stoneBalls.add(chainLink);
		for(StoneChainLink chainLink : this.doubleChainLinks)
			if(chainLink.getType().equals("ball"))
				stoneBalls.add(chainLink);
		
		return stoneBalls;
	}
	public MyPoint getLocation(){
		return this.location;
	}
}