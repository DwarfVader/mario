package model.blocks;

import model.MapPart;
import util.Constants.BlockType;

public class LabelBlock extends Block{
	protected String label;
	protected boolean isLiteralLabel;
	
	public LabelBlock(MapPart map, BlockType type, String label){
		this(map, type, label, false);
	}
	public LabelBlock(MapPart map, BlockType type, String label, boolean isLiteralLabel){
		super(map, type);
		
		this.label = label;
		this.isLiteralLabel = isLiteralLabel;
	}
	
	public String getLabel(){
		return this.label;
	}
	public boolean isLiteralLabel(){
		return this.isLiteralLabel;
	}
}