package model.blocks;

import model.MapPart;
import model.formula.Clause;
import model.formula.Formula;
import model.formula.Variable;
import util.Constants.BlockType;
import util.MyPoint;
import util.VariableState;

public class TrampolineDestinationBlock extends Block{
	private MyPoint location;
//	private Clause clause;
	private Variable variable;
	
	public TrampolineDestinationBlock(MapPart map, BlockType type, MyPoint location, Clause clause, Variable variable){
		super(map, type);
		
		this.location = new MyPoint(location);
//		this.clause = clause;
		this.variable = variable;
	}
	
	public void satisfyLiteral(Formula formula){
		if(this.variable != null){
			this.variable.setSatisfied(VariableState.TRUE);
//			formula.checkClausePSPACE(this.clause);
		}
	}
	
	public MyPoint getLocation(){
		return this.location;
	}
//	public Clause getClause(){
//		return this.clause;
//	}
	public Variable getVariable(){
		return this.variable;
	}
}