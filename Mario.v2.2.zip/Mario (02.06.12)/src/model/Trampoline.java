package model;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.util.LinkedList;
import java.util.List;

import model.blocks.BlockHolder;
import util.Collidable;
import util.Constants;
import util.Constants.Direction;
import util.ImageLoader;
import util.Movable;
import util.MyPoint;

public class Trampoline implements Movable{
	private Game game;
	private MyPoint location;
	private MyPoint oldLocation;
	private MyPoint initLocation;
	private MyPoint velocity;
	private MapPart curMap;
	private MapPart initMap;
	
	private Image image;
	
	private boolean isFixed;
	private boolean isGrabbed;
	
	public Trampoline(Game game, MapPart map, MyPoint location, boolean isFixed){
		this.game = game;
		this.location = new MyPoint(location);
		this.oldLocation = new MyPoint(location);
		this.initLocation = new MyPoint(location);
		this.velocity = new MyPoint(0, 0);
		this.curMap = map;
		this.initMap = map;
		
		this.image = ImageLoader.trampolineImage;
		
		this.isFixed = isFixed;
		this.isGrabbed = false;
	}
	
	@Override
	public void move(){
		if(!this.isGrabbed){
			setOldLocation(this.location);
			
			if(this.velocity.y.value < Constants.MAX_FALLING_SPEED / 1000 * Constants.TIMER_INTERVAL) //define a maximum falling speed
				this.velocity.y.value += (Constants.GRAVITY / 1000 * Constants.TIMER_INTERVAL) / 1000 * Constants.TIMER_INTERVAL; //increase falling speed until it reaches its limit
			
			//change location by velocity values on every method call
			this.location.y.value += this.velocity.y.value;
			
			checkMapChange();
			
			updateImage();
		}
	}
	
	public void checkMapChange(){
		if(this.location.x.value >= Constants.MAP_PART_SIZE.width*Constants.BLOCK_SIZE.width)
			changeMap(this.curMap.getIndex().x + 1, this.curMap.getIndex().y);
		else if(this.location.x.value < 0)
			changeMap(this.curMap.getIndex().x - 1, this.curMap.getIndex().y);
		
		if(this.location.y.value >= Constants.MAP_PART_SIZE.height*Constants.BLOCK_SIZE.height)
			changeMap(this.curMap.getIndex().x, this.curMap.getIndex().y + 1);
		else if(this.location.y.value < 0)
			changeMap(this.curMap.getIndex().x, this.curMap.getIndex().y - 1);
	}
	private void changeMap(int i, int j){
		MapPart newMap = this.game.getMap(i, j);
		int maxWidth = Constants.MAP_PART_SIZE.width*Constants.BLOCK_SIZE.width;
		int maxHeight = Constants.MAP_PART_SIZE.height*Constants.BLOCK_SIZE.height;
		if(newMap != null){
			int dx = this.curMap.getIndex().x - i;
			int dy = this.curMap.getIndex().y - j;
			this.location.x.value += dx * maxWidth;
			this.location.y.value += dy * maxHeight;
			
			//need to change old location as well
			this.oldLocation.x.value += dx * maxWidth;
			this.oldLocation.y.value += dy * maxHeight;

			this.curMap = newMap;
		}
	}
	
	@Override
	public void updateImage(){}
	
	/**
	 * Checks, whether this player collides with a field, which is non-empty. 
	 * 
	 * @param oldLocation the players location before moving
	 * @param blockHolder the field to check against collision 
	 * @return a list containing all direction, in which Mario collides with blockHolder
	 */
	@Override
	public List<Direction> collides(Collidable collidable, Point offset){
		return collides(collidable, offset, false);
	}
	@Override
	public List<Direction> collides(Collidable collidable, Point offset, boolean ignorePassable){
		List<Direction> collisionDirections = new LinkedList<Direction>();
		
		//collision with block holder containing a passable block; ignorePassable needed for detection of last block to avoid falling
		if(!ignorePassable && collidable instanceof BlockHolder && 
				Constants.typePassableMapping.get(((BlockHolder)collidable).getBlock().getType()))
			collisionDirections.add(Direction.NONE);
		else{ //collision
			collisionDirections.add(collides(new MyPoint(this.location.x.value, oldLocation.y.value), collidable, offset, Direction.HORIZONTAL));
			collisionDirections.add(collides(new MyPoint(oldLocation.x.value, this.location.y.value), collidable, offset, Direction.VERTICAL));
		}
		
		return collisionDirections;
	}
	public Direction collides(MyPoint koopaLocation, Collidable collidable, Point offset, Direction collisionDirection){
		//have to check for both vertical and horizontal collision
		if(collisionDirection == Direction.HORIZONTAL && collidesVertical(koopaLocation, collidable, offset.y) != Direction.NONE)
			return collidesHorizontal(koopaLocation, collidable, offset.x); //EAST or WEST or NONE
		else if(collisionDirection == Direction.VERTICAL && collidesHorizontal(koopaLocation, collidable, offset.x) != Direction.NONE)
			return collidesVertical(koopaLocation, collidable, offset.y); //NORTH or SOUTH or NONE
		
		return Direction.NONE;
	}
	private Direction collidesHorizontal(MyPoint koopaLocation, Collidable collidable, int offsetX){
		/** Attention: Doesn't make sense without parallel vertical collision check! */
		if(koopaLocation.x.value + Constants.DEFAULT_BLOCK_SIZE.width > collidable.getCollisionLocation().x.value + offsetX + 
				Constants.MARIO_SIZE_OFFSET && 
				koopaLocation.x.value < collidable.getCollisionLocation().x.value + offsetX + 
				collidable.getCollisionSize().width - Constants.MARIO_SIZE_OFFSET){
			//left side is outside block
			if(koopaLocation.x.value < collidable.getCollisionLocation().x.value + offsetX)
				return Direction.EAST;
			else if(koopaLocation.x.value + Constants.DEFAULT_BLOCK_SIZE.width >= collidable.getCollisionLocation().x.value + offsetX + 
					Constants.DEFAULT_BLOCK_SIZE.width)
				return Direction.WEST;
		}
		return Direction.NONE;
	}
	private Direction collidesVertical(MyPoint koopaLocation, Collidable collidable, int offsetY){
		/** Attention: Doesn't make sense without parallel horizontal collision check! */
		/** Attention: Mario's location is based on his feet! */
		//there is a vertical collision
		if(koopaLocation.y.value > collidable.getCollisionLocation().y.value + offsetY + 0 && 
				koopaLocation.y.value - Constants.DEFAULT_BLOCK_SIZE.height < 
				collidable.getCollisionLocation().y.value + offsetY + collidable.getCollisionSize().height - 
				Constants.MARIO_SIZE_OFFSET){
			//head is over the top of the block; his feet touch the block
			if(koopaLocation.y.value - Constants.DEFAULT_BLOCK_SIZE.height < collidable.getCollisionLocation().y.value + offsetY)
				return Direction.SOUTH;
			else if(koopaLocation.y.value >= collidable.getCollisionLocation().y.value + offsetY + Constants.DEFAULT_BLOCK_SIZE.height)
				return Direction.NORTH;
		}
		//no vertical collision
		return Direction.NONE;
	}
	
	@Override
	public void setLocation(MyPoint location){
		setLocation(location.x.value, location.y.value);
	}
	@Override
	public void setLocation(double x, double y){
		this.location.x.value = x;
		this.location.y.value = y;
	}
	@Override
	public void setLocationX(double x){
		this.location.x.value = x;
	}
	@Override
	public void setLocationY(double y){
		this.location.y.value = y;
	}
	@Override
	public void setOldLocation(MyPoint oldLocation){
		setOldLocation(oldLocation.x.value, oldLocation.y.value);
	}
	@Override
	public void setOldLocation(double x, double y){
		this.oldLocation.x.value = x;
		this.oldLocation.y.value = y;
	}
	@Override
	public void setVelocityX(double vx){}
	@Override
	public void setVelocityY(double vy){
		this.velocity.y.value = vy;
	}
	@Override
	public void setFeetOnGround(){}
	
	public MyPoint getLocation(){
		return this.location;
	}
	@Override
	public MyPoint getOldLocation(){
		return this.oldLocation;
	}
	public MyPoint getInitLocation(){
		return this.initLocation;
	}
	public MyPoint getVelocity(){
		return this.velocity;
	}
	public void setGrabbed(boolean isGrabbed){
		this.isGrabbed = isGrabbed;
	}
	public void setCurMap(MapPart map){
		this.curMap = map;
	}
	
	@Override
	public MyPoint getCollisionLocation(){
		return new MyPoint(this.location.x.value, this.location.y.value - getCollisionSize().height);
	}
	@Override
	public MyPoint getOldCollisionLocation(){
		return new MyPoint(this.oldLocation.x.value, this.oldLocation.y.value - getCollisionSize().height);
	}
	@Override
	public Dimension getCollisionSize(){
		float width = Constants.BLOCK_SIZE.width * 3 / 4f;
		return new Dimension((int)width, (int)width);
	}
	@Override
	public double getVelocityX(){
		return this.velocity.x.value;
	}
	@Override
	public double getVelocityY(){
		return this.velocity.y.value;
	}
	@Override
	public Direction getLastMoveDirection(){
		return null; //Works?
	}
	@Override
	public MapPart getCurMap(){
		return this.curMap;
	}
	public MapPart getInitMap(){
		return this.initMap;
	}
	@Override
	public Image getImage(){
		return this.image;
	}
	public boolean isFixed(){
		return this.isFixed;
	}
	public boolean isGrabbed(){
		return this.isGrabbed;
	}
}