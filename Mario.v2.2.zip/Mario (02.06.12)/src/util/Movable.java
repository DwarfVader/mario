package util;

import util.Constants.Direction;

public interface Movable extends Collidable{
	public void move();
	
	public void setLocation(MyPoint location);
	public void setLocation(double x, double y);
	public void setLocationX(double x);
	public void setLocationY(double y);
	public void setOldLocation(MyPoint oldLocation);
	public void setOldLocation(double x, double y);	
	public void setVelocityX(double vx);
	public void setVelocityY(double vy);
	
	public void setFeetOnGround();
	
	public MyPoint getOldLocation();
	public double getVelocityX();
	public double getVelocityY();
	
	public Direction getLastMoveDirection();
	public void updateImage();
}