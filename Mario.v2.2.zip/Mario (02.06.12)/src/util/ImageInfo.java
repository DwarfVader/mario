package util;

import java.awt.Image;
import java.awt.Point;

public class ImageInfo{
	private Image image;
	private Point location;
	
	public ImageInfo(Image image, Point location){
		this.image = image;
		this.location = new Point(location);
	}
	
	public void setLocation(int x, int y){
		this.location.x = x;
		this.location.y = y;
	}
	
	public Image getImage(){
		return this.image;
	}
	public Point getLocation(){
		return this.location;
	}
}