package util;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.util.HashMap;
import java.util.Map;

public class Constants{
	private Constants(){}

	public static final Dimension DEFAULT_BLOCK_SIZE = new Dimension(40, 40);
	public static final int DEFAULT_MARIO_SIZE_OFFSET = (int)((float)DEFAULT_BLOCK_SIZE.width/16 + 1); //free space between Mario and walls in pixels
	public static final int DEFAULT_KOOPA_SIZE_OFFSET = (int)((float)DEFAULT_BLOCK_SIZE.width/8 + 1);
	public static final Dimension DEFAULT_FLAG_SIZE = new Dimension(DEFAULT_BLOCK_SIZE.width/3, DEFAULT_BLOCK_SIZE.height);
	public static final Dimension DEFAULT_FLAG_HEAD_SIZE = new Dimension(DEFAULT_BLOCK_SIZE.width*2/3, DEFAULT_BLOCK_SIZE.height*2/3);
	public static final float MARIO_SMALL_SIZE_RATIO = 0.95f; //TODO: Adapt!
	public static final float MARIO_BIG_SIZE_RATIO = 28.f/16.f;
	public static final float MARIO_CROUCH_SIZE_RATIO = 14.f/22.f;
	public static final float KOOPA_NORMAL_SIZE_RATIO = 26f/23f;
	public static final float KOOPA_SHELL_SIZE_RATIO = 17.f/24.f;
	public static final float FINISH_GATE_SIZE_RATIO = 99f/117f;
	public static final float GAME_PANEL_SIZE_RATIO = 19f/32f;
	public static final float SCREEN_SIZE_RATIO = (float)Toolkit.getDefaultToolkit().getScreenSize().height/
			Toolkit.getDefaultToolkit().getScreenSize().width;
	
	public static final Dimension FRAME_SIZE = new Dimension(Math.min(1400, Toolkit.getDefaultToolkit().getScreenSize().width), 
			Math.min(1000, Toolkit.getDefaultToolkit().getScreenSize().height));
	public static final Dimension GAME_FRAME_MINIMUM_SIZE = new Dimension(800, (int)(800*SCREEN_SIZE_RATIO));
	//public static Dimension GAME_FRAME_SIZE = new Dimension(1024, (int)(1024*SCREEN_SIZE_RATIO));
	public static Dimension GAME_FRAME_SIZE = new Dimension(1000, 1000);

	public static Dimension GAME_PANEL_SIZE = new Dimension(GAME_FRAME_SIZE.width, 
			(int)(GAME_FRAME_SIZE.height*0.85));
	public static Dimension FORMULA_PANEL_SIZE = new Dimension(GAME_FRAME_SIZE.width, 
			GAME_FRAME_SIZE.height-GAME_PANEL_SIZE.height-20);
	
	public static final Dimension BLOCK_SIZE = new Dimension(DEFAULT_BLOCK_SIZE);
	public static final int BLOCK_SIZE_MINIMAP_RATIO = 4;
	public static final Dimension BLOCK_SIZE_MINIMAP = new Dimension(BLOCK_SIZE.width / BLOCK_SIZE_MINIMAP_RATIO, 
			BLOCK_SIZE.height / BLOCK_SIZE_MINIMAP_RATIO);
	public static final Dimension FLAG_SIZE = new Dimension(BLOCK_SIZE.width/3, BLOCK_SIZE.height);
	public static final Dimension FLAG_HEAD_SIZE = new Dimension(BLOCK_SIZE.width*2/3, BLOCK_SIZE.height*2/3);
	public static final int MARIO_SIZE_OFFSET = BLOCK_SIZE.width/8; //free space between Mario and walls in pixels
	public static final Dimension STONECHAIN_SIZE = new Dimension(BLOCK_SIZE.width*3/4, BLOCK_SIZE.height*3/4);
	public static final Dimension STONEBALL_SIZE = new Dimension(BLOCK_SIZE.width*2, BLOCK_SIZE.height*2);
	public static final Dimension FIREBALL_SIZE = new Dimension(BLOCK_SIZE.width*3/4, BLOCK_SIZE.height*3/4);

	public static final Dimension PATH_SIZE = new Dimension(6, 6);
	public static final Dimension MAP_PART_SIZE = new Dimension(3, 3); //orig: (30, 30)
	public static final Dimension NUM_MAPS_TO_RENDER = new Dimension(
			Toolkit.getDefaultToolkit().getScreenSize().width / (BLOCK_SIZE.width * MAP_PART_SIZE.width) + 2,
			Toolkit.getDefaultToolkit().getScreenSize().height / (BLOCK_SIZE.height * MAP_PART_SIZE.height) + 2);
	public static final Dimension NUM_MAPS_TO_RENDER_MINIMAP = new Dimension(
			Toolkit.getDefaultToolkit().getScreenSize().width / (BLOCK_SIZE_MINIMAP.width * MAP_PART_SIZE.width) + 2,
			Toolkit.getDefaultToolkit().getScreenSize().height / (BLOCK_SIZE_MINIMAP.height * MAP_PART_SIZE.height) + 2);
	
	public static Point calcCenterLocation(Dimension source, Dimension object){
		return new Point((source.width-object.width)/2, (source.height-object.height)/2);
	}
	public static Point calcFrameLocation(Dimension size){
		return new Point((Toolkit.getDefaultToolkit().getScreenSize().width-size.width)/2, 
				(Toolkit.getDefaultToolkit().getScreenSize().height-size.height)/2);
	}
	public static Point calcPanelLocation(Dimension size){
		return new Point((GAME_FRAME_SIZE.width-size.width)/2, 
				(GAME_FRAME_SIZE.height-size.height)/2);
	}
	public static void resize(){
		GAME_PANEL_SIZE = new Dimension(GAME_FRAME_SIZE.width, (int)(GAME_FRAME_SIZE.height*0.88));
		FORMULA_PANEL_SIZE = new Dimension(GAME_FRAME_SIZE.width, GAME_FRAME_SIZE.height-GAME_PANEL_SIZE.height-20);
	}
	
	public static final String FONT_NAME = "Rockwell";
	public static final String FONT_NAME_2 = "Comic Sans MS";
	public static final String FONT_NAME_3 = "Trebuchet MS";
	//public static final Color COLOR_FONT = new Color(255, 200, 10);
	public static final Color COLOR_FONT = new Color(250, 250, 50);
	public static float SLOMO_FACTOR = 1.0f;
	public static final int TIMER_INTERVAL = 15; //in ms
	public static final float MARIO_ACCELERATION = 30*DEFAULT_BLOCK_SIZE.width; //in pixels / s^2
	public static final float MAX_MOVE_SPEED = 10*DEFAULT_BLOCK_SIZE.width; //in pixels / s
	public static final float MAX_MARIO_MOVE_SPEED = 1.25f*MAX_MOVE_SPEED; //in pixels / s
	public static final float MIN_JUMP_SPEED = 16.5f*DEFAULT_BLOCK_SIZE.height; //initial jump speed in pixels / s
	public static final float MAX_FALLING_SPEED = 20*DEFAULT_BLOCK_SIZE.height; //upper limit for Mario's falling speed in pixels / s
	public static final float GRAVITY = 40*DEFAULT_BLOCK_SIZE.height; //in pixels / s^2
	public static final int ROTATING_TIME = 5000; //in ms
	public static final float TRAMPOLINE_JUMP_SPEED = 25*DEFAULT_BLOCK_SIZE.height; //in pixels / s
	public static final float MINIMAP_SCROLL_SPEED = 500 * DEFAULT_BLOCK_SIZE.width / BLOCK_SIZE_MINIMAP_RATIO; //in pixels / s
	public static int MAP_TRANSPARENCY = 125; //range: [0, 255] from transparent to opaque
	
	public static final int BRICK_SMASH_SCORE = 50;
	public static final int KOOPA_STUN_SCORE = 100;
	public static final int MUSHROOM_EAT_SCORE = 1000;
	public static final int FINISH_SCORE = 2000;
	public static final int FINISH_HEAD_SCORE = 5000;
	public static final int COIN_SCORE = 50;
	
	public static final char AND_1 = '*';
	public static final char AND_2 = '&';
	public static final char OR_1 = '+';
	public static final char OR_2 = '|';
	public static final char NOT_1 = '-';
	public static final char NOT_2 = '!';
	public static final char IMPLICATION_1 = '>';
	public static final char XOR_1 = '^';
	
	public static final char AND = '\u2227';
	public static final char OR = '\u2228';
	public static final char NOT = '\u00AC';
	public static final char IMPLICATION = '\u2192';
	public static final char XOR = '\u2295';
	
	public static GameMode GAME_MODE = GameMode.NORMAL; //default game mode
	
	public static final Map<BlockType, Boolean> typeVisibleMapping = new HashMap<BlockType, Boolean>();
	public static final Map<BlockType, Boolean> typePassableMapping = new HashMap<BlockType, Boolean>();
	
	public enum BlockType{
		BORDER,
		ENTRANCE,
		EMPTY,
		BRICK,
		WALL,
		KOOPA,
		MUSHROOM_BLOCK,
		COIN_BLOCK,
		USED_BLOCK,
		FLAG, FLAG_HEAD,
		LINK,
		LAVA,
		POWER_BLOCK,
		COIN,
		FINISH_GATE,
		LABEL,
		LABEL_LITERAL, //literal in clause: do not display in hardcore mode
		VARIABLE_ASSIGNMENT_POSITIVE,
		VARIABLE_ASSIGNMENT_NEGATIVE,
		VARIABLE_ASSIGNMENT_POSITIVE_LABEL,
		VARIABLE_ASSIGNMENT_NEGATIVE_LABEL,
		ARROW,
		
		VINE, //vine, on which mario can climb
		FIREBALL, //fiery enemy staying still inside door gadgets
		STONE, //stone on chain rotating and harming Mario
		ROTATE_BLOCK,
		TRAMPOLINE,
		TRAMPOLINE_FIXED,
		TRAMPOLINE_DESTINATION,
		
		//codes for other map parts to be created inside other map parts
		DOOR_MAP,
		CROSSOVER_UP_LEFT_MAP,
		CROSSOVER_UP_RIGHT_MAP,
		CROSSOVER_DOWN_LEFT_MAP,
		CROSSOVER_DOWN_RIGHT_MAP
	}
	
	public enum Direction{
		NONE, EAST, WEST, SOUTH, NORTH, HORIZONTAL, VERTICAL, HORIZONTAL_CENTER, VERTICAL_CENTER
	}
}