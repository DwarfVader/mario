package util;

import java.util.HashMap;
import java.util.Map;

import javax.swing.ImageIcon;

public class Language{
	private Language(){}
	
	public enum LanguageCode{
		DE, 
		EN
	}
	
	public static final Map<LanguageCode, Map<String, String>> languageCodeMap = new HashMap<LanguageCode, Map<String, String>>();
	public static LanguageCode chosenLanguage = LanguageCode.EN;
	public static ImageIcon chosenLanguageIcon = ImageLoader.languageENIcon;
	
	public static void initLanguageCodeMap(){
		languageCodeMap.put(LanguageCode.DE, new HashMap<String, String>());
		languageCodeMap.put(LanguageCode.EN, new HashMap<String, String>());
		
		//init German language codes
		Map<String, String> germanCodes = languageCodeMap.get(LanguageCode.DE);
		germanCodes.put("file", "Datei");
		germanCodes.put("restart", "Neustart");
		germanCodes.put("end", "Beenden");
		germanCodes.put("undo", "R\u00FCckg\u00E4ngig");
		germanCodes.put("undo until", "R\u00FCckg\u00E4ngig bis");
		germanCodes.put("window", "Fenster");
		germanCodes.put("fullscreen", "Vollbild");
		germanCodes.put("enter formula", "Formel eingeben");
		germanCodes.put("parse", "Parsen");
		germanCodes.put("start", "Spiel starten");
		germanCodes.put("open", "\u00D6ffnen");
		germanCodes.put("mode", "Modus");
		germanCodes.put("normal", "Normal");
		germanCodes.put("hardcore", "Hardcore");
		germanCodes.put("help", "Hilfe");
		germanCodes.put("show help", "Hilfe anzeigen");
		germanCodes.put("retry", "Neuer Versuch");
		germanCodes.put("next level", "N\u00E4chstes Level");
		germanCodes.put("game won", "Spiel gewonnen! Die Formel ist somit erf\u00FCllbar. Super.");
		germanCodes.put("game lost", "Spiel verloren! Mario erlag seinen Verletzungen. Versuchen Sie es erneut.");
		germanCodes.put("time", "Zeit");
		germanCodes.put("score", "Punkte");
		germanCodes.put("general", "Allgemein");
		germanCodes.put("mechanics", "Mechanik");
		germanCodes.put("formula", "Formel");
		germanCodes.put("controls", "Steuerung");
		germanCodes.put("back", "Zur�ck");
		germanCodes.put("choose help category", "W\u00E4hlen Sie links eine Hilfekategorie aus.");
		germanCodes.put("general help", "Allgemein:\n\n"
				+ "Das Ziel dieses Programms ist es, die Erf�llbarkeit von logischen Formeln durch das Beenden "
				+ "eines Spiels zu zeigen. Dabei wird aus der eingegebenen Formel eine Spielwelt im "
				+ "Super-Mario-World-Stil generiert. W�hrend des Spiels m�ssen Entscheidungen getroffen werden, die die "
				+ "Belegungen der Variablen der Formel symbolisieren. Wenn die Zielstange erreicht wird, ist die "
				+ "eingegebene Formel erf�llbar (durch die gew�hlte Belegung der Variablen).\n\n"
				+ "Im Hauptfenster k�nnen logische Formeln eingegeben werden (siehe Hilfe: Formel). Das Spiel "
				+ "verlangt Formeln in CNF oder QBF. Daher muss die Eingabe (bzw. deren Matrix-Teil bei QBF) "
				+ "in CNF transformiert werden. "
				+ "�ber 'Datei->�ffnen' k�nnen Formeln aus (mehreren) '.cnf'- und '.frm'-Dateien gelesen werden. "
				+ "Auf diese Weise kann eine Serie von Spielwelten gespielt werden. "
				+ "Die CNF-Formel wird unterhalb des Eingabe-Textfeldes angezeigt. Nach Eingabe einer g�ltigen Formel, "
				+ "kann das Spiel gestartet werden. Die Spielwelt wird aus der transformierten Formel "
				+ "generiert.\n\n"
				+ "Nachdem das Spiel startet, wird am unteren Bildschirmrand der momentane Zustand der Formel "
				+ "angezeigt. Wenn der Zustand eines Literal einer Klauseln durch eine Aktion des Spielers "
				+ "ge�ndert wird, �ndert sich die Farbe dieses Literals in der angezeigten Formel nach "
				+ "gr�n oder rot.");
		germanCodes.put("mechanics help", "Spielmechanik:\n\n"
				+ "Der/Die Spieler/in steuert Mario durch ein Labyrinth aus kleinen Bl�cken verschiedener Art. "
				+ "Auf seinem Weg durch die Spielwelt wird Mario Gefahren und Hindernisse �berwinden m�ssen. "
				+ "Diese beschr�nken sich auf Koopas, rotierende Flammen, Ziegelsteine und zu �berwindende H�hen.\n"
				+ "Wenn Mario mit einen Koopa horizontal kollidiert, wird er "
				+ "verletzt. Wenn Mario auf einen Koopa springt, wird Koopa bet�ubt und schl�pft in seinen "
				+ "Panzer. Dadurch wird Koopa unsch�dlich und kann auch horizontal ber�hrt werden, wodurch "
				+ "dieser in die Ber�hrungsrichtung gesto�en wird. Bei horizontalen Ber�hrungen mit "
				+ "schlitternden Panzern wird Mario verletzt. Ein erneuter Sprung auf den schlitternden Panzer "
				+ "stoppt diesen wieder. Wenn Mario von unten gegen einen bestimmten Fragezeichenblock springt, erscheint "
				+ "ein Super-Pilz, der Mario in Super Mario verwandelt. Wenn Super Mario verletzt wird, "
				+ "verwandelt er sich zur�ck in den normalen Mario. Wird Mario im normalen Zustand verletzt, "
				+ "stirbt er und das Spiel muss neu gestartet oder beendet werden. "
				+ "Wenn Super-Mario von unten gegen Ziegelsteine springt, werden diese zerst�rt. "
				+ "Schlitternde Koopas prallen an W�nden ab. Wird dadurch ein "
				+ "Ziegelstein horizontal getroffen, wird dieser zerst�rt. Wenn Mario von einer rotierenden "
				+ "Flamme getroffen wird, wird er verletzt bzw. stirbt. "
				+ "An bestimmten Stellen wird Mario Trampoline vorfinden, mit deren Hilfe er h�her springen "
				+ "kann. Mario kann Trampoline tragen und diese an geeigneten Stellen ablegen, jedoch lassen "
				+ "sich nicht alle Trampoline aufheben. Mario kann nicht mehr als einen Gegenstand gleichzeitig "
				+ "tragen und er kann nicht klettern, wenn er etwas tr�gt. "
				+ "An manchen Stellen gibt es Kletterranken, an denen Mario nach oben oder unten klettern kann.");
		germanCodes.put("formula help", "Formel:\n\n"
				+ "Der Spieler darf beliebige logische Formeln eingeben, die dem folgenden Format entsprechen:\n"
				+ "\tf -> prefix cnf | cnf\n"
				+ "Die Formel besteht also entweder aus einem Prefix-Teil und anschlie�endem Matrix-Teil in CNF (bei QBF) "
				+ "oder nur aus der eigentlichen Formel (bei CNF). Der Prefix muss dem folgenden Format entsprechen:\n"
				+ "\tprefix -> quants ':'\n"
				+ "\tquants -> quants quant | quant\n"
				+ "\tquant -> 'A' vars | 'E' vars\n"
				+ "\tvars -> var | var ',' vars\n"
				+ "\tvar -> [a..zA..Z0..9] | [a..zA..Z0..9] var\n"
				+ "Der Prefix besteht aus einer Reihe quantifizierter Variablen und endet mit einem ':'. "
				+ "Hinter einem Quantor ('A' oder 'E') k�nnen mehrere Variablen genannt werden, durch ',' getrennt, "
				+ "wobei jede Variable ein String aus Buchstaben und Ziffern ist.\n"
				+ "Die Matrix muss dem folgenden Format entsprechen:\n"
				+ "\tcnf -> e\n"
				+ "\te -> e bo e\n"
				+ "\te -> uo e\n"
				+ "\te -> '(' e ')'\n"
				+ "\te -> var\n"
				+ "\tbo -> '&' | '*' | '|' | '+' | '>' | '^'\n"
				+ "\tuo -> '!' | '-'\n"
				+ "Der Matrix-Teil in CNF besteht also aus einem logischen Ausdruck e, der sich "
				+ "aus weiteren Ausdr�cken zusammensetzten kann. Diese Ausdr�cke k�nnen durch bin�re Operatoren "
				+ "verbunden werden, verneint oder geklammert. Ein Ausdruck kann auch eine Variable sein.\n"
				+ "Die Operatoren haben folgende Bedeutungen:\n"
				+ "\t&, *: UND\n"
				+ "\t|, +: ODER\n"
				+ "\t>: IMPLIKATION\n"
				+ "\t^: XOR\n"
				+ "\t!, -: NICHT\n"
				+ "Die Ausdr�cke werden in einer bestimmten Reihenfolge ausgewertet, die durch die Operatoren "
				+ "bestimmt ist: \n"
				+ "\tXOR, IMPLIKATION, ODER, UND, NICHT, '()'\n"
				+ "Dabei hat XOR die niedrigste und '()' als Operator die h�chste Bindung."
				+ "Das bedeutet, dass ein umklammerter Ausdruck isoliert und ausgewertet wird, "
				+ "bevor das Ergebnis dieses Ausdrucks an umgebende, schw�cher bindende Operatoren �bergeben wird.\n"
				+ "Beispiel:\n"
				+ "\t-(a + b * c > d) + e\n"
				+ "Im Programm ist dies folgenderma�en umgesetzt:\n"
				+ "Anfangs wird der gesamte Ausdruck betrachtet und nach dem niedrigst bindenden, freiliegenden "
				+ "Operator gesucht. Freiliegend bedeutet hier, dass der Operator auf 'oberster Ebene' liegt, also "
				+ "nicht innerhalb einer Klammer steht. Im Beispiel ist dies der ODER-Operator. Nun wird der "
				+ "Ausdruck an diesem Operator geteilt. Da es sich im Beispiel um einen bin�ren Operator handelt, "
				+ "wird der bestehende Ausdruck in einen linken und rechten Teil zerlegt. Die einzelnen, kleineren "
				+ "Teilausdr�cke '-(a + b * c > d)' und 'e' werden nun separat ausgewertet.\n"
				+ "In '-(a + b * c > d)' ist der NICHT-Operator der niedrigst bindende freiliegende Operator. Der "
				+ "un�re Operator 'teilt' den Ausdruck nur in einen rechten Teil '(a + b * c > d)', der wiederum "
				+ "isoliert betrachtet und am IMPLIKATION-Operator geteilt wird. Dieser rekursive Vorgang "
				+ "h�lt erst, sobald ein Teilausdruck nur mehr aus einer alleinstehenden Variable besteht. "
				+ "Dann kann das Ergebnis des gesamten Ausdrucks, ausgehend von den Belegungen der einzelnen "
				+ "Variablen, von 'unten herauf' ermittelt werden, indem die Operatoren (an denen der Ausdruck "
				+ "geteilt wurde) aus den entsprechenden Teilergebnissen ihrer Teilausdr�cke wiederum ihr "
				+ "(Teil-)Ergbenis berechnen und dieses nach oben weiterreichen, bis das Ergebnis des gesamten "
				+ "Ausdrucks ermittelt wurde.\n\n"
				+ "Das Spiel ben�tigt Formeln im CNF-Format. Daher wird die eingegebene Formel (sofern sie "
				+ "g�ltig ist) transformiert. Die generierte CNF-Formel wird im Hauptfenster "
				+ "(unterhalb der Formeleingabe) angezeigt. Die Spielwelt wird aus dieser CNF-Formel generiert.");
		germanCodes.put("controls help", "Tastenbelegung:\n\n"
				+ "Steuerung:\n"
				+ "A: nach links bewegen\n"
				+ "D: nach rechts bewegen\n"
				+ "S: hocken / Ranke runterklettern\n"
				+ "W: Ranke hochklettern\n"
				+ "Leertaste: Springen\n"
				+ "F: Trampolin aufheben/fallen lassen\n"
				+ "Esc: Spiel/Programm beenden\n\n"
				+ "Karte:\n"
				+ "M: Karte anzeigen/verstecken\n"
				+ "Pfeiltasten: auf der Karte navigieren\n"
				+ ",: Kartentransparenz verringern\n"
				+ ".: Kartentransparenz erh�hen\n\n"
				+ "Zeitlupe:\n"
				+ "1-9: Zeitlupe/-raffer einstellen\n"
				+ "0: Zeitlupe zur�cksetzen\n"
				+ "+: Zeitraffer erh�hen\n"
				+ "-: Zeitlupe erh�hen\n\n"
				+ "Cheats:\n"
				+ "F6: Unverwundbarkeit ein/aus\n"
				+ "F7: Mehrfachsprung ein/aus\n"
				+ "F8: Kollision ein/aus");
		
		//init English language codes
		Map<String, String> englishCodes = languageCodeMap.get(LanguageCode.EN);
		englishCodes.put("file", "File");
		englishCodes.put("restart", "Restart");
		englishCodes.put("end", "End");
		englishCodes.put("undo", "Undo");
		englishCodes.put("undo until", "Undo until");
		englishCodes.put("window", "Window");
		englishCodes.put("fullscreen", "Fullscreen");
		englishCodes.put("enter formula", "Enter formula");
		englishCodes.put("parse", "Parse");
		englishCodes.put("start", "Start game");
		englishCodes.put("open", "Open");
		englishCodes.put("mode", "Mode");
		englishCodes.put("normal", "Normal");
		englishCodes.put("hardcore", "Hardcore");
		englishCodes.put("help", "Help");
		englishCodes.put("show help", "Show help");
		englishCodes.put("retry", "Retry");
		englishCodes.put("next level", "Next level");
		englishCodes.put("game won", "Game won! The given formula is satisfiable. Great!");
		englishCodes.put("game lost", "Game lost! Mario died of his injuries. Try again!");
		englishCodes.put("time", "Time");
		englishCodes.put("score", "Score");
		englishCodes.put("general", "General");
		englishCodes.put("mechanics", "Mechanics");
		englishCodes.put("formula", "Formula");
		englishCodes.put("controls", "Controls");
		englishCodes.put("back", "Back");
		englishCodes.put("choose help category", "Choose a category on the left.");
		englishCodes.put("general help", "General:\n\n"
				+ "This program aims at showing satisfiability of logic formulas by playing and beating a game. "
				+ "Given an input formula, a game world in the style of Super Mario World is generated. "
				+ "While playing the game, the player assigns the represented variables by deciding which "
				+ "of two paths to follow. On this paths, the player performs actions that unlock regions of "
				+ "the game such that Mario can pass the region at a later point, which simulates the "
				+ "satisfaction of clauses of the formula. If the finish flag can be reached, the formula "
				+ "is satisfiable by the chosen variable assignment.\n\n"
				+ "The main window allows to enter formulas (refer to Help -> Formula). The game accepts "
				+ "CNF and QBF formulas. Therefore the input (resp. its matrix part in the case of QBF) has "
				+ "to be transformed in CNF. "
				+ "Via 'File->Open', formulas can be read from (multiple) '.cnf' or '.frm' files. "
				+ "This way, a series of game worlds can be played. "
				+ "The resulting formula is displayed below the input text area. "
				+ "If a valid formula has been entered, the game can be started. The game world is going to "
				+ "be created based on the transformed formula. \n\n"
				+ "After the game started, the current state of the formula is displayed at the bottom of "
				+ "the screen. If the state of a literal in a clause gets changed by performing an action, "
				+ "the color of the literal in the displayed formula changes to green or red.");
		englishCodes.put("mechanics help", "Game mechanics:\n\n"
				+ "The player moves Mario through a maze of small blocks of different kinds. On his way "
				+ "through the game world, Mario will have to overcome threats and obstacles. "
				+ "These occur in the form of Koopas, rotating firebars, blocking bricks and heights.\n"
				+ "If Mario collides horizontally with a Koopa, he gets hurt. If he jumps on it, Koopa gets "
				+ "stunned and hides in his shell, making Koopa harmless. When horizontally touching a harmless "
				+ "Koopa shell, it gets kicked and starts sliding. Getting hit by a sliding shell hurts Mario. "
				+ "Jumping on a sliding shell stops it. "
				+ "If Mario jumps against certain question-mark blocks from below, Super-mushrooms will spawn "
				+ "that turn Mario into Super Mario upon collision. If Super Mario gets hurt, he turns back "
				+ "into normal Mario. If normal Mario gets hurt, he dies and the game has to be restarted or ended. "
				+ "If Super Mario jumps against bricks from below, those get destroyed. "
				+ "Sliding Koopa shells reflect from walls. If they hit bricks, those get destroyed. "
				+ "If Mario gets hit by a rotating firebar, he gets hurt resp. dies. "
				+ "On certain places in the game, Mario will find trampolines which he can use to jump higher. "
				+ "Mario can grab and carry trampolines and drop them at suitable locations. Though, not all "
				+ "trampolines can be carried and Mario can not carry more than one item at a time. "
				+ "Mario can not climb while carrying an item. "
				+ "At some locations vines are placed, allowing Mario to climb up or down.");
		englishCodes.put("formula help", "Formula:\n\n"
				+ "The player may enter arbitrary logic formulas, conforming with the following format:\n"
				+ "\tf -> prefix cnf | cnf\n"
				+ "The formula consists of either a prefix and following matrix part in CNF (for QBF formulas) "
				+ "or only the actual formula (for CNF formulas). The prefix has to conform with the following format:\n"
				+ "\tprefix -> quants ':'\n"
				+ "\tquants -> quants quant | quant\n"
				+ "\tquant -> 'A' vars | 'E' vars\n"
				+ "\tvars -> var | var ',' vars\n"
				+ "\tvar -> [a..zA..Z0..9] | [a..zA..Z0..9] var\n"
				+ "The prefix consists of a row of quantified variables and ends with a ':'. "
				+ "Next to a quantifier ('A' or 'E'), multiple variables may be specified, separated by ',' with "
				+ "each variable being a string of letters or digits.\n"
				+ "The matrix has to conform with the following format:\n"
				+ "\tcnf -> e\n"
				+ "\te -> e bo e\n"
				+ "\te -> uo e\n"
				+ "\te -> '(' e ')'\n"
				+ "\te -> var\n"
				+ "\tbo -> '&' | '*' | '|' | '+' | '>' | '^'\n"
				+ "\tuo -> '!' | '-'\n"
				+ "The matrix part in CNF consists of a logic expression e, which can be composed of further expressions. "
				+ "This expressions can be connected by binary operators, be negated or surrounded by parentheses. "
				+ "Expressions can resolve to variables as well.\n"
				+ "The operators have the following meanings:\n"
				+ "\t&, *: AND\n"
				+ "\t|, +: OR\n"
				+ "\t>: IMPLICATION\n"
				+ "\t^: XOR\n"
				+ "\t!, -: NOT\n"
				+ "The expressions have to be evaluated in a certain order, defined by the operators:\n"
				+ "\tXOR, IMPLICATION, OR, AND, NOT, '()'\n"
				+ "The XOR has the weakest, the '()' has the strongest binding. This means that an expression within "
				+ "parentheses gets isolated and evaluated such that its result is passed to surrounding, "
				+ "weaker binding operators.\n"
				+ "Example:\n"
				+ "\t-(a + b * c > d) + e\n"
				+ "The program handles this as follows:\n"
				+ "In the beginning, the whole expression is considered and the weakest binding, free operator "
				+ "is searched. Free means that the operator is lying on the 'top layer', so it is not "
				+ "surrounded by parentheses. In the example this is the OR operator. Now the expression "
				+ "gets split around that operator. Since it is a binary operator, this leads to left and right "
				+ "sub-expressions. The single, smaller sub-expressions '-(a + b * c > d)' and 'e' are now "
				+ "evaluated separately.\n"
				+ "In '-(a + b * c > d)', NOT is the weakest binding free operator. The unary operator 'splits' "
				+ "the expression into a right part '(a + b * c > d)' which again gets isolated and split "
				+ "around the IMPLICATION operator. This recursive process stops when a sub-expression consists "
				+ "of a single variable. Then the result of the whole expression can be calculated from "
				+ "bottom to top based on the assignments of the variables. This is done by applying the "
				+ "operator (on which an expression has been split) to the results of the sub-expressions and "
				+ "passing the resulting value to the top. The process ends as the top operator calculates "
				+ "the resulting value of the whole expression.\n\n"
				+ "The game needs the (matrix part of) formulas to be in CNF. Therefore the input formula "
				+ "gets transformed into CNF if a valid expression could be parsed from the input. "
				+ "The generated formula is displayed in the main window below the input text area. "
				+ "The game world is going to be created based on that CNF formula/matrix part.");
		englishCodes.put("controls help", "Key assignment:\n\n"
				+ "Controls:\n"
				+ "A: move left\n"
				+ "D: move right\n"
				+ "S: crouch / climb down vine\n"
				+ "W: climb up vine\n"
				+ "Space: jump\n"
				+ "F: grab/drop trampoline\n"
				+ "Esc: end game/program\n\n"
				+ "Minimap:\n"
				+ "M: show/hide minimap\n"
				+ "Arrow keys: navigate in minimap\n"
				+ ",: decrease map transparency\n"
				+ ".: increase map transparency\n\n"
				+ "Slow-motion:\n"
				+ "1-9: set slow-/fast-motion\n"
				+ "0: reset slow-motion\n"
				+ "+: increase fast-motion\n"
				+ "-: increase slow-motion\n\n"
				+ "Cheats:\n"
				+ "F6: invincibility on/off\n"
				+ "F7: multi-jump on/off\n"
				+ "F8: collision on/off");
	}
	
	public static void setLanguage(LanguageCode language){
		chosenLanguage = language;
		switch(language){
		case DE:
			chosenLanguageIcon = ImageLoader.languageDEIcon;
			break;
		case EN:
			chosenLanguageIcon = ImageLoader.languageENIcon;
			break;
		default:
			chosenLanguageIcon = ImageLoader.dummyImageIcon;
		}
	}
	
	public static String getString(String code){
		String string = languageCodeMap.get(chosenLanguage).get(code);
		if(string == null)
			string = "dummy";
		
		return string;
	}
}