package util;

public class MyInteger{
	public int value;
	
	public MyInteger(MyInteger other){
		this(other.value);
	}
	public MyInteger(int value){
		this.value = value;
	}
	
	public void setValue(int value){
		this.value = value;
	}
}