package util;

public enum GameMode{
	NORMAL, 
	TEST, 
	HARDCORE
}