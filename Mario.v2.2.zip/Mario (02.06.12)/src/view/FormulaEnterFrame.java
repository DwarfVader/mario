package view;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;

import util.Constants;
import util.ImageLoader;
import util.Language;

public class FormulaEnterFrame extends JFrame{
	private static final long serialVersionUID = 6312513009408039088L;
	
	private Container contentPane;
	private JScrollPane scrollPane;
	private JScrollPane infoScrollPane;
	private JTextArea formulaTextArea;
	private JTextArea infoTextArea;
	private JButton btnParse;
	private JButton btnStartGame;
	private JButton btnEnd;
	private JMenu menuHelp;
	private JMenuItem menuItemOpen;
	private JMenuItem menuItemEnd;
	private JMenuItem menuItemShowHelp;
	private JMenu menuGameMode;
	private JMenuItem menuItemNormalMode;
	private JMenuItem menuItemTestMode;
	private JMenuItem menuItemHardcoreMode;
	private JMenu menuLanguage;
	private JMenuItem menuItemGerman;
	private JMenuItem menuItemEnglish;

	private JMenu menuFile;
	
	public FormulaEnterFrame(){
		setResizable(false);
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		setSize(new Dimension(681, 411));
		setLocation(Constants.calcFrameLocation(getSize()));
		
		getContentPane().setFont(new Font(Constants.FONT_NAME, Font.PLAIN, 11));
		//setUndecorated(true);
		setVisible(true);
		setTitle("Super Formula World");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		this.contentPane = getContentPane();
		this.contentPane.setBackground(Color.DARK_GRAY);
		this.contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setFocusable(false);
		scrollPane.setFont(new Font(Constants.FONT_NAME, Font.PLAIN, 24));
		scrollPane.setViewportBorder(new TitledBorder(null, Language.getString("enter formula"), TitledBorder.LEADING, TitledBorder.TOP, null, null));
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 11, 650, 150);
		getContentPane().add(scrollPane);
		
		formulaTextArea = new JTextArea();
		formulaTextArea.setBackground(SystemColor.control);
		formulaTextArea.addKeyListener(new KeyAdapter(){
			String oldFormula = "";
			
			@Override
			public void keyPressed(KeyEvent e){
				//pass key event upwards until accepted
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
					for(KeyListener keyListener : FormulaEnterFrame.this.getKeyListeners())
						keyListener.keyPressed(e);
				}
				
				//if formula changed, show parse button and hide start button
				oldFormula = formulaTextArea.getText();
				System.out.println(formulaTextArea.getText());
			}
			
			@Override
			public void keyReleased(KeyEvent e){
				//text changed
				if(oldFormula.compareToIgnoreCase(formulaTextArea.getText()) != 0){
					btnParse.setVisible(true);
					btnStartGame.setVisible(false);
				}
			}
		});
		formulaTextArea.setFont(new Font(Constants.FONT_NAME, Font.PLAIN, 24));
		formulaTextArea.setRows(1);
		//formulaTextArea.setText("-s + e * p + p > l");
		formulaTextArea.setText("As: -s + e");
		scrollPane.setViewportView(formulaTextArea);
		
		btnParse = new JButton(Language.getString("parse"));
		btnParse.setFont(new Font(Constants.FONT_NAME, Font.PLAIN, 24));
		btnParse.setFocusable(false);
		btnParse.setBounds(10, 313, 250, 41);
		getContentPane().add(btnParse);
		
		btnStartGame = new JButton(Language.getString("start"));
		btnStartGame.setFocusable(false);
		btnStartGame.setFont(new Font(Constants.FONT_NAME, Font.PLAIN, 24));
		btnStartGame.setBounds(10, 313, 250, 41);
		getContentPane().add(btnStartGame);
		
		btnEnd = new JButton(Language.getString("end"));
		btnEnd.setFocusable(false);
		btnEnd.setBounds(410, 313, 250, 41);
		btnEnd.setFont(new Font(Constants.FONT_NAME, Font.PLAIN, 24));
		getContentPane().add(btnEnd);
		
		infoScrollPane = new JScrollPane();
		infoScrollPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		infoScrollPane.setBackground(Color.DARK_GRAY);
		infoScrollPane.setFocusable(false);
		infoScrollPane.setFont(new Font(Constants.FONT_NAME, Font.PLAIN, 24));
		infoScrollPane.setBounds(10, 172, 650, 130);
		getContentPane().add(infoScrollPane);
		
		infoTextArea = new JTextArea();
		infoTextArea.setLineWrap(true);
		infoTextArea.setWrapStyleWord(true);
		infoTextArea.setEditable(false);
		infoTextArea.setBackground(Color.DARK_GRAY);
		infoTextArea.setFont(new Font(Constants.FONT_NAME, Font.PLAIN, 24));
		infoScrollPane.setViewportView(infoTextArea);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setFocusable(false);
		setJMenuBar(menuBar);
		
		menuFile = new JMenu(Language.getString("file"));
		menuFile.setFocusable(false);
		//menuFile.setActionCommand(Language.getString("file")); //TODO: <- What for?
		menuBar.add(menuFile);

		menuItemOpen = new JMenuItem(Language.getString("open"));
		menuFile.add(menuItemOpen);
		
		menuItemEnd = new JMenuItem(Language.getString("end"));
		menuFile.add(menuItemEnd);
		
		menuGameMode = new JMenu(Language.getString("mode"));
		menuBar.add(menuGameMode);
		
		menuItemNormalMode = new JMenuItem(Language.getString("normal"));
		menuGameMode.add(menuItemNormalMode);
		
		menuItemHardcoreMode = new JMenuItem(Language.getString("hardcore"));
		menuGameMode.add(menuItemHardcoreMode);
		
		menuHelp = new JMenu(Language.getString("help"));
		menuHelp.setFocusable(false);
		menuBar.add(menuHelp);
		
		menuItemShowHelp = new JMenuItem(Language.getString("show help"));
		menuHelp.add(menuItemShowHelp);
		
		menuLanguage = new JMenu("");
		menuLanguage.setIcon(ImageLoader.languageENIcon);
		menuLanguage.setFocusable(false);
		menuBar.add(menuLanguage);
		
		menuItemGerman = new JMenuItem("DE");
		menuItemGerman.setIcon(ImageLoader.languageDEIcon);
		menuLanguage.add(menuItemGerman);
		
		menuItemEnglish = new JMenuItem("EN");
		menuItemEnglish.setIcon(ImageLoader.languageENIcon);
		menuLanguage.add(menuItemEnglish);
	}
	
	public void languageChanged(){
		((TitledBorder)scrollPane.getViewportBorder()).setTitle(Language.getString("enter formula"));
		btnParse.setText(Language.getString("parse"));
		btnStartGame.setText(Language.getString("start"));
		btnEnd.setText(Language.getString("end"));
		menuFile.setText(Language.getString("file"));
		menuItemEnd.setText(Language.getString("end"));
		menuItemOpen.setText(Language.getString("open"));
		menuGameMode.setText(Language.getString("mode"));
		menuItemNormalMode.setText(Language.getString("normal"));
		menuItemHardcoreMode.setText(Language.getString("hardcore"));
		menuHelp.setText(Language.getString("help"));
		menuItemShowHelp.setText(Language.getString("show help"));
		menuLanguage.setIcon(Language.chosenLanguageIcon);
	}
	
	public JButton getParseButton(){
		return this.btnParse;
	}
	public JButton getStartGameButton(){
		return this.btnStartGame;
	}
	public JButton getEndButton(){
		return this.btnEnd;
	}
	public JTextArea getFormulaTextArea(){
		return this.formulaTextArea;
	}
	public JTextArea getInfoTextArea(){
		return this.infoTextArea;
	}
	public JMenuItem getMenuItemShowHelp(){
		return this.menuItemShowHelp;
	}
	public JMenuItem getMenuItemOpen(){
		return this.menuItemOpen;
	}
	public JMenuItem getMenuItemEnd(){
		return this.menuItemEnd;
	}
	public JMenuItem getMenuItemNormalMode(){
		return this.menuItemNormalMode;
	}
	public JMenuItem getMenuItemTestMode(){
		return this.menuItemTestMode;
	}
	public JMenuItem getMenuItemHardcoreMode(){
		return this.menuItemHardcoreMode;
	}
	public JMenuItem getMenuItemGermanLanguage(){
		return this.menuItemGerman;
	}
	public JMenuItem getMenuItemEnglishLanguage(){
		return this.menuItemEnglish;
	}
}