package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.util.List;

import javax.swing.JPanel;

import model.Coin;
import model.FinishGate;
import model.Game;
import model.MapPart;
import model.StoneChainLink;
import model.animation.BackgroundLayer;
import model.blocks.BlockHolder;
import model.blocks.LabelBlock;
import util.Collidable;
import util.Constants;
import util.GameMode;
import util.ImageLoader;
import util.Language;

public class GamePanel extends JPanel{
	private static final long serialVersionUID = 1860979716621182121L;
	
	private GameOverPanel gameOverPanel;
	private Game game;
	
	private Font font1;
	private Font font2;
	
	public GamePanel(){
		this.font1 = new Font(Constants.FONT_NAME, Font.PLAIN, 36);
		this.font2 = new Font(Constants.FONT_NAME, Font.PLAIN, 30);
		setFont(this.font1);
		
		setDoubleBuffered(false);
		setLayout(null);
		setSize(Constants.GAME_PANEL_SIZE);
		
		//ugly game over panel stuff... needed to put it here because of flickering
		this.gameOverPanel = new GameOverPanel();
		this.gameOverPanel.setLocation(Constants.calcPanelLocation(this.gameOverPanel.getSize()));
		this.gameOverPanel.setVisible(false);
		add(this.gameOverPanel, 0);
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		MapPart map;
		if(this.game != null && this.game.isCreated()){
			if(!this.game.isShowMinimap() || Constants.MAP_TRANSPARENCY < 255){ //do not render if minimap is opaque
				Point scroll = calcScroll(this.game.getCurMap());
				
				//draw background
				if(this.game.getBackground() != null)
					for(int l = this.game.getBackground().getLayers().size(); l >= 0; l--){
						BackgroundLayer layer = this.game.getBackground().getLayer(l);
						if(layer != null){
							for(int i = 0; i < layer.getSize().width; i++)
								for(int j = 0; j < layer.getSize().height; j++){
									g2.drawImage(layer.getImage(), 
											(i-1) * layer.getImageSize().width + layer.calcOffset(scroll, this.game.getCurMap()).getX(), 
											(j-1) * layer.getImageSize().height + layer.calcOffset(scroll, this.game.getCurMap()).getY(), null);
								}
						}
					}
				
				//render current mapPart and its neighbors
				Dimension numMapsToRender = Constants.NUM_MAPS_TO_RENDER;
				//correct width and height by -1 to keep additional map part on the right if even number of maps
				Point offset = new Point(-(numMapsToRender.width-1)/2, -(numMapsToRender.height-1)/2);
				if(this.game.getCurMap().getIndex().x + offset.x < 0)
					offset.x = -this.game.getCurMap().getIndex().x;
				else if(this.game.getCurMap().getIndex().x + offset.x + numMapsToRender.width >= this.game.getNumMapParts().width)
					offset.x = this.game.getNumMapParts().width - this.game.getCurMap().getIndex().x - numMapsToRender.width;
				if(this.game.getCurMap().getIndex().y + offset.y < 0)
					offset.y = -this.game.getCurMap().getIndex().y;
				else if(this.game.getCurMap().getIndex().y + offset.y + numMapsToRender.height >= this.game.getNumMapParts().height)
					offset.y = this.game.getNumMapParts().height - this.game.getCurMap().getIndex().y - numMapsToRender.height;
				
				for(int ii = 0 + offset.x; ii < numMapsToRender.width + offset.x; ii++)
					for(int jj = 0 + offset.y; jj < numMapsToRender.height + offset.y; jj++){
						map = this.game.getMap(this.game.getCurMap().getIndex().x + ii, this.game.getCurMap().getIndex().y + jj);
						if(map == null)
							continue; //mapPart not existing
						
						//draw all blocks
						BlockHolder blockHolders[][] = map.getBlockHolders();
						int i, j;
						//g2.setColor(Color.RED);
						for(i = 0; i < Constants.MAP_PART_SIZE.width; i++)
							for(j = 0; j < Constants.MAP_PART_SIZE.height; j++){
								//draw image, if block is visible
								if(Constants.typeVisibleMapping.get(blockHolders[i][j].getBlock().getType()) && 
										blockHolders[i][j].getBlock().getImage() != null)
									g2.drawImage(blockHolders[i][j].getBlock().getImage(), 
											blockHolders[i][j].getLocation().getX() + scroll.x + 
											ii * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width, 
											blockHolders[i][j].getLocation().getY() + scroll.y + 
											jj * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height, 
											null);
								if(blockHolders[i][j].getBlock() instanceof LabelBlock && 
										((LabelBlock)blockHolders[i][j].getBlock()).getLabel() != null && 
										(Constants.GAME_MODE != GameMode.HARDCORE || 
										!((LabelBlock)blockHolders[i][j].getBlock()).isLiteralLabel())){
									g2.setFont(this.font2);
									g2.setColor(Color.WHITE);
									g2.drawString(((LabelBlock)blockHolders[i][j].getBlock()).getLabel(), 
											blockHolders[i][j].getLocation().getX() + scroll.x + Constants.BLOCK_SIZE.width + 
											ii * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width - 
											getFontMetrics(this.font2).stringWidth(
											((LabelBlock)blockHolders[i][j].getBlock()).getLabel())/2, 
											blockHolders[i][j].getLocation().getY() + scroll.y + 
											jj * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height + 
											(int)(this.font2.getSize()*0.85));
								}
							}
						
						//draw flag
						if(this.game.getFlag() != null && this.game.getFlag().getMap() == map){
							g2.drawImage(ImageLoader.flagImage, 
									this.game.getFlag().getLocation().getX() + scroll.x + 
									ii * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width + 
									(Constants.BLOCK_SIZE.width*4/5 - Constants.FLAG_SIZE.width)/2 - Constants.BLOCK_SIZE.width*4/5, 
									this.game.getFlag().getLocation().getY() + scroll.y + 
									jj * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height, 
									null);
						}
						
						//draw coins
						for(Coin coin : this.game.getCoins())
							if(coin.getCurMap() == map)
								g2.drawImage(coin.getImage(), 
										coin.getLocation().getX() + scroll.x + 
										ii * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width, 
										coin.getLocation().getY() + scroll.y + 
										jj * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height, 
										null);
						
						//draw finish gate
						FinishGate finishGate = this.game.getFinishGate();
						if(finishGate != null && finishGate.getMap() == map)
							g2.drawImage(finishGate.getImage(), finishGate.getRenderLocation().getX() + scroll.x + 
									(finishGate.getMap().getIndex().x - this.game.getCurMap().getIndex().x) * 
									Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width, 
									finishGate.getRenderLocation().getY() + scroll.y + 
									(finishGate.getMap().getIndex().y - this.game.getCurMap().getIndex().y) * 
									Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height, 
									null);
					}
				
				//separate fireballs and movables because of possible overlapping by later rendered map parts
				for(int ii = 0 + offset.x; ii < numMapsToRender.width + offset.x; ii++)
					for(int jj = 0 + offset.y; jj < numMapsToRender.height + offset.y; jj++){
						map = this.game.getMap(this.game.getCurMap().getIndex().x + ii, this.game.getCurMap().getIndex().y + jj);
						if(map == null)
							continue; //mapPart not existing
						
						//draw movables: Mario, Koopas, mushrooms and trampolines
						/*for(Movable movable : game.getMovables())
							if(movable.getCurMap() == map) //movable is placed on neighboring map part
								g2.drawImage(movable.getImage(), 
										movable.getLocation().getX() + scroll.x + 
										ii * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width, 
										movable.getLocation().getY() - movable.getImage().getHeight(null) + scroll.y + 
										jj * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height, 
										null);*/
						
						//draw movables: Mario, Koopas, mushrooms and trampolines
						for(Collidable collidable : game.getCollidables())
							if(collidable.getCurMap() == map) //movable is placed on neighboring map part
								g2.drawImage(collidable.getImage(), 
										collidable.getCollisionLocation().getX() + scroll.x + 
										ii * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width, 
										collidable.getCollisionLocation().getY() + scroll.y + 
										jj * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height, 
										null);
					}
				
				//separate stone chains from static world but draw after movables
				for(int ii = 0 + offset.x; ii < numMapsToRender.width + offset.x; ii++)
					for(int jj = 0 + offset.y; jj < numMapsToRender.height + offset.y; jj++){
						map = this.game.getMap(this.game.getCurMap().getIndex().x + ii, this.game.getCurMap().getIndex().y + jj);
						if(map == null)
							continue; //mapPart not existing
						
						//draw stone chains
						for(StoneChainLink stoneChainLink : game.getStoneChainLinksInMapPart(map.getIndex().x, map.getIndex().y))
							g2.drawImage(stoneChainLink.getImage(), stoneChainLink.getCollisionLocation().getX() + scroll.x + 
									ii * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width, 
									stoneChainLink.getCollisionLocation().getY() + scroll.y + 
									jj * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height, null);
					}
				
				//draw score and time
				g2.setFont(this.font1);
				g2.setColor(Constants.COLOR_FONT);
				g2.drawString(Language.getString("time") + ": " + this.game.getTime(), 20, getFontMetrics(this.font1).getHeight() - 
						getFontMetrics(this.font1).getDescent());
				g2.drawString(Language.getString("score") + ": " + this.game.getScore(), getSize().width - 
						(int)getFontMetrics(this.font1).getStringBounds(Language.getString("score") + ": " + 
						this.game.getScore(), g).getWidth() - 20, 
						getFontMetrics(this.font1).getHeight() - getFontMetrics(this.font1).getDescent());
				
				//draw active cheat icons
				List<Image> activeCheatImages = this.game.getMario().getActiveCheatImages();
				int xOffset = (getSize().width - activeCheatImages.size()*Constants.BLOCK_SIZE.width) / 2;
				for(int i = 0; i < activeCheatImages.size(); i++)
					g2.drawImage(activeCheatImages.get(i), xOffset + i * Constants.BLOCK_SIZE.width, 10, null);
			}
			
			if(this.game.isShowMinimap()){
				g2.setColor(new Color(60, 60, 60, Constants.MAP_TRANSPARENCY));
				g2.fillRect(0, 0, getSize().width, getSize().height);
				
				Point scroll = new Point((int)(getSize().width/2 - Constants.BLOCK_SIZE_MINIMAP.width/2 + 
						this.game.getMinimapScroll().x.value/Constants.BLOCK_SIZE_MINIMAP_RATIO), 
						(int)(getSize().height/2 + 
						this.game.getMinimapScroll().y.value/Constants.BLOCK_SIZE_MINIMAP_RATIO));
				Dimension numMapsToRender = Constants.NUM_MAPS_TO_RENDER_MINIMAP;
				Point offset = new Point(-numMapsToRender.width/2, -numMapsToRender.height/2);
				
				for(int ii = offset.x; ii < numMapsToRender.width + offset.x; ii++)
					for(int jj = offset.y; jj < numMapsToRender.height + offset.y; jj++){
						map = this.game.getMap(this.game.getMinimapOriginScrollIndex().x + ii, 
								this.game.getMinimapOriginScrollIndex().y + jj);
						if(map == null)
							continue; //mapPart not existing
						
						//draw all blocks
						BlockHolder blockHolders[][] = map.getBlockHolders();
						int i, j;
						for(i = 0; i < Constants.MAP_PART_SIZE.width; i++)
							for(j = 0; j < Constants.MAP_PART_SIZE.height; j++){
								if(Constants.typeVisibleMapping.get(blockHolders[i][j].getBlock().getType()) && 
										blockHolders[i][j].getBlock().getImage() != null)
									g2.drawImage(ImageLoader.getBlockImageSmall(blockHolders[i][j].getBlock().getType()), 
											i * Constants.BLOCK_SIZE_MINIMAP.width + scroll.x + 
											ii * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE_MINIMAP.width, 
											j * Constants.BLOCK_SIZE_MINIMAP.height + scroll.y + 
											jj * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE_MINIMAP.height, 
											null);
							}
						
						//draw Mario
						if(this.game.getMario().getCurMap() == map){
							g2.setColor(Color.RED);
							g2.fillRect(this.game.getMario().getLocation().getX()/Constants.BLOCK_SIZE_MINIMAP_RATIO + scroll.x + 
									ii * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE_MINIMAP.width, 
									this.game.getMario().getLocation().getY()/Constants.BLOCK_SIZE_MINIMAP_RATIO - 
									Constants.BLOCK_SIZE_MINIMAP.height + scroll.y + 
									jj * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE_MINIMAP.height, 
									Constants.BLOCK_SIZE_MINIMAP.width, Constants.BLOCK_SIZE_MINIMAP.height);
						}
					}
			}
		}
	}
	private Point calcScroll(MapPart curMap){ //TODO
		double scrollX = (double)Constants.GAME_PANEL_SIZE.width/2 - 
				this.game.getMario().getLocation().x.value - Constants.BLOCK_SIZE.width/2; //distance to horizontal center
		double scrollY = (double)Constants.GAME_PANEL_SIZE.height/2 - 
				this.game.getMario().getLocation().y.value; //distance to vertical center
		
		/* Leftmost block moved by scroll value inside screen: Not good, adjust scroll value! */
		if(-curMap.getIndex().x * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width + scrollX > 0)
			scrollX = curMap.getIndex().x * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
		else if(this.game.getMap(this.game.getNumMapParts().width-1, 0).getBlockHolder( //check last block in last map 
				(this.game.getGameSize().width - 1) % Constants.MAP_PART_SIZE.width, 0).getLocation().x.value + 
				Constants.BLOCK_SIZE.width + //plus width of that last block
				(this.game.getNumMapParts().width-1 - curMap.getIndex().x) * //consider map parts in between
				Constants.MAP_PART_SIZE.width*Constants.BLOCK_SIZE.width + scrollX < Constants.GAME_PANEL_SIZE.width)
			scrollX = Constants.GAME_PANEL_SIZE.width - 
					(this.game.getMap(this.game.getNumMapParts().width-1, 0).getBlockHolder(
					(this.game.getGameSize().width - 1) % Constants.MAP_PART_SIZE.width, 0).getLocation().x.value + 
					Constants.BLOCK_SIZE.width + 
					(this.game.getNumMapParts().width-1 - curMap.getIndex().x) * //need to correct location in case that...
					Constants.MAP_PART_SIZE.width*Constants.BLOCK_SIZE.width); //... curMap is not the last one
		
		if(-curMap.getIndex().y * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height + scrollY > 0)
			scrollY = curMap.getIndex().y * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height;
		else if(this.game.getMap(0, this.game.getNumMapParts().height-1).getBlockHolder(0, //check last block in last map 
				(this.game.getGameSize().height - 1) % Constants.MAP_PART_SIZE.height).getLocation().y.value + 
				Constants.BLOCK_SIZE.height + //plus height of that last block
				(this.game.getNumMapParts().height-1 - curMap.getIndex().y) * //consider map parts in between 
				Constants.MAP_PART_SIZE.height*Constants.BLOCK_SIZE.height + scrollY < Constants.GAME_PANEL_SIZE.height)
			scrollY = Constants.GAME_PANEL_SIZE.height - 
					(this.game.getMap(0, this.game.getNumMapParts().height-1).getBlockHolder(0, 
					(this.game.getGameSize().height - 1) % Constants.MAP_PART_SIZE.height).getLocation().y.value + 
					Constants.BLOCK_SIZE.height + 
					(this.game.getNumMapParts().height-1 - curMap.getIndex().y) * //need to correct location in case that...
					Constants.MAP_PART_SIZE.height*Constants.BLOCK_SIZE.height); //... curMap is not the last one
		
		return new Point((int)scrollX, (int)scrollY);
	}
	
	public void resize(){
		setSize(Constants.GAME_PANEL_SIZE);
		setPreferredSize(getSize());
		getGameOverPanel().resize();
		this.font1 = new Font(Constants.FONT_NAME_2, Font.PLAIN, Constants.BLOCK_SIZE.width);
		this.font2 = new Font(Constants.FONT_NAME_2, Font.PLAIN, (int)(Constants.BLOCK_SIZE.width*0.8));
		setFont(this.font1);
	}
	
	public void setGame(Game game){
		this.game = game;
		this.gameOverPanel.setGame(game);
	}
	
	public GameOverPanel getGameOverPanel(){
		return this.gameOverPanel;
	}
}