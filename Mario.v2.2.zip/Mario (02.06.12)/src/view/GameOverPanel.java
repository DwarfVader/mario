package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;

import model.Game;
import util.Constants;
import util.GameState;
import util.Language;

public class GameOverPanel extends JPanel{
	private static final long serialVersionUID = 271638080696291760L;
	
	private Game game;
	
	private JButton btnNextLvl;
	private JButton btnRestart;
	private JButton btnEnd;
	private JTextArea textAreaInfo;
	private JScrollPane scrollPane;
	private Font font;
	
	public GameOverPanel(){
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		setSize(new Dimension(420, 240));
		setLocation(Constants.calcFrameLocation(getSize()));
		setBorder(new LineBorder(new Color(255, 0, 0), 2, true));
		setBackground(Color.BLACK);
		setFont(new Font(Constants.FONT_NAME, Font.PLAIN, getHeight()/12));
		setLayout(null);
		setFocusable(false);

		this.font = new Font(Constants.FONT_NAME, Font.PLAIN, getHeight()/12);
		
		btnRestart = new JButton(Language.getString("retry"));
		btnRestart.setFocusable(false);
		btnRestart.setFont(this.font);
		//btnRestart.setBounds(10, 192, 196, 38);
		btnRestart.setSize((getSize().width-20-8)/2, getSize().height/6);
		btnRestart.setLocation(10, getSize().height-btnRestart.getSize().height-10);
		add(btnRestart);
		
		btnNextLvl = new JButton(Language.getString("next level"));
		btnNextLvl.setFocusable(false);
		btnNextLvl.setFont(this.font);
		//btnNextLvl.setBounds(10, 142, 196, 38);
		btnNextLvl.setSize((getSize().width-20-8)/2, getSize().height/6);
		btnNextLvl.setLocation(10, getSize().height-btnNextLvl.getSize().height-btnRestart.getSize().height-20);
		add(btnNextLvl);
		
		btnEnd = new JButton(Language.getString("end"));
		btnEnd.setFocusable(false);
		btnEnd.setFont(this.font);
		//btnEnd.setBounds(216, 192, 196, 38);
		btnEnd.setSize((getSize().width-20-8)/2, getSize().height/6);
		btnEnd.setLocation(getSize().width-btnEnd.getSize().width-10, getSize().height-btnRestart.getSize().height-10);
		add(btnEnd);
		
		scrollPane = new JScrollPane();
		//scrollPane.setBounds(10, 11, 400, 120);
		scrollPane.setSize(getSize().width-20, getSize().height-btnNextLvl.getSize().height-btnRestart.getSize().height-40);
		scrollPane.setLocation(10, 10);
		add(scrollPane);
		
		textAreaInfo = new JTextArea();
		textAreaInfo.setFocusable(false);
		textAreaInfo.setEditable(false);
		textAreaInfo.setForeground(Color.WHITE);
		textAreaInfo.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		textAreaInfo.setBackground(Color.DARK_GRAY);
		textAreaInfo.setFont(new Font(Constants.FONT_NAME, Font.PLAIN, getHeight()/12));
		textAreaInfo.setText("Test Text");
		textAreaInfo.setLineWrap(true);
		textAreaInfo.setWrapStyleWord(true);
		scrollPane.setViewportView(textAreaInfo);
	}
	
	public void resize(){
		setSize(Math.min(Constants.GAME_PANEL_SIZE.width, 420), Math.min(Constants.GAME_PANEL_SIZE.height, 240));
		setLocation(Constants.calcCenterLocation(Constants.GAME_PANEL_SIZE, getSize()));
		
		btnRestart.setSize((getSize().width-20-8)/2, getSize().height/6);
		btnRestart.setLocation(10, getSize().height-btnRestart.getSize().height-10);
		btnNextLvl.setSize((getSize().width-20-8)/2, getSize().height/6);
		btnNextLvl.setLocation(10, getSize().height-btnNextLvl.getSize().height-btnRestart.getSize().height-20);
		btnEnd.setSize((getSize().width-20-8)/2, getSize().height/6);
		btnEnd.setLocation(getSize().width-btnEnd.getSize().width-10, getSize().height-btnRestart.getSize().height-10);
		scrollPane.setSize(getSize().width-20, getSize().height-btnNextLvl.getSize().height-btnRestart.getSize().height-40);
		scrollPane.setLocation(10, 10);
		
		setFont(new Font(Constants.FONT_NAME, Font.PLAIN, getHeight()/12));
		font = new Font(Constants.FONT_NAME, Font.PLAIN, getHeight()/12);
		btnRestart.setFont(this.font);
		btnNextLvl.setFont(this.font);
		btnEnd.setFont(this.font);
		textAreaInfo.setFont(new Font(Constants.FONT_NAME, Font.PLAIN, getHeight()/12));
	}
	
	public void showOptions(boolean nextLevel){
		if(this.game == null)
			return;
		
		setVisible(true);
		
		if(nextLevel){
			this.btnNextLvl.setVisible(true);
		}else{
			this.btnNextLvl.setVisible(false);
		}
		
		if(this.game.getState() == GameState.WON){
			this.textAreaInfo.setForeground(Color.GREEN);
			this.textAreaInfo.setText(Language.getString("game won"));
			this.setBorder(new LineBorder(Color.GREEN, 3, true));
		}else if(this.game.getState() == GameState.LOST){
			this.textAreaInfo.setForeground(Color.RED);
			this.textAreaInfo.setText(Language.getString("game lost"));
			this.setBorder(new LineBorder(Color.RED, 3, true));
		}
	}
	
	public void setGame(Game game){
		this.game = game;
	}
	
	public JButton getRestartButton(){
		return this.btnRestart;
	}
	public JButton getNextLevelButton(){
		return this.btnNextLvl;
	}
	public JButton getEndButton(){
		return this.btnEnd;
	}
}