package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import model.Game;
import util.ColoredString;
import util.Constants;
import util.GameMode;

public class FormulaPanel extends JPanel{
	private static final long serialVersionUID = 4088877258360777513L;
	
	private Game game;
	
	public FormulaPanel(){
		this.game = null;
		setFont(new Font(Constants.FONT_NAME, Font.PLAIN, 36));
		
		setDoubleBuffered(true);
		setLayout(null);
		setSize(Constants.FORMULA_PANEL_SIZE);
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		if(this.game != null && this.game.getCurFormula() != null){ //formula exists
			String formulaString = "";
			
			//in case of QBF, add prefix
			if(this.game.getCurFormula().getOrigQuantifierInfo() != null)
				formulaString += this.game.getCurFormula().getOrigQuantifierInfo().toString();
			
			if(Constants.GAME_MODE != GameMode.HARDCORE)
				formulaString += this.game.getCurFormula().print();
			else //hardcore mode: use original expression
				formulaString += this.game.getCurFormula().getCnfInfo().getFormulaStateInfo().getOriginalExpression().toString();
			
			//set size of panel properly
			setPreferredSize(new Dimension(Math.max(Constants.FORMULA_PANEL_SIZE.width, 
					getFontMetrics(getFont()).stringWidth(formulaString)), 
					getFontMetrics(getFont()).getHeight())); //setPreferredSize()!!!
			
			Graphics2D g2 = (Graphics2D)g;
			
			//draw background for formula
			g2.setColor(Color.DARK_GRAY);
			g2.fillRect(0, 0, getSize().width, getSize().height);
			
			//draw formula
			int offsetX = (getSize().width - getFontMetrics(getFont()).stringWidth(formulaString))/2;
			int offsetY = (getSize().height - getFontMetrics(getFont()).getHeight())/2*0 + getFontMetrics(getFont()).getAscent();
			List<ColoredString> coloredStrings = new LinkedList<ColoredString>();
			
			//quantifier prefix existing: use original quantifier info that the user entered
			if(this.game.getCurFormula().getOrigQuantifierInfo() != null)
				coloredStrings.add(new ColoredString(this.game.getCurFormula().getOrigQuantifierInfo().toString(), Color.WHITE));
			
			if(Constants.GAME_MODE != GameMode.HARDCORE){
				coloredStrings.addAll(this.game.getCurFormula().getColoredClauseStrings());
			}else{ //hardcore mode: use original expression
				coloredStrings.addAll(this.game.getCurFormula().getColoredOriginalExpression());
			}
			
			//draw colored strings
			for(ColoredString coloredString : coloredStrings){
				g2.setColor(coloredString.getColor());
				g2.drawString(coloredString.getString(), offsetX, offsetY);
				offsetX += getFontMetrics(getFont()).stringWidth(coloredString.getString());
			}
		}
	}
	
	public void resize(){
		setSize(Constants.FORMULA_PANEL_SIZE);
		setFont(new Font(Constants.FONT_NAME, Font.PLAIN, (int)((getSize().height - 
				((JScrollPane)getParent().getParent()).getHorizontalScrollBar().getHeight())*0.7)));
		repaint();
	}
	
	public void setGame(Game game){
		this.game = game;
	}
}