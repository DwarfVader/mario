package model.action;

import util.VariableState;
import model.formula.Variable;

public class VariableAction implements Action{
	private Variable variable;
	
	public VariableAction(Variable variable){
		this.variable = variable;
	}
	
	@Override
	public void undo(){
		if(this.variable != null)
			this.variable.setSatisfied(VariableState.UNDEFINED);
	}
	@Override
	public String toString(){
		return "variable action";
	}
	
	public Variable getVariable(){
		return this.variable;
	}
}