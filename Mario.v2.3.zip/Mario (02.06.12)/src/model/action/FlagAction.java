package model.action;

import model.Flag;
import model.MapPart;
import util.MyPoint;

public class FlagAction implements Action{
	private Flag flag;
	private MyPoint originalDestination;
	private MapPart originalMap;
	
	public FlagAction(Flag flag){
		this.flag = flag;
		this.originalDestination = new MyPoint(flag.getLocation());
		this.originalMap = flag.getMap();
	}
	
	@Override
	public void undo(){
		this.flag.setLocation(this.originalDestination);
		this.flag.setMap(originalMap);
	}
	@Override
	public String toString(){
		return "flag action";
	}
	
	public Flag getFlag(){
		return this.flag;
	}
}