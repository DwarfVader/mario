package model.action;

import model.Coin;
import model.Game;
import model.MapPart;
import model.animation.SlideshowManager;
import model.blocks.Block;
import model.blocks.BlockHolder;
import util.Constants.BlockType;

public class PowerCoinToBlockAction implements Action{
	private Game game;
	private MapPart map;
	private BlockHolder blockHolder;
	
	public PowerCoinToBlockAction(Game game, MapPart map, BlockHolder blockHolder){
		this.map = map;
		this.blockHolder = blockHolder;
	}
	
	@Override
	public void undo(){
		SlideshowManager.getInstance().removeSlideshow(this.blockHolder.getBlock().getMap(), 
				this.blockHolder.getBlock().getSlideshow());
		this.blockHolder.setBlock(new Block(this.map, BlockType.COIN));
		//won't need the next line; addSlideshow() is called by the constructor of Block
		//SlideshowManager.getInstance().addSlideshow(this.blockHolder.getBlock().getMap(), this.blockHolder.getBlock().getSlideshow());
		
		this.game.getCoins().add(new Coin(this.map, this.blockHolder.getLocation()));
	}
	@Override
	public String toString(){
		return "power coin to block action";
	}
	
	public MapPart getGameMap(){
		return this.map;
	}
	public BlockHolder getBlockHolder(){
		return this.blockHolder;
	}
}