package model.action;

import model.MapPart;
import model.animation.SlideshowManager;
import model.blocks.Block;
import model.blocks.BlockHolder;
import util.Constants.BlockType;

public class CoinBlockAction implements Action{
	private MapPart map;
	private BlockHolder blockHolder;
	
	public CoinBlockAction(MapPart map, BlockHolder blockHolder){
		this.map = map;
		this.blockHolder = blockHolder;
	}
	
	@Override
	public void undo(){
		//SlideshowManager.getInstance().removeSlideshow(this.blockHolder.getBlock().getMap(), 
		//		this.blockHolder.getBlock().getSlideshow());
		this.blockHolder.setBlock(new Block(this.map, BlockType.COIN_BLOCK));
		//won't need the next line; addSlideshow() is called by the constructor of Block
		//SlideshowManager.getInstance().addSlideshow(this.blockHolder.getBlock().getMap(), this.blockHolder.getBlock().getSlideshow());
	}
	@Override
	public String toString(){
		return "coin block action";
	}
	
	public MapPart getGameMap(){
		return this.map;
	}
	public BlockHolder getBlockHolder(){
		return this.blockHolder;
	}
}