package model.action;

import model.MapPart;
import model.animation.SlideshowManager;
import model.blocks.BlockHolder;
import model.blocks.BlockManager;
import model.blocks.RotateBlock;
import model.formula.Clause;
import model.formula.Variable;
import util.Constants.BlockType;

public class BrickSmashAction implements Action{
	private MapPart map;
	private BlockHolder blockHolder;
	private Clause clause;
	private Variable variable;
	
	public BrickSmashAction(MapPart map, BlockHolder blockHolder, Clause clause, Variable variable){
		this.map = map;
		this.blockHolder = blockHolder;
		this.clause = clause;
		this.variable = variable;
	}
	
	@Override
	public void undo(){
		SlideshowManager.getInstance().removeSlideshow(this.blockHolder.getBlock().getMap(), 
				this.blockHolder.getBlock().getSlideshow());
		RotateBlock block = new RotateBlock(this.map, BlockType.ROTATE_BLOCK, clause, variable);
		this.blockHolder.setBlock(block);
		BlockManager.getInstance().registerBlock(block);
	}
	@Override
	public String toString(){
		return "brick smash action";
	}
	
	public MapPart getGameMap(){
		return this.map;
	}
	public BlockHolder getBlockHolder(){
		return this.blockHolder;
	}
}