package model;

import java.awt.Dimension;
import java.awt.Point;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Observable;

import model.action.ActionManager;
import model.action.BrickSmashAction;
import model.action.ClauseAction;
import model.action.CoinAction;
import model.action.CoinBlockAction;
import model.action.EntranceAction;
import model.action.InitializationAction;
import model.action.KoopaAction;
import model.action.MushroomBlockAction;
import model.action.MushroomSpawnAction;
import model.action.PowerBlockAction;
import model.action.VariableAction;
import model.animation.Animation;
import model.animation.AnimationStep;
import model.animation.Background;
import model.animation.BackgroundLayer;
import model.animation.CollisionAnimationStep;
import model.animation.GameOverAnimationStep;
import model.animation.HorizontalDistanceAnimationStep;
import model.animation.SlideshowManager;
import model.blocks.ArrowBlock;
import model.blocks.Block;
import model.blocks.BlockHolder;
import model.blocks.BlockManager;
import model.blocks.BrickBlock;
import model.blocks.EntranceBlock;
import model.blocks.LabelBlock;
import model.blocks.RotateBlock;
import model.blocks.StoneBlock;
import model.blocks.TrampolineDestinationBlock;
import model.blocks.VariableAssignmentBlock;
import model.formula.Clause;
import model.formula.CnfInfo;
import model.formula.Formula;
import model.formula.QuantifierType;
import model.formula.Variable;
import util.Collidable;
import util.Constants;
import util.Constants.BlockType;
import util.Constants.Direction;
import util.GameState;
import util.ImageLoader;
import util.MapLoader;
import util.Movable;
import util.MyPoint;
import util.ObservableType;
import util.VariableState;

public class Game extends Observable{
	private Mario mario;
	private List<Mushroom> mushrooms;
	private List<Koopa> koopas;
	private List<Trampoline> trampolines;
	private List<FireBall> fireBalls;
	private List<Coin> coins;
	private Map<Point, MapPart> mapParts;
	private Dimension numMapParts;
	private Dimension gameSize;
	private List<CnfInfo> formulas;
	private Formula curFormula;
	private GameState state;
	private GameState oldState;
	private int timerTicks;
	//private Flag flag;
	private FinishGate finishGate;
	
	private ActionManager actionManager; //Do NOT replace, since this is observed!
	private long time;
	private long score;
	
	private SlideshowManager slideshowManager;
	private BlockManager blockManager;
	private Background background;
	
	private boolean running;
	private boolean isCreated;
	private boolean isShowMinimap;
	private List<Direction> minimapScrollDirections;
	private MyPoint minimapScroll;
	
	public Game(List<CnfInfo> formulas){
		this.mario = null;
		this.mushrooms = new LinkedList<Mushroom>();
		this.koopas = new LinkedList<Koopa>();
		this.trampolines = new LinkedList<Trampoline>();
		this.fireBalls = new LinkedList<FireBall>();
		this.coins = new LinkedList<Coin>();
		this.mapParts = new HashMap<Point, MapPart>();
		this.numMapParts = null;
		this.gameSize = null;
		this.state = GameState.RUNNING;
		this.timerTicks = 0;
		this.actionManager = new ActionManager();
		this.time = 0;
		this.score = 0;
		this.formulas = formulas;
		this.curFormula = null; //= Formula.createFormula(this, formula);
		this.running = true;
		this.isCreated = false;
		//this.flag = null;
		this.isShowMinimap = false;
		this.minimapScrollDirections = new LinkedList<Direction>();
		this.minimapScroll = new MyPoint(0, 0);
		
		this.finishGate = null;
		
		this.slideshowManager = SlideshowManager.getInstance();
		this.blockManager = BlockManager.getInstance();
		
		if(!MapLoader.isOk()){
			System.out.println("Probleme beim Laden der Karten. Beende Spiel!");
			return;
		}
		
		startTimerThread();
	}
	
	public void newGame(){
		//create new formula
		if(this.formulas.isEmpty()){
			System.out.println("Error: Tried to start further games without further formulas... Should not happen!");
			update(ObservableType.GAME_ERROR_STATE);
			return;
		}
		
		reset();
		
		this.isCreated = false;
		
		/* If new games are created, the old ones are still in the slideshow manager and will 
		 * call the increment times method. To avoid this, a new slideshow manager instance 
		 * is created. Therefore a new Mario has to be created AFTER the slideshow manager 
		 * has been instantiated. */
		SlideshowManager.reset();
		BlockManager.reset();
		this.slideshowManager = SlideshowManager.getInstance();
		this.mario = new Mario(this);
		this.mushrooms.clear();
		this.koopas.clear();
		this.actionManager.clear();
		this.minimapScroll = new MyPoint(0, 0);
		
		this.curFormula = Formula.createFormula(this, this.formulas.remove(0));
		if(this.curFormula.getQuantifierInfo() == null)
			newGameNP();
		else
			newGamePSPACE();
		
		createBackground();
	}
	
	private void createBackground(){
		this.background = new Background();
		this.background.addLayer(new BackgroundLayer(ImageLoader.background1));
		this.background.addLayer(new BackgroundLayer(ImageLoader.background2Images, 800));
	}
	
	private void newGameNP(){
	//CREATE MAPPARTS
		long a = System.currentTimeMillis();
		//calc size of game world
		int numVariables = this.curFormula.getNormalVariables().size();
		int numClauses = this.curFormula.getClauses().size();
		Dimension mapSizeVariable = MapLoader.mapMapping.get("variable").getSize();
		Dimension mapSizeClause = MapLoader.mapMapping.get("clause").getSize();
		Dimension mapSizeJumpDown = MapLoader.mapMapping.get("jump_down").getSize();
		Dimension mapSizeStart = MapLoader.mapMapping.get("start").getSize();
		Dimension mapSizeFinish = MapLoader.mapMapping.get("finish").getSize();
		Dimension mapSizeCrossover = MapLoader.mapMapping.get("crossover1").getSize();
		int totalLiteralsInClauses = 0; //sum of all literals
		int maxLiteralsInClauses = 0; //max number of literals in a single clause
		for(Clause clause : this.curFormula.getClauses()){
			totalLiteralsInClauses += clause.getLiterals().size();
			maxLiteralsInClauses = Math.max(maxLiteralsInClauses, clause.getLiterals().size());
		}
		
		this.gameSize = new Dimension(Math.max(numVariables * (mapSizeVariable.width + Constants.PATH_SIZE.width), 
				Math.max(mapSizeStart.width + Constants.PATH_SIZE.width, mapSizeFinish.width + Constants.PATH_SIZE.width)) + 
				Constants.PATH_SIZE.width + //additional move to right in case of crossover between first and second literal
				2 * totalLiteralsInClauses * (mapSizeCrossover.width + Constants.PATH_SIZE.width) + 
				(numVariables > 1 ? 2 * mapSizeCrossover.width + Constants.PATH_SIZE.width : 
						mapSizeJumpDown.width) + //space for jump-down gadget: in case of only one variable, no crossovers
				(numVariables-1) * 2 * Constants.PATH_SIZE.width, 
				Math.max(mapSizeStart.height, (numVariables-1) * 2 * Constants.PATH_SIZE.height) + 
				Constants.PATH_SIZE.height + mapSizeVariable.height + Constants.PATH_SIZE.height + 
				(numVariables * 2) * (mapSizeCrossover.height + Constants.PATH_SIZE.height) + 
				(maxLiteralsInClauses + 1) * Constants.PATH_SIZE.height + //bonus height between lowest crossover and clause
				Math.max(mapSizeFinish.height, mapSizeClause.height));
		Point origin = new Point(0, Math.max(mapSizeStart.height, //calculate location of first variable gadget
				(numVariables-1) * 2 * Constants.PATH_SIZE.height) + Constants.PATH_SIZE.height);
		int xOffsetClauses = Math.max(numVariables * (mapSizeVariable.width + Constants.PATH_SIZE.width), 
				Math.max(mapSizeStart.width + Constants.PATH_SIZE.width, mapSizeFinish.width + Constants.PATH_SIZE.width)) + 
				Constants.PATH_SIZE.width;
		int yOffsetPath = Math.max(mapSizeStart.height, 
				(numVariables-1) * 2 * Constants.PATH_SIZE.height) + Constants.PATH_SIZE.height + mapSizeVariable.height;
		
		//create mapParts to handle the size of the game
		this.numMapParts = new Dimension((gameSize.width-1)/Constants.MAP_PART_SIZE.width + 1,
				(gameSize.height-1)/Constants.MAP_PART_SIZE.height + 1);
		for(int i = 0; i < numMapParts.width; i++)
			for(int j = 0; j < numMapParts.height; j++){
				this.mapParts.put(new Point(i, j), new MapPart(i, j));
			}
		
		//for convenience, create check path (straight bottom line) first
		for(int i = 0; i < (xOffsetClauses + 2 * totalLiteralsInClauses * 
				(mapSizeCrossover.width + Constants.PATH_SIZE.width)) / Constants.PATH_SIZE.width; i++)
			insertMapTemplate(i * Constants.PATH_SIZE.width, gameSize.height - Constants.PATH_SIZE.height, 
					MapLoader.mapMapping.get("path10"));
		
		//place gadgets in mapParts
		insertMapTemplate(origin.x, origin.y - Constants.PATH_SIZE.height - mapSizeStart.height, 
				MapLoader.mapMapping.get("start"));
		for(int i = 0; i < numVariables; i++)
			insertMapTemplate(origin.x + i * (mapSizeVariable.width + Constants.PATH_SIZE.width), origin.y, 
					MapLoader.mapMapping.get("variable"), null, this.curFormula.getNormalVariable(i), 
					this.curFormula.getNormalVariable(i).getName());
		for(int i = 0, literalCount = 0; i < numClauses; i++){
			insertMapTemplate(xOffsetClauses + 
					2 * literalCount * (mapSizeCrossover.width + Constants.PATH_SIZE.width), 
					gameSize.height - mapSizeClause.height, 
					createClauseGadget(this.curFormula.getClause(i)), this.curFormula.getClause(i), null);
			literalCount += this.curFormula.getClause(i).getLiterals().size();
		}
		
		//need to create paths BEFORE crossovers are created
		for(int i = 0; i < this.curFormula.getNormalVariables().size(); i++){
			createPathsNP(gameSize, this.curFormula.getNormalVariable(i), VariableState.TRUE, i*2, 
					maxLiteralsInClauses, xOffsetClauses, yOffsetPath);
			createPathsNP(gameSize, this.curFormula.getNormalVariable(i), VariableState.FALSE, i*2 + 1, 
					maxLiteralsInClauses, xOffsetClauses, yOffsetPath);
		}
		
		//insert crossover gadgets
		Clause curClause;
		Variable variable;
		VariableState state;
		Point crossoverOffset = new Point(24, 30);
		for(int l = 0, literalCount = 0; l < 2 * numVariables; l++){
			//change variable every TWO steps, change state in between
			variable = this.curFormula.getNormalVariable(l / 2);
			state = (l % 2 == 0) ? VariableState.TRUE : VariableState.FALSE;
			
			literalCount = 0; //reset for each literal path
			for(int c = 0; c < numClauses; c++){
				curClause = this.curFormula.getClause(c);
				for(int cl = 0; cl < curClause.getLiterals().size(); cl++){
					if(curClause.getLiteral(cl).getName().equals(variable.getName()) &&
							curClause.getLiteral(cl).getState() == state){ //current literal found in clause
						for(int l2 = 0; l2 < l; l2++){ //insert crossovers for all previous literals
							//path going down
							insertMapTemplate(xOffsetClauses - crossoverOffset.x + 
									2 * literalCount * (mapSizeCrossover.width + Constants.PATH_SIZE.width), 
									gameSize.height - mapSizeClause.height - crossoverOffset.y - 
									(maxLiteralsInClauses + 1) * Constants.PATH_SIZE.height + Constants.PATH_SIZE.height - 
									mapSizeCrossover.height - Constants.PATH_SIZE.height - 
									l2 * (mapSizeCrossover.height + Constants.PATH_SIZE.height), 
									MapLoader.mapMapping.get("crossover1"));
							//path going up
							insertMapTemplate(xOffsetClauses - crossoverOffset.x + 
									(2 * literalCount + 1) * (mapSizeCrossover.width + Constants.PATH_SIZE.width), 
									gameSize.height - mapSizeClause.height - crossoverOffset.y - 
									(maxLiteralsInClauses + 1) * Constants.PATH_SIZE.height + Constants.PATH_SIZE.height - 
									mapSizeCrossover.height - Constants.PATH_SIZE.height - 
									l2 * (mapSizeCrossover.height + Constants.PATH_SIZE.height), 
									MapLoader.mapMapping.get("crossover2"));
						}
					}
					
					literalCount++;
				}
			}
			
			//insert crossovers above jump-down gadget
			if(l >= 2 * numVariables - 2){
				for(int l2 = 0; l2 < 2 * numVariables - 2; l2++){
					//path going down
					insertMapTemplate(xOffsetClauses - crossoverOffset.x + 
							2 * literalCount * (mapSizeCrossover.width + Constants.PATH_SIZE.width) + 
							(l - (2 * numVariables - 2)) * (mapSizeCrossover.width + Constants.PATH_SIZE.width), 
							gameSize.height - mapSizeClause.height - crossoverOffset.y - 
							(maxLiteralsInClauses + 1) * Constants.PATH_SIZE.height + Constants.PATH_SIZE.height - 
							mapSizeCrossover.height - Constants.PATH_SIZE.height - 
							l2 * (mapSizeCrossover.height + Constants.PATH_SIZE.height), 
							MapLoader.mapMapping.get("crossover1"));
				}
			}
		}
		
		insertMapTemplate(xOffsetClauses + 
				2 * totalLiteralsInClauses * (mapSizeCrossover.width + Constants.PATH_SIZE.width), 
				gameSize.height - mapSizeJumpDown.height, MapLoader.mapMapping.get("jump_down"));
		insertMapTemplate(origin.x, gameSize.height - mapSizeFinish.height, MapLoader.mapMapping.get("finish"));
		
		insertMapTemplate(origin.x, origin.y - Constants.PATH_SIZE.height, MapLoader.mapMapping.get("path5"));
		insertMapTemplate(origin.x + 2 * Constants.PATH_SIZE.width, 
				origin.y - Constants.PATH_SIZE.height, MapLoader.mapMapping.get("path5"));
		
		//easter eggs
		insertMapTemplate(numVariables * (mapSizeVariable.width + Constants.PATH_SIZE.width), 
				origin.y, MapLoader.mapMapping.get("seppl"));
		insertMapTemplate(numVariables * (mapSizeVariable.width + Constants.PATH_SIZE.width) + 
				MapLoader.mapMapping.get("seppl").getSize().width + Constants.PATH_SIZE.width, 
				origin.y, MapLoader.mapMapping.get("easteregg"));
		
		System.out.println("Time to create map: " + (System.currentTimeMillis() - a) + "ms");
	//SETUP STUFF TO START THE GAME
		
		//set start location
		Point marioStartLocation = new Point(origin.x + 3, origin.y - mapSizeStart.height);
		this.mario.setCurMap(calcMapPart(marioStartLocation.x, marioStartLocation.y));
		this.mario.setLocation(new MyPoint((marioStartLocation.x % Constants.MAP_PART_SIZE.width) * Constants.BLOCK_SIZE.width, 
				(marioStartLocation.y % Constants.MAP_PART_SIZE.height) * Constants.BLOCK_SIZE.height));
		
		//add initial entrance action to reset the game
		this.actionManager.addAction(new InitializationAction(this, "start", this.mario.getCurMap(), 
				this.mario.getLocation(), null)); //TODO: mushroom block!!!
		
		//updateSlideshows();
		
		this.isCreated = true;
		
		update(ObservableType.FORMULA);
	}
	private void createPathsNP(Dimension gameSize, Variable variable, VariableState state, int count, 
			int maxLiteralsInClauses, int xOffsetClauses, int yOffset){
		Dimension mapSizeCrossover = MapLoader.mapMapping.get("crossover1").getSize();
		Dimension mapSizeClause = MapLoader.mapMapping.get("clause").getSize();
		Dimension mapSizeVariable = MapLoader.mapMapping.get("variable").getSize();
		Dimension mapSizeJumpDown = MapLoader.mapMapping.get("jump_down").getSize();
		Dimension path = Constants.PATH_SIZE;
		Dimension size = new Dimension(gameSize.width/path.width + 1, gameSize.height/path.height + 1);
		int totalLiterals = 0;
		int map[][] = new int [size.width][size.height];
		clearArray(map, size, 0);
		
		int horizontalHeight = gameSize.height - mapSizeClause.height - 
				(maxLiteralsInClauses + 1) * path.height - //move up by bonus height TODO: +1 correct?
				(count + 1) * (mapSizeCrossover.height + path.height);
		Point start = new Point(2 * count * path.width, yOffset);
		List<Point> locations = new LinkedList<Point>();
		List<Point> clauseLocations = new LinkedList<Point>();
		for(int i = 0; i < this.curFormula.getClauses().size(); i++){
			for(int j = 0; j < this.curFormula.getClause(i).getLiterals().size(); j++){
				if(this.curFormula.getClause(i).getLiteral(j).getName().equals(variable.getName()) && 
						this.curFormula.getClause(i).getLiteral(j).getState() == state){
					clauseLocations.add(new Point(xOffsetClauses + 2 * totalLiterals * (mapSizeCrossover.width + path.width), 
							gameSize.height - mapSizeClause.height - (maxLiteralsInClauses + 1 - j) * path.height));
				}
				totalLiterals++;
			}
		}
		
		Point pos1 = new Point(start), pos2;
		for(int l = 0; l < clauseLocations.size(); l++){ //create path from start to last occurrence in a clause
			pos2 = clauseLocations.get(l);
			
			locations.clear();
			locations.add(new Point(pos1));
			locations.add(new Point(pos1.x, horizontalHeight));
			locations.add(new Point(pos2.x, horizontalHeight));
			locations.add(new Point(pos2));
			connectPoints(map, locations);
			
			pos1.x = pos2.x + mapSizeCrossover.width + path.width;
			pos1.y = pos2.y;
		}
		
		//need to keep last value of pos1 as beginning of remaining outer path
		locations.clear();
		locations.add(new Point(pos1));
		if(count >= 2 * this.curFormula.getNormalVariables().size() - 2){ //last variable: link to jump-down gadget
			locations.add(new Point(pos1.x, horizontalHeight));
			
			if(state == VariableState.TRUE){
				locations.add(new Point(xOffsetClauses + 2 * totalLiterals * (mapSizeCrossover.width + path.width), 
						horizontalHeight));
				locations.add(new Point(xOffsetClauses + 2 * totalLiterals * (mapSizeCrossover.width + path.width), 
						gameSize.height - mapSizeJumpDown.height - path.height));
			}else{
				if(this.curFormula.getNormalVariables().size() > 1){
					locations.add(new Point(xOffsetClauses + (2 * totalLiterals + 1) * (mapSizeCrossover.width + path.width), 
							horizontalHeight));
					locations.add(new Point(xOffsetClauses + (2 * totalLiterals + 1) * (mapSizeCrossover.width + path.width), 
							gameSize.height - mapSizeJumpDown.height - 2 * path.height));
					locations.add(new Point(xOffsetClauses + 
							2 * totalLiterals * (mapSizeCrossover.width + path.width) + 2 * path.width, 
							gameSize.height - mapSizeJumpDown.height - 2 * path.height));
					locations.add(new Point(xOffsetClauses + 
							2 * totalLiterals * (mapSizeCrossover.width + path.width) + 2 * path.width, 
							gameSize.height - mapSizeJumpDown.height - path.height));
				}else{ //only one variable, no crossovers above jump-down gadget
					locations.add(new Point(xOffsetClauses + 2 * totalLiterals * (mapSizeCrossover.width + path.width) + 
							mapSizeJumpDown.width - path.width, horizontalHeight));
					locations.add(new Point(xOffsetClauses + 2 * totalLiterals * (mapSizeCrossover.width + path.width) + 
							mapSizeJumpDown.width - path.width, 
							gameSize.height - mapSizeJumpDown.height - path.height));
				}
			}
		}else{ //not last variable
			locations.add(new Point(pos1.x, horizontalHeight));
			locations.add(new Point(gameSize.width - (count + 1) * path.width, horizontalHeight));
			locations.add(new Point(gameSize.width - (count + 1) * path.width, count * path.width));
			locations.add(new Point((count + 2) * 2 * path.width, count * path.width));
			locations.add(new Point((count + 2) * 2 * path.width, yOffset - mapSizeVariable.height - path.height));
		}
		connectPoints(map, locations);
		
		//create connection of down and up paths for each literal
		totalLiterals = 0;
		for(int i = 0; i < this.curFormula.getClauses().size(); i++){
			for(int j = 0; j < this.curFormula.getClause(i).getLiterals().size(); j++){
				if(this.curFormula.getClause(i).getLiteral(j).getName().equals(variable.getName()) && 
						this.curFormula.getClause(i).getLiteral(j).getState() == state){
					locations.clear();
					locations.add(new Point(xOffsetClauses + 2 * totalLiterals * (mapSizeCrossover.width + path.width) + 
							j * path.width, gameSize.height - mapSizeClause.height - path.height));
					locations.add(new Point(xOffsetClauses + 2 * totalLiterals * (mapSizeCrossover.width + path.width) + 
							j * path.width, gameSize.height - mapSizeClause.height - (maxLiteralsInClauses + 1 - j) * path.height));
					locations.add(new Point(xOffsetClauses + (2 * (totalLiterals + j) + 1) * (mapSizeCrossover.width + path.width), 
							gameSize.height - mapSizeClause.height - (maxLiteralsInClauses + 1 - j) * path.height));
					connectPoints(map, locations);
				}
			}
			totalLiterals += this.curFormula.getClause(i).getLiterals().size();
		}
		
		//insert map templates according to neighborhood (which sides need to connect to each other)
		for(int i = 0; i < size.width; i++)
			for(int j = 0; j < size.height; j++)
				if(map[i][j] != 0)
					insertMapTemplate(i * path.width, j * path.height, MapLoader.mapMapping.get("path" + calcNeighborhood(map, size, i, j)));
	}
	
	private void newGamePSPACE(){
	//CREATE MAPPARTS
		
		long a = System.currentTimeMillis();
		
		//calc size of game world
		int numVariables = this.curFormula.getNormalVariables().size(); //normal variables works here as only size matters
		int numClauses = this.curFormula.getClauses().size();
		Dimension mapSizeExQuantifierLeft = MapLoader.mapMapping.get("ex_quantifier").getSize();
		Dimension mapSizeExQuantifierControl = MapLoader.mapMapping.get("ex_quantifier_control").getSize();
		Dimension mapSizeUnQuantifierLeft = MapLoader.mapMapping.get("un_quantifier").getSize();
		Dimension mapSizeUnQuantifierControl = MapLoader.mapMapping.get("un_quantifier_control").getSize();
		Dimension mapSizeQuantifier = new Dimension(mapSizeUnQuantifierLeft.width+mapSizeUnQuantifierControl.width, 
				Math.max(mapSizeUnQuantifierLeft.height, mapSizeUnQuantifierControl.height));
		Dimension mapSizeStart = MapLoader.mapMapping.get("start_pspace").getSize();
		Dimension mapSizeFinish = MapLoader.mapMapping.get("finish_pspace").getSize();
		Dimension mapSizeCrossover = MapLoader.mapMapping.get("crossover_up").getSize();
		Dimension mapSizeGeneralizedDoor = MapLoader.mapMapping.get("generalized_door").getSize();
		int totalLiteralsInClauses = 0; //sum of all literals
		int maxLiteralsInClauses = 0; //max number of literals in a single clause
		for(Clause clause : this.curFormula.getClauses()){
			totalLiteralsInClauses += clause.getLiterals().size();
			maxLiteralsInClauses = Math.max(maxLiteralsInClauses, clause.getLiterals().size());
		}
		
		this.gameSize = new Dimension(Math.max(mapSizeStart.width, mapSizeFinish.width) + 
				numVariables * mapSizeQuantifier.width + 
				totalLiteralsInClauses * mapSizeGeneralizedDoor.width + //Wide enough to cover 4 crossovers!
				mapSizeCrossover.width + Constants.PATH_SIZE.width, 
				mapSizeQuantifier.height + //high enough to cover start and finish gadget?
				8 * numVariables * mapSizeCrossover.height + 
				mapSizeGeneralizedDoor.height + mapSizeCrossover.height + 2*Constants.PATH_SIZE.height);
		Point offsetPath = new Point(Math.max(mapSizeStart.width, mapSizeFinish.width), mapSizeQuantifier.height);
		Point offsetClauses = new Point(offsetPath.x + numVariables * mapSizeQuantifier.width, 
				offsetPath.y + 8 * numVariables * mapSizeCrossover.height);
		
		//create mapParts to handle the size of the game
		this.numMapParts = new Dimension((gameSize.width-1)/Constants.MAP_PART_SIZE.width + 1,
				(gameSize.height-1)/Constants.MAP_PART_SIZE.height + 1);
		for(int i = 0; i < numMapParts.width; i++)
			for(int j = 0; j < numMapParts.height; j++){
				this.mapParts.put(new Point(i, j), new MapPart(i, j));
			}
		
		//create paths
		for(int i = 0; i < numVariables; i++){ //creates 4 literal paths for each quantified variable
			createPathsPSPACE(i, VariableState.TRUE, offsetPath, offsetClauses);
			createPathsPSPACE(i, VariableState.FALSE, offsetPath, offsetClauses);
		}
		//create check path
		List<Point> locations = new LinkedList<Point>();
		locations.add(new Point(0, offsetPath.y-Constants.PATH_SIZE.height));
		locations.add(new Point(gameSize.width-mapSizeCrossover.width-Constants.PATH_SIZE.width, 
				offsetPath.y-Constants.PATH_SIZE.height));
		locations.add(new Point(gameSize.width-mapSizeCrossover.width-Constants.PATH_SIZE.width, 
				gameSize.height-Constants.PATH_SIZE.height));
		locations.add(new Point(offsetClauses.x-Constants.PATH_SIZE.width, 
				gameSize.height-Constants.PATH_SIZE.height));
		locations.add(new Point(offsetClauses.x-Constants.PATH_SIZE.width, 
				gameSize.height-mapSizeCrossover.height-Constants.PATH_SIZE.height));
		locations.add(new Point(gameSize.width-Constants.PATH_SIZE.width, 
				gameSize.height-mapSizeCrossover.height-Constants.PATH_SIZE.height));
		locations.add(new Point(gameSize.width-Constants.PATH_SIZE.width, 
				offsetPath.y-mapSizeUnQuantifierLeft.height));
		locations.add(new Point(0, offsetPath.y-mapSizeUnQuantifierLeft.height));
		createPath(locations);
		
		//create start and finish gadgets
		insertMapTemplate(0, offsetPath.y - mapSizeStart.height, MapLoader.mapMapping.get("start_pspace"));
		insertMapTemplate(0, offsetPath.y - mapSizeFinish.height - mapSizeUnQuantifierLeft.height + Constants.PATH_SIZE.height, 
				MapLoader.mapMapping.get("finish_pspace"));
		
		System.out.println(this.curFormula.getQuantifierInfo().toString());
		
		//create quantifier gadgets
		for(int i = 0; i < numVariables; i++){
			String curVariableName = this.curFormula.getQuantifierInfo().getVariableName(i);
			if(this.curFormula.getQuantifierInfo(curVariableName) == QuantifierType.EXISTENTIAL){
				insertMapTemplate(offsetPath.x + i * mapSizeQuantifier.width, 
						offsetPath.y - mapSizeExQuantifierLeft.height, 
						MapLoader.mapMapping.get("ex_quantifier"), 
						null, this.curFormula.getVariable(curVariableName), //need null clause to use variable
						curVariableName);
				insertMapTemplate(offsetPath.x + i * mapSizeQuantifier.width + mapSizeExQuantifierLeft.width, 
						offsetPath.y - mapSizeExQuantifierControl.height, 
						MapLoader.mapMapping.get("ex_quantifier_control"));
			}else{ //universal quantifier
				insertMapTemplate(offsetPath.x + i * mapSizeQuantifier.width, 
						offsetPath.y - mapSizeUnQuantifierLeft.height, 
						MapLoader.mapMapping.get("un_quantifier"), 
						null, this.curFormula.getVariable(curVariableName), //need null clause to use variable
						curVariableName);
				insertMapTemplate(offsetPath.x + i * mapSizeQuantifier.width + mapSizeUnQuantifierLeft.width, 
						offsetPath.y - mapSizeUnQuantifierControl.height, 
						MapLoader.mapMapping.get("un_quantifier_control"), 
						null, this.curFormula.getVariable(curVariableName));
			}
		}
		
		//create clause gadgets using generalized door gadgets
		for(int i = 0, literalCount = 0; i < numClauses; i++){
			//connect traverse paths of generalized door gadgets within one clause
			List<List<Point>> locationList = new LinkedList<List<Point>>();
			List<Point> myLocations;
			//upper horizontal path
			myLocations = new LinkedList<Point>();
			myLocations.add(new Point(offsetClauses.x + literalCount * mapSizeGeneralizedDoor.width, 
					gameSize.height - mapSizeCrossover.height - Constants.PATH_SIZE.height));
			myLocations.add(new Point(offsetClauses.x + (literalCount + this.curFormula.getClause(i).getLiterals().size()) * 
					mapSizeGeneralizedDoor.width - 2*Constants.PATH_SIZE.width, 
					gameSize.height - mapSizeCrossover.height - Constants.PATH_SIZE.height));
			locationList.add(myLocations);
			//vertical paths connecting to upper horizontal path
			for(int j = 0; j < this.curFormula.getClause(i).getLiterals().size(); j++){
				myLocations = new LinkedList<Point>();
				myLocations.add(new Point(offsetClauses.x + (literalCount + j+1) * mapSizeGeneralizedDoor.width - 
						2*Constants.PATH_SIZE.width, gameSize.height - mapSizeCrossover.height - Constants.PATH_SIZE.height));
				myLocations.add(new Point(offsetClauses.x + (literalCount + j+1) * mapSizeGeneralizedDoor.width - 
						2*Constants.PATH_SIZE.width, gameSize.height - mapSizeCrossover.height - 2*Constants.PATH_SIZE.height));
				locationList.add(myLocations);
			}
			createPaths(locationList);
			//lower horizontal path
			locationList.clear();
			myLocations = new LinkedList<Point>();
			if(this.curFormula.getClause(i).getLiterals().size() > 1){
				myLocations.add(new Point(offsetClauses.x + (literalCount+1) * mapSizeGeneralizedDoor.width - 
						Constants.PATH_SIZE.width, gameSize.height - 2*Constants.PATH_SIZE.height));
				myLocations.add(new Point(offsetClauses.x + (literalCount + this.curFormula.getClause(i).getLiterals().size()) * 
						mapSizeGeneralizedDoor.width - Constants.PATH_SIZE.width, gameSize.height - 2*Constants.PATH_SIZE.height));
			}
			myLocations.add(new Point(offsetClauses.x + (literalCount + this.curFormula.getClause(i).getLiterals().size()) * 
					mapSizeGeneralizedDoor.width - Constants.PATH_SIZE.width, 
					gameSize.height - mapSizeCrossover.height - Constants.PATH_SIZE.height));
			myLocations.add(new Point(offsetClauses.x + (literalCount + this.curFormula.getClause(i).getLiterals().size()) * 
					mapSizeGeneralizedDoor.width, gameSize.height - mapSizeCrossover.height - Constants.PATH_SIZE.height));
			locationList.add(myLocations);
			
			//vertical paths connecting to lower horizontal path: important to go top-down
			for(int j = 0; j < this.curFormula.getClause(i).getLiterals().size(); j++){
				myLocations = new LinkedList<Point>();
				myLocations.add(new Point(offsetClauses.x + (literalCount + j+1) * 
						mapSizeGeneralizedDoor.width - Constants.PATH_SIZE.height, 
						gameSize.height - mapSizeCrossover.height - 2*Constants.PATH_SIZE.height));
				if(j < this.curFormula.getClause(i).getLiterals().size()-1){
					myLocations.add(new Point(offsetClauses.x + (literalCount + j+1) * 
							mapSizeGeneralizedDoor.width - Constants.PATH_SIZE.height, 
							gameSize.height - 2*Constants.PATH_SIZE.height));
				}else{ //last vertical down-path has to stop earlier, to not overwrite up-path from below
					myLocations.add(new Point(offsetClauses.x + (literalCount + j+1) * 
							mapSizeGeneralizedDoor.width - Constants.PATH_SIZE.height, 
							gameSize.height - mapSizeCrossover.height - Constants.PATH_SIZE.height));
				}
				locationList.add(myLocations);
			}
			createPaths(locationList);
			
			//create generalized door gadgets
			for(int j = 0; j < this.curFormula.getClause(i).getLiterals().size(); j++){
				insertMapTemplate(offsetClauses.x + (literalCount + j) * mapSizeGeneralizedDoor.width, offsetClauses.y, 
						MapLoader.mapMapping.get("generalized_door"), this.curFormula.getClause(i), 
						this.curFormula.getClause(i).getLiteral(j), 
						(this.curFormula.getClause(i).getLiteral(j).getState() == VariableState.FALSE ? Constants.NOT : "") + 
						this.curFormula.getClause(i).getLiteral(j).getName());
				if(j < this.curFormula.getClause(i).getLiterals().size()-1)
					createCrossover(offsetClauses.x + (literalCount + j + 1) * mapSizeGeneralizedDoor.width - 
							Constants.PATH_SIZE.width, gameSize.height - mapSizeCrossover.height - 2*Constants.PATH_SIZE.height, 
							false, true);
			}
			
			literalCount += this.curFormula.getClause(i).getLiterals().size();
		}
		
		//create crossover gadgets
		Clause curClause;
		Variable variable;
		VariableState state;
		for(int l = 0, literalCount = 0; l < 2 * numVariables; l++){
			//change variable every TWO steps, change state in between
			variable = this.curFormula.getVariable(this.curFormula.getQuantifierInfo().getVariableName(l / 2));
			state = (l % 2 == 0) ? VariableState.TRUE : VariableState.FALSE;
			
			literalCount = 0; //reset for each literal path
			for(int c = 0; c < numClauses; c++){
				curClause = this.curFormula.getClause(c);
				for(int cl = 0; cl < curClause.getLiterals().size(); cl++){
					if(curClause.getLiteral(cl).getName().equals(variable.getName()) &&
							curClause.getLiteral(cl).getState() == state){ //current literal found in clause
						for(int l2 = 0; l2 <= l; l2++){ //check crossovers for previous literals
							//check later clauses whether previous literal is contained
							boolean insertCrossovers = false;
							for(int i = c+1; i < numClauses; i++)
								if(this.curFormula.getClause(i).containsLiteral(
										this.curFormula.getVariable(this.curFormula.getQuantifierInfo().getVariableName(l2 / 2)).getName(), 
										(l2 % 2 == 0) ? VariableState.TRUE : VariableState.FALSE)){
									insertCrossovers = true; //need crossovers
									break;
								}
							
							//crossover gadgets needed above literal l2
							if(insertCrossovers){
								int horizontalHeight = offsetPath.y + (8 * numVariables - 4 * l2) * mapSizeCrossover.height - 
										mapSizeCrossover.height;
								if(l2 == l){ //special case: close path crosses open path if further clauses to visit
									createCrossover(offsetClauses.x + literalCount * mapSizeGeneralizedDoor.width + 
											2*mapSizeCrossover.width, horizontalHeight - 0*mapSizeCrossover.height, 
											false, true);
									createCrossover(offsetClauses.x + literalCount * mapSizeGeneralizedDoor.width + 
											2*mapSizeCrossover.width, horizontalHeight - 1*mapSizeCrossover.height, 
											false, false);
									createCrossover(offsetClauses.x + literalCount * mapSizeGeneralizedDoor.width + 
											3*mapSizeCrossover.width, horizontalHeight - 0*mapSizeCrossover.height, 
											true, true);
									createCrossover(offsetClauses.x + literalCount * mapSizeGeneralizedDoor.width + 
											3*mapSizeCrossover.width, horizontalHeight - 1*mapSizeCrossover.height, 
											true, false);
								}else{
									//open and close paths going down
									for(int i = 0; i < 4; i++){
										createCrossover(offsetClauses.x + literalCount * mapSizeGeneralizedDoor.width, 
												horizontalHeight - i*mapSizeCrossover.height, 
												false, i % 2 == 0 ? true : false);
										createCrossover(offsetClauses.x + literalCount * mapSizeGeneralizedDoor.width + 
												2*mapSizeCrossover.width, horizontalHeight - i*mapSizeCrossover.height, 
												false, i % 2 == 0 ? true : false);
									}
									//open and close paths going up
									for(int i = 0; i < 4; i++){
										createCrossover(offsetClauses.x + literalCount * mapSizeGeneralizedDoor.width + 
												mapSizeCrossover.width, horizontalHeight - i*mapSizeCrossover.height, 
												true, i % 2 == 0 ? true : false);
										createCrossover(offsetClauses.x + literalCount * mapSizeGeneralizedDoor.width + 
												3*mapSizeCrossover.width, horizontalHeight - i*mapSizeCrossover.height, 
												true, i % 2 == 0 ? true : false);
									}
								}
							}
						}
					}
					
					literalCount++;
				}
			}
		}
		
		//single bottom right crossover
		createCrossover(gameSize.width - mapSizeCrossover.width - Constants.PATH_SIZE.width, 
				gameSize.height - mapSizeCrossover.height - 2*Constants.PATH_SIZE.height, 
				false, true);
		
		System.out.println("Time to create map: " + (System.currentTimeMillis() - a) + "ms");
		
	//SETUP STUFF TO START THE GAME
		
		//set start location
		Point marioStartLocation = new Point(3, offsetPath.y-6); //Caution: This is in BLOCK_SIZEs!
		this.mario.setCurMap(calcMapPart(marioStartLocation.x, marioStartLocation.y));
		this.mario.setLocation(new MyPoint((marioStartLocation.x % Constants.MAP_PART_SIZE.width) * Constants.BLOCK_SIZE.width, 
				(marioStartLocation.y % Constants.MAP_PART_SIZE.height) * Constants.BLOCK_SIZE.height));
		
		//add initial entrance action to reset the game
		this.actionManager.addAction(new InitializationAction(this, "start", this.mario.getCurMap(), 
				this.mario.getLocation(), null));
		
		//updateSlideshows();
		
		this.isCreated = true;
		
		update(ObservableType.FORMULA);
	}
	private void createPathsPSPACE(int variableIndex, VariableState state, 
			Point offsetPath, Point offsetClauses){ 
		/* Consider a variable and its state to create the open and close paths for that combination. 
		 * Variable count specifies the height on which a path runs. */
		int numVariables = this.curFormula.getNormalVariables().size(); //normal variables works here as only its size matters
		Dimension mapSizeUnQuantifierLeft = MapLoader.mapMapping.get("un_quantifier").getSize();
		Dimension mapSizeUnQuantifierControl = MapLoader.mapMapping.get("un_quantifier_control").getSize();
		Dimension mapSizeQuantifier = new Dimension(mapSizeUnQuantifierLeft.width+mapSizeUnQuantifierControl.width, 
				Math.max(mapSizeUnQuantifierLeft.height, mapSizeUnQuantifierControl.height));
		Dimension mapSizeCrossover = MapLoader.mapMapping.get("crossover_up").getSize();
		Dimension mapSizeGeneralizedDoor = MapLoader.mapMapping.get("generalized_door").getSize();
		Dimension path = Constants.PATH_SIZE;
		//Variable variable = this.curFormula.getNormalVariable(variableIndex);
		Variable variable = this.curFormula.getVariable(this.curFormula.getQuantifierInfo().getVariableName(variableIndex));
		int totalLiterals = 0;
		
		int horizontalHeight = offsetPath.y + (8 * (numVariables-variableIndex) - 
				(state == VariableState.TRUE ? 0 : 4)) * mapSizeCrossover.height - 2*path.height; //Correct by 2*path height!
		Point start = new Point(offsetPath.x + variableIndex*mapSizeQuantifier.width + 
				(state == VariableState.TRUE ? 0 : 4) * path.width, offsetPath.y); //FALSE path skips 4 TRUE (open/close) paths
		List<Point> locations = new LinkedList<Point>();
		
		//in contrast to createPathsNP(), only collect origin location of generalized door gadgets
		List<Point> clauseLocations = new LinkedList<Point>();
		for(int i = 0; i < this.curFormula.getClauses().size(); i++){
			for(int j = 0; j < this.curFormula.getClause(i).getLiterals().size(); j++){
				if(this.curFormula.getClause(i).getLiteral(j).getName().equals(variable.getName()) && 
						this.curFormula.getClause(i).getLiteral(j).getState() == state){
					clauseLocations.add(new Point(offsetClauses.x + totalLiterals * mapSizeGeneralizedDoor.width, 
							offsetClauses.y - path.height)); //correct by path.height to let paths connect exactly to doors
				}
				totalLiterals++;
			}
		}
		
		//in case of no clauses/generalized doors to visit: simply connect start and end points
		if(clauseLocations.isEmpty()){
			insertMapTemplate(start.x, start.y, MapLoader.mapMapping.get("path3"));
			insertMapTemplate(start.x + path.width, start.y, MapLoader.mapMapping.get("path25"));
			insertMapTemplate(start.x + 2*path.width, start.y, MapLoader.mapMapping.get("path3"));
			insertMapTemplate(start.x + 3*path.width, start.y, MapLoader.mapMapping.get("path25"));
			
			return;
		}
		
		//on k==0 create open path, on k==1 create close path, which uses next two lanes
		for(int k = 0; k < 2; k++){
			Point pos1 = new Point(start.x + k*2*path.width, start.y), pos2;
			
			//create paths from start to last occurrence in a clause
			for(int l = 0; l < clauseLocations.size(); l++){
				pos2 = clauseLocations.get(l);
				pos2.x += k*2*mapSizeCrossover.width; //moves close path to the right
				
				locations.clear();
				locations.add(new Point(pos1));
				locations.add(new Point(pos1.x, horizontalHeight - k*2*mapSizeCrossover.height));
				locations.add(new Point(pos2.x, horizontalHeight - k*2*mapSizeCrossover.height));
				locations.add(new Point(pos2));
				
				pos1.x = pos2.x + mapSizeCrossover.width;
				pos1.y = pos2.y;
				
				createPath(locations);
			}
			
			//need to keep last value of pos1 as beginning of back path
			locations.clear();
			locations.add(new Point(pos1));
			locations.add(new Point(pos1.x, horizontalHeight - (1 + k*2)*mapSizeCrossover.height));
			locations.add(new Point(start.x + (1 + k*2)*path.width, horizontalHeight - (1 + k*2)*mapSizeCrossover.height));
			locations.add(new Point(start.x + (1 + k*2)*path.width, start.y));
			
			createPath(locations);
		}
	}
	
	private void createPath(List<Point> locations){
		List<List<Point>> locationList = new LinkedList<List<Point>>();
		locationList.add(locations);
		createPaths(locationList);
	}
	private void createPaths(List<List<Point>> locationList){
		Dimension path = Constants.PATH_SIZE;
		Dimension size = new Dimension(gameSize.width/path.width + 1, gameSize.height/path.height + 1);
		int map[][] = new int [size.width][size.height];
		for(List<Point> locations : locationList)
			connectPoints(map, locations);
		
		//insert map templates according to neighborhood (which sides need to connect to each other)
		for(int i = 0; i < size.width; i++)
			for(int j = 0; j < size.height; j++)
				if(map[i][j] != 0)
					insertMapTemplate(i * path.width, j * path.height, 
							MapLoader.mapMapping.get("path" + calcNeighborhood(map, size, i, j)));
	}
	
	private int calcNeighborhood(int map[][], Dimension size, int x, int y){
		/* 
		 * Neighborhood: sum of neighbor values, calculated if not 0 as follows
		 * up: 1
		 * right: 2
		 * down: 4
		 * left: 8
		 * 
		 * if current block is marked as upward path: 16
		 * 
		 * Do NOT call for (empty) map[x][y] == 0.
		 */
		int sum = 0;
		if(y > 0 && map[x][y-1] != 0)
			sum += 1;
		if(x < size.width-1 && map[x+1][y] != 0)
			sum += 2;
		if(y < size.height-1 && map[x][y+1] != 0)
			sum += 4;
		if(x > 0 && map[x-1][y] != 0)
			sum += 8;
		
		if(map[x][y] == 2 || map[x][y] == 3)
			sum += 16;
		//else if(map[x][y] == 3)
		//	sum += 48; //up and coming from left: 16 + 32
		//System.out.println("Value of path part: " + sum);
		
		return sum;
	}
	private void connectPoints(int map[][], List<Point> points){
		if(points == null || points.isEmpty())
			return;
		
		Point pos1 = points.get(0), pos2;
		int path = Constants.PATH_SIZE.width;
		boolean previousPathLeft = false;
		
		/* Values: 0,1 -> down; 2,3 -> up; 0,2 -> right; 1,3 -> left */
		
		for(int l = 1; l < points.size(); l++){
			pos2 = points.get(l);
			
			for(int i = Math.min(pos1.x, pos2.x) / path; i <= Math.max(pos1.x, pos2.x) / path; i++)
				for(int j = Math.min(pos1.y, pos2.y) / path; j <= Math.max(pos1.y, pos2.y) / path; j++){
					if(map[i][j] == 0){
						map[i][j] = (pos1.y > pos2.y ? (previousPathLeft ? 3 : 2) : 1); //upward paths marked with 2
					}else{ //Applies on edges? 
						map[i][j] = Math.max(map[i][j], (pos1.y > pos2.y ? 2 : 1));
					}
				}
			
			previousPathLeft = pos1.x > pos2.x;
			
			pos1 = pos2;
		}
	}
	private void clearArray(int array[][], Dimension size, int value){
		for(int i = 0; i < size.width; i++)
			for(int j = 0; j < size.height; j++)
				array[i][j] = value;
	}
	
	private void createCrossover(int x, int y, final boolean up, final boolean right){
		GameMapTemplate mapTemplate = MapLoader.mapMapping.get(up ? "crossover_up" : "crossover_down");
		MapPart map;
		Block block;
		BlockType type;
		for(int i = 0; i < mapTemplate.getSize().width; i++)
			for(int j = 0; j < mapTemplate.getSize().height; j++){
				//calculate containing mapPart and location inside mapPart from absolute location
				map = calcMapPart(x + i, y + j);
				type = mapTemplate.getTypes()[i][j];
				switch(mapTemplate.getTypes()[i][j]){
				case ROTATE_BLOCK:
					block = new RotateBlock(map, type);
					this.blockManager.registerBlock((RotateBlock)block);
					break;
				case STONE:
					//replace block type by wall to avoid a separate block type with same image
					block = new StoneBlock(map, BlockType.WALL, map.getBlockHolder((x + i) % Constants.MAP_PART_SIZE.width, 
							(y + j) % Constants.MAP_PART_SIZE.height).getCollisionLocation(), true, 3);
					((StoneBlock)block).setRotateSpeed(10);
					this.blockManager.registerBlock((StoneBlock)block);
					//fireBlocksHorizontal.add((FireBlock)block);
					break;
				case TRAMPOLINE:
				case TRAMPOLINE_FIXED:
					block = new Block(map, type);
					this.trampolines.add(new Trampoline(this, map, 
							new MyPoint(((x + i) % Constants.MAP_PART_SIZE.width) * Constants.BLOCK_SIZE.width, 
							((y + j) % Constants.MAP_PART_SIZE.height) * Constants.BLOCK_SIZE.height), 
							mapTemplate.getTypes()[i][j] == BlockType.TRAMPOLINE ? false : true));
					break;
				default:
					block = new Block(map, type);
				}
				
				map.replaceBlock((x + i) % Constants.MAP_PART_SIZE.width, (y + j) % Constants.MAP_PART_SIZE.height, block);
			}
	}
	
	private void insertMapTemplate(int x, int y, GameMapTemplate mapTemplate){
		insertMapTemplate(x, y, mapTemplate, null, null, null);
	}
	/*private void insertMapTemplate(int x, int y, GameMapTemplate mapTemplate, String label){
		insertMapTemplate(x, y, mapTemplate, null, null, label);
	}*/
	private void insertMapTemplate(int x, int y, GameMapTemplate mapTemplate, Clause clause, Variable variable){
		insertMapTemplate(x, y, mapTemplate, clause, variable, null);
	}
	private void insertMapTemplate(int x, int y, GameMapTemplate mapTemplate, Clause clause, Variable variable, String label){
		//need this to insert recursive GameMapTemplates AFTER current insertion finished to avoid overwriting
		Map<Point, BlockType> recursiveMapParts = new HashMap<Point, BlockType>();
		
		MapPart map;
		Block block;
		BlockType type;
		for(int i = 0; i < mapTemplate.getSize().width; i++)
			for(int j = 0; j < mapTemplate.getSize().height; j++){
				//calculate containing mapPart and location inside mapPart from absolute location
				map = calcMapPart(x + i, y + j);
				type = mapTemplate.getTypes()[i][j];
				switch(type){
				case LABEL:
				case LABEL_LITERAL:
					block = new LabelBlock(map, type, label != null ? label : mapTemplate.getLabel(new Point(i, j)), 
							type == BlockType.LABEL_LITERAL ? true : false);
					break;
				case KOOPA:
					block = new Block(map, type);
					addKoopa(map, new MyPoint(((x + i) % Constants.MAP_PART_SIZE.width) * Constants.BLOCK_SIZE.width, 
							((y + j) % Constants.MAP_PART_SIZE.height) * Constants.BLOCK_SIZE.height));
					break;
				case COIN:
					block = new Block(map, type);
					this.coins.add(new Coin(map, 
							new MyPoint(((x + i) % Constants.MAP_PART_SIZE.width) * Constants.BLOCK_SIZE.width, 
							((y + j) % Constants.MAP_PART_SIZE.height) * Constants.BLOCK_SIZE.height)));
					break;
				case ROTATE_BLOCK:
					block = new RotateBlock(map, type, clause, variable);
					this.blockManager.registerBlock((RotateBlock)block);
					break;
				case STONE:
					//replace block type by wall to avoid a separate block type with same image
					block = new StoneBlock(map, BlockType.WALL, map.getBlockHolder((x + i) % Constants.MAP_PART_SIZE.width, 
							(y + j) % Constants.MAP_PART_SIZE.height).getCollisionLocation(), 4);
					this.blockManager.registerBlock((StoneBlock)block);
					break;
				case TRAMPOLINE:
				case TRAMPOLINE_FIXED:
					block = new Block(map, type);
					this.trampolines.add(new Trampoline(this, map, 
							new MyPoint(((x + i) % Constants.MAP_PART_SIZE.width) * Constants.BLOCK_SIZE.width, 
							((y + j) % Constants.MAP_PART_SIZE.height) * Constants.BLOCK_SIZE.height), 
							mapTemplate.getTypes()[i][j] == BlockType.TRAMPOLINE ? false : true));
					break;
				case TRAMPOLINE_DESTINATION:
					block = new TrampolineDestinationBlock(map, type, 
							new MyPoint(((x + i) % Constants.MAP_PART_SIZE.width) * Constants.BLOCK_SIZE.width, 
							((y + j) % Constants.MAP_PART_SIZE.height) * Constants.BLOCK_SIZE.height), 
							clause, variable);
					break;
				case FIREBALL:
					block = new Block(map, BlockType.EMPTY);
					this.fireBalls.add(new FireBall(map, 
							new MyPoint(((x + i) % Constants.MAP_PART_SIZE.width) * Constants.BLOCK_SIZE.width + 
							(Constants.BLOCK_SIZE.width - Constants.FIREBALL_SIZE.width)/2, 
							((y + j) % Constants.MAP_PART_SIZE.height) * Constants.BLOCK_SIZE.height + 
							(Constants.BLOCK_SIZE.height - Constants.FIREBALL_SIZE.height)/2)));
					break;
				case ENTRANCE:
					block = new EntranceBlock(map, type, label);
					break;
				/*case BRICK:
					block = new BrickBlock(map, type, clause);
					break;*/
				case VARIABLE_ASSIGNMENT_POSITIVE_LABEL:
				case VARIABLE_ASSIGNMENT_NEGATIVE_LABEL:
				case VARIABLE_ASSIGNMENT_POSITIVE:
				case VARIABLE_ASSIGNMENT_NEGATIVE:
					block = new VariableAssignmentBlock(map, type, variable);
					break;
				case ARROW:
					block = new ArrowBlock(map, type, variable);
					break;
				case FINISH_GATE:
					block = new Block(map, BlockType.EMPTY);
					this.finishGate = new FinishGate(map, 
							new MyPoint(((x + i) % Constants.MAP_PART_SIZE.width) * Constants.BLOCK_SIZE.width, 
							((y + j) % Constants.MAP_PART_SIZE.height) * Constants.BLOCK_SIZE.height));
					break;
				
				case DOOR_MAP:
				case CROSSOVER_DOWN_LEFT_MAP:
				case CROSSOVER_DOWN_RIGHT_MAP:
				case CROSSOVER_UP_LEFT_MAP:
				case CROSSOVER_UP_RIGHT_MAP:
					recursiveMapParts.put(new Point(x + i, y + j), mapTemplate.getTypes()[i][j]);
					continue;
				default:
					block = new Block(map, type);
				}
				
				map.replaceBlock((x + i) % Constants.MAP_PART_SIZE.width, (y + j) % Constants.MAP_PART_SIZE.height, block);
			}
		
		for(Point point : recursiveMapParts.keySet()){
			switch(recursiveMapParts.get(point)){
			case DOOR_MAP:
				insertMapTemplate(point.x, point.y, MapLoader.mapMapping.get("door"), clause, variable, label);
				break;
			case CROSSOVER_DOWN_LEFT_MAP:
				createCrossover(point.x, point.y, false, false);
				break;
			case CROSSOVER_DOWN_RIGHT_MAP:
				createCrossover(point.x, point.y, false, true);
				break;
			case CROSSOVER_UP_LEFT_MAP:
				createCrossover(point.x, point.y, true, false);
				break;
			case CROSSOVER_UP_RIGHT_MAP:
				createCrossover(point.x, point.y, true, true);
				break;
			default:
				break;
			}
		}
	}
	/** Resolves containing mapPart from absolute block-index-location. */
	private MapPart calcMapPart(int x, int y){
		return this.mapParts.get(new Point(x / Constants.MAP_PART_SIZE.width, y / Constants.MAP_PART_SIZE.height));
	}
	
	private GameMapTemplate createClauseGadget(Clause clause){
		Dimension size = new Dimension(Math.max(MapLoader.mapMapping.get("clause").getSize().width, 
				clause.getLiterals().size() * Constants.PATH_SIZE.width), MapLoader.mapMapping.get("clause").getSize().height);
		BlockType blockTypes[][] = new BlockType[size.width][size.height];
		
		//init border and empty blocks
		for(int i = 0; i < size.width; i++)
			for(int j = 0; j < size.height; j++)
				if(i == 0 || i == size.width-1 || j == 0 || j == size.height-1)
					blockTypes[i][j] = BlockType.WALL;
				else
					blockTypes[i][j] = BlockType.EMPTY;
		
		//insert insert narrow passage and bricks; open bottom exits
		for(int i = 0; i < size.width; i++){
			if(i != 1)
				blockTypes[i][size.height-8] = BlockType.WALL;
			if(i != size.width-6)
				blockTypes[i][size.height-6] = BlockType.WALL;
			if(i == size.width-5 || i == size.width-7){
				blockTypes[i][size.height-2] = BlockType.ROTATE_BLOCK;
				blockTypes[i][size.height-3] = BlockType.ROTATE_BLOCK;
				blockTypes[i][size.height-4] = BlockType.ROTATE_BLOCK;
				blockTypes[i][size.height-5] = BlockType.ROTATE_BLOCK;
			}
			if(i == 0 || i == size.width-1){
				blockTypes[i][size.height-2] = BlockType.EMPTY;
				blockTypes[i][size.height-3] = BlockType.EMPTY;
				blockTypes[i][size.height-4] = BlockType.EMPTY;
				blockTypes[i][size.height-5] = BlockType.EMPTY;
			}
		}
		
		//place top entrances
		GameMapTemplate topEntrance = MapLoader.mapMapping.get("clause_entrance");
		Map<Point, String> labels = new HashMap<Point, String>();
		for(int l = 0; l < clause.getLiterals().size(); l++)
			for(int i = 0; i < topEntrance.getSize().width; i++)
				for(int j = 0; j < topEntrance.getSize().height; j++){
					blockTypes[l * topEntrance.getSize().width + i][j] = topEntrance.getTypes()[i][j];
					if(topEntrance.getTypes()[i][j] == BlockType.LABEL || 
							topEntrance.getTypes()[i][j] == BlockType.LABEL_LITERAL){
						labels.put(new Point(l * topEntrance.getSize().width + i, j), 
								(clause.getLiteral(l).getState() == VariableState.FALSE ? Constants.NOT : "") + 
								clause.getLiteral(l).getName());
					}
				}
		
		return new GameMapTemplate(blockTypes, size, labels);
	}
	
	private void checkCollision(Movable movable){
		List<Direction> collisionDirections;
		BlockHolder curBlockHolder;
		Point offset = new Point(0, 0); //corrects location differences due to different map parts
		
		//FIRST check for collision with collidables; only check, if no animation steps are left for Mario
		if(movable instanceof Mario && (this.mario.getAnimation() == null || 
				this.mario.getAnimation().getStep() == null)){
			//Koopas
			if(!((Mario)movable).isCheatInvincibilityActive()){
				for(Koopa koopa : this.koopas){
					offset.x = (koopa.getCurMap().getIndex().x - movable.getCurMap().getIndex().x) * 
							Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
					offset.y = (koopa.getCurMap().getIndex().y - movable.getCurMap().getIndex().y) * 
							Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height;
					collisionDirections = movable.collides(koopa, offset);
					
					//isolate horizontal collisions, otherwise Mario would most likely not get hurt when colliding with Koopas
					if(collisionDirections.contains(Direction.WEST) || collisionDirections.contains(Direction.EAST)){
						for(Direction direction : collisionDirections){
							switch(direction){
							case WEST:
							case EAST:
								if(!koopa.isStunned() || Math.abs(koopa.getVelocity().x.value) > 0){
									((Mario)movable).hurt();
									koopa.setVelocityX(-koopa.getVelocityX());
								}else{
									koopa.kick(direction);
									koopa.setLocationX(koopa.getLocation().x.value + (direction == Direction.WEST ? 4 : -4));
									movable.setLocationX(movable.getOldLocation().x.value);
									movable.setVelocityX(movable.getVelocityX()/4);
								}
								break;
							case NORTH:
								((Mario)movable).hurt();
								break;
							default:
								break;
							}
						}
					}else if(collisionDirections.contains(Direction.SOUTH)){ //SOUTH-collision
						movable.setLocationY(movable.getOldLocation().y.value);
						movable.setVelocityY(-0.5f*Constants.MAX_MARIO_MOVE_SPEED / 1000 * Constants.TIMER_INTERVAL);
						
						if(!koopa.isStunned()){
							koopa.stun();
							//only add action on first contact, further actions will be ignored
							this.actionManager.addAction(new KoopaAction(this, koopa, koopa.getCurMap(), koopa.getLocation()));
							addScore(Constants.KOOPA_STUN_SCORE);
						}else{
							if(koopa.getVelocityX() == 0){
								koopa.kick(movable.getOldLocation().x.value > koopa.getOldLocation().x.value ? Direction.WEST : Direction.EAST);
								
								////this.game.addToKoopaMoveMapping(koopa, this); //XXX: Performance approach applied here!
								
							}else
								koopa.setVelocityX(0);
						}
					}
				}
			}
			
			//mushrooms
			for(Mushroom mushroom : new LinkedList<Mushroom>(this.mushrooms)){
				offset.x = (mushroom.getCurMap().getIndex().x - movable.getCurMap().getIndex().x) * 
						Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
				offset.y = (mushroom.getCurMap().getIndex().y - movable.getCurMap().getIndex().y) * 
						Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height;
				collisionDirections = movable.collides(mushroom, offset);
				
				for(Direction direction : collisionDirections)
					if(direction != Direction.NONE){ //Mario touched mushroom
						this.mushrooms.remove(mushroom);
						((Mario)movable).eatMushroom();
						addScore(Constants.MUSHROOM_EAT_SCORE);
						break;
					}
			}
			
			//coins
			for(Coin coin : new LinkedList<Coin>(this.coins)){
				offset.x = (coin.getCurMap().getIndex().x - movable.getCurMap().getIndex().x) * 
						Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
				offset.y = (coin.getCurMap().getIndex().y - movable.getCurMap().getIndex().y) * 
						Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height;
				collisionDirections = movable.collides(coin, offset);
				
				for(Direction direction : collisionDirections)
					if(direction != Direction.NONE){ //touched a coin
						this.coins.remove(coin);
						addScore(Constants.COIN_SCORE);
						this.actionManager.addAction(new CoinAction(this, coin));
						break;
					}
			}
			
			//fire balls
			for(FireBall fireBall : new LinkedList<FireBall>(this.fireBalls)){
				offset.x = (fireBall.getCurMap().getIndex().x - movable.getCurMap().getIndex().x) * 
						Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
				offset.y = (fireBall.getCurMap().getIndex().y - movable.getCurMap().getIndex().y) * 
						Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height;
				collisionDirections = movable.collides(fireBall, offset);
				
				for(Direction direction : collisionDirections)
					if(direction != Direction.NONE){ //touched a fireball
						((Mario)movable).hurt();
						break;
					}
			}
			
			//stone balls
			if(!((Mario)movable).isCheatInvincibilityActive()){
				List<StoneChainLink> stoneBalls;
				MapPart curMap;
				for(int ii = -1; ii <= 1; ii++)
					for(int jj = -1; jj <= 1; jj++){
						curMap = getMap(movable.getCurMap().getIndex().x + ii, movable.getCurMap().getIndex().y + jj);
						if(curMap == null)
							continue;
						
						stoneBalls = getStoneBallsInMapPart(curMap.getIndex().x, curMap.getIndex().y);
						for(StoneChainLink stoneBall : stoneBalls){
							offset.x = (stoneBall.getCurMap().getIndex().x - movable.getCurMap().getIndex().x) * 
									Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
							offset.y = (stoneBall.getCurMap().getIndex().y - movable.getCurMap().getIndex().y) * 
									Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height;
							collisionDirections = movable.collides(stoneBall, offset);

							boolean collision = false;
							for(Direction direction : collisionDirections)
								if(direction != Direction.NONE){ //rectangular collision with stone
									//take a closer look using radial collision check
									List<Direction> radialCollisionDirections = stoneBall.collides(movable, offset);
									for(Direction radialDirection : radialCollisionDirections)
										if(radialDirection != Direction.NONE){ //actually touching stone ball
											collision = true;
											break;
										}
								}
							
							if(collision){
								if(collisionDirections.contains(Direction.SOUTH) && ((Mario)movable).isSpinJumping()){
									movable.setLocationY(movable.getOldLocation().getY());
									((Mario)movable).jump(true, true);
									return;
								}else
									((Mario)movable).hurt();
							}
						}
					}
			}
			
			//trampolines
			for(Trampoline trampoline : this.trampolines){
				if(trampoline.isGrabbed())
					continue;
				
				offset.x = (trampoline.getCurMap().getIndex().x - movable.getCurMap().getIndex().x) * 
						Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
				offset.y = (trampoline.getCurMap().getIndex().y - movable.getCurMap().getIndex().y) * 
						Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height;
				collisionDirections = movable.collides(trampoline, offset);
				
				for(Direction direction : collisionDirections)
					switch(direction){
					case SOUTH:
						movable.setVelocityY(0);
						movable.setLocationY(movable.getOldLocation().y.value);
						((Mario)movable).setFeetOnTrampoline();
						break;
					case EAST:
					case WEST:
						movable.setVelocityX(0);
						movable.setLocationX(movable.getOldLocation().x.value);
						break;
					default:
						break;
					}
			}
			
			//finish: bar and gate
			offset.x = (this.finishGate.getCurMap().getIndex().x - movable.getCurMap().getIndex().x) * 
					Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
			offset.y = (this.finishGate.getCurMap().getIndex().y - movable.getCurMap().getIndex().y) * 
					Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height;
			collisionDirections = movable.collides(this.finishGate, offset);
			for(Direction direction : collisionDirections)
				if(direction != Direction.NONE){
					if(movable instanceof Mario){
						//check if Mario also collides with finish bar
						List<Direction> barCollisionDirections = movable.collides(this.finishGate.getBar(), offset);
						for(Direction barCollisionDirection : barCollisionDirections){
							if(barCollisionDirection != Direction.NONE){ //touching finish bar
								addScore(10000); //TODO
								this.finishGate.getBar().touch();
								break;
							}
						}
						
						Animation animation = new Animation();
						animation.addAnimationStep(new HorizontalDistanceAnimationStep(
								(int)(-10*Constants.BLOCK_SIZE.width), 
								this.mario.getLocation(), ((Mario)movable).getCurMap(), 
								-Constants.MAX_MOVE_SPEED, 0, false, true));
						animation.addAnimationStep(new GameOverAnimationStep(GameState.WON));
						this.mario.setAnimation(animation);
					}
				}
		}
		
		//check, whether movable collides with any block
		boolean isMarioOnVine = false;
		boolean wasSpinJumping = false;
		if(movable instanceof Mario){ //need to store before-collision-check information
			wasSpinJumping = ((Mario)movable).isSpinJumping();
		}
		boolean forceNewSpinJump = false;
		double newX = movable.getLocation().x.value;
		double newY = movable.getLocation().y.value;
		MapPart curMap;
		for(int ii = -1; ii <= 1; ii++)
			for(int jj = -1; jj <= 1; jj++){
				curMap = getMap(movable.getCurMap().getIndex().x + ii, movable.getCurMap().getIndex().y + jj);
				if(curMap == null)
					continue;
				
				offset.x = ii * Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width;
				offset.y = jj * Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height;
				
				for(int i = 0; i < Constants.MAP_PART_SIZE.width; i++)
					for(int j = 0; j < Constants.MAP_PART_SIZE.height; j++){
						curBlockHolder = curMap.getBlockHolder(i, j);

						if(curBlockHolder.getBlock().passable())
							continue;
						
						collisionDirections = movable.collides(curBlockHolder, offset);
						
						//check for animation steps
						if(movable instanceof Mario && ((Mario)movable).getAnimation() != null && 
								((Mario)movable).getAnimation().getStep() != null){
							AnimationStep animationStep = ((Mario)movable).getAnimation().getStep();
							//animationStep.updateVelocity(this.mario);
							if(((Mario)movable).getAnimation().getStep() instanceof CollisionAnimationStep){
								animationStep.checkFinishCondition(collisionDirections);
							}else if(((Mario)movable).getAnimation().getStep() instanceof HorizontalDistanceAnimationStep){
								animationStep.checkFinishCondition((Mario)movable);
							}else if(((Mario)movable).getAnimation().getStep() instanceof GameOverAnimationStep){
								animationStep.checkFinishCondition((Mario)movable);
								
								//Mario reached finish and animation ended
								switch(((GameOverAnimationStep)animationStep).getState()){
								case WON:
									win();
									break;
								case LOST:
									lose();
									break;
								default:
									//nothing to do
								}
							}
							
							//in case of gravity
							if(!animationStep.isIgnoreGravity()){
								for(Direction direction : collisionDirections)
									switch(direction){
									case EAST:
									case WEST:
										if(!animationStep.isIgnoreHorizontalCollision()){
											movable.setVelocityX(0);
											//movable.setLocationX(movable.getOldLocation().x.value);
											newX = movable.getOldLocation().x.value;
										}
										break;
									case SOUTH:
										movable.setFeetOnGround(); //do that only on SOUTH collision; No break!
									case NORTH:
										if(!animationStep.isIgnoreVerticalCollision()){
											movable.setVelocityY(0);
											//movable.setLocationY(movable.getOldLocation().y.value);
											newY = movable.getOldLocation().y.value;
										}
										break;
									default:
										break;
									}
							}
						}else{ //no amination steps left
							for(Direction direction : collisionDirections){
								if(direction != Direction.NONE){
									//enter new variable/quantifier gadget
									if(curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.ENTRANCE){
										this.actionManager.addAction(new EntranceAction(this, 
												((EntranceBlock)curMap.getBlockHolder(i, j).getBlock()).getLabel(), 
												curMap.getBlockHolder(i, j).getBlock().getMap(), 
												curMap.getBlockHolder(i, j).getLocation(), this.time, this.score, 
												((Mario)movable).isSuper()));
									}else if(curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.LAVA){ //fall into lava
										if(movable instanceof Mario){
											((Mario)movable).die();
										}else if(movable instanceof Koopa){
											this.koopas.remove((Koopa)movable);
										}else if(movable instanceof Mushroom){
											this.mushrooms.remove((Mushroom)movable);
										}
										return;
									}else if(curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.TRAMPOLINE_DESTINATION){
										if(movable instanceof Trampoline){
											((TrampolineDestinationBlock)curMap.getBlockHolder(i, j).getBlock()).
													satisfyLiteral(this.curFormula);
											this.actionManager.addAction(new VariableAction(((TrampolineDestinationBlock)curMap.
													getBlockHolder(i, j).getBlock()).getVariable()));
										}
									}else if(curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.VARIABLE_ASSIGNMENT_POSITIVE || 
											curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.VARIABLE_ASSIGNMENT_NEGATIVE || 
											curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.VARIABLE_ASSIGNMENT_POSITIVE_LABEL || 
											curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.VARIABLE_ASSIGNMENT_NEGATIVE_LABEL){
										if(movable instanceof Mario){
											((VariableAssignmentBlock)curMap.getBlockHolder(i, j).getBlock()).getVariable().setSatisfied(
													(curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.VARIABLE_ASSIGNMENT_POSITIVE || 
													curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.VARIABLE_ASSIGNMENT_POSITIVE_LABEL) ? 
													VariableState.TRUE : VariableState.FALSE);
											//also check clauses containing variable; in case of only unsatisfied variables, react
											this.curFormula.checkClausesNP();
											this.actionManager.addAction(new VariableAction(
													((VariableAssignmentBlock)curMap.getBlockHolder(i, j).getBlock()).getVariable()));
										}
									}else if(curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.VINE){
										if(movable instanceof Mario)
											isMarioOnVine = true;
									}else{
										switch(direction){ //check for collision with blocks of other types
										case EAST:
										case WEST:
										case HORIZONTAL_CENTER:
											if(movable instanceof Mario){
												movable.setVelocityX(0);
												if(((Mario)movable).getGrabbedTrampoline() != null && 
														((Mario)movable).getLastMoveDirection() != 
														((Mario)movable).getOldLastMoveDirection())
													((Mario)movable).restoreOldMoveDirection();
											}else if(movable instanceof Koopa){
												movable.setVelocityX(-movable.getVelocityX()); //reflect from wall
												if(curBlockHolder.getBlock().getType() == BlockType.ROTATE_BLOCK){ //smash
													RotateBlock brick = (RotateBlock)curBlockHolder.getBlock();
													curMap.replaceBlock(i, j, new Block(curMap, BlockType.EMPTY));
													addScore(Constants.BRICK_SMASH_SCORE);
													this.blockManager.unregisterBlock(brick);
													this.actionManager.addAction(new BrickSmashAction(curMap, curBlockHolder, 
															brick.getClause(), brick.getVariable()));
													checkBricks(brick, curMap);
												}/*else if(curBlockHolder.getBlock().getType() == BlockType.POWER_BLOCK){
													curMap.replaceBlock(i, j, new Block(curMap, BlockType.USED_BLOCK));
													addScore(Constants.COIN_SCORE);
													this.actionManager.addAction(new PowerBlockAction(curMap, curBlockHolder));
													//usePowerBlock(); //TODO
													//checkBricks(); //TODO
												}*/
											}else if(movable instanceof Mushroom){
												movable.setVelocityX(-movable.getVelocityX()); //reflect from wall
											}
											//movable.setLocationX(movable.getOldLocation().x.value);
											newX = movable.getOldLocation().x.value;
											break;
										case NORTH: //jump from below
											if(movable instanceof Mario){
												if(((Mario)movable).isSuper() && ((Mario)movable).hasFeetOnGround())
													((Mario)movable).setCrouching(true); //TODO: Shit!!!
												else
													switch(curBlockHolder.getBlock().getType()){
													/*case BRICK:
														if(((Mario)movable).isSuper()){ //smash brick
															BrickBlock brick = (BrickBlock)curBlockHolder.getBlock();
															curMap.replaceBlock(i, j, new Block(curMap, BlockType.EMPTY));
															addScore(Constants.BRICK_SMASH_SCORE);
															this.actionManager.addAction(new BrickAction(curMap, curBlockHolder, 
																	brick.getClause()));
															//checkBricks(brick, curMap);
														}
														break;*/
													case MUSHROOM_BLOCK:
														curMap.replaceBlock(i, j, new Block(curMap, BlockType.USED_BLOCK));
														Mushroom mushroom = new Mushroom(this, curMap, new MyPoint(curBlockHolder.getLocation().x.value, 
																curBlockHolder.getLocation().y.value));
														this.mushrooms.add(mushroom);
														this.actionManager.addAction(new MushroomSpawnAction(this, mushroom));
														this.actionManager.addAction(new MushroomBlockAction(curMap, curBlockHolder));
														break;
													case COIN_BLOCK:
														curMap.replaceBlock(i, j, new Block(curMap, BlockType.USED_BLOCK));
														addScore(50);
														this.actionManager.addAction(new CoinBlockAction(curMap, curBlockHolder));
														break;
													case ROTATE_BLOCK:
														((RotateBlock)curBlockHolder.getBlock()).rotate(this.curFormula);
														if(((RotateBlock)curMap.getBlockHolder(i, j).getBlock()).getVariable() != null)
															this.actionManager.addAction(new VariableAction(((RotateBlock)curMap.
																	getBlockHolder(i, j).getBlock()).getVariable()));
														update(ObservableType.FORMULA);
														break;
													default:
														break;
													}
											}
											
											movable.setVelocityY(0.05f * movable.getVelocityY());
											//movable.setLocationY(movable.getOldLocation().y.value);
											newY = movable.getOldLocation().y.value;
											break;
										case SOUTH:
											//check for collision with neighboring empty block to avoid falling down
											if(movable instanceof Koopa && !((Koopa)movable).isStunned()){
												BlockHolder neighbor = getMap(curMap.getIndex().x + 
														(i + (movable.getLastMoveDirection() == Direction.EAST ? 1 : -1)) / 
														Constants.MAP_PART_SIZE.width, curMap.getIndex().y).getBlockHolder(((i + 
																(movable.getLastMoveDirection() == Direction.EAST ? 1 : -1)) + 
																Constants.MAP_PART_SIZE.width) % Constants.MAP_PART_SIZE.width, j);
												
												if(Constants.typePassableMapping.get(neighbor.getBlock().getType())){
													List<Direction> neighborCollisionDirections = 
															movable.collides(neighbor, offset, true);
													for(Direction neighborCollisionDirection : neighborCollisionDirections)
														if(neighborCollisionDirection != Direction.NONE){
															movable.setVelocityX(-movable.getVelocityX()); //turn around
															break; //avoid possible multiple turn-arounds
														}
												}
											}else if(movable instanceof Mario){
												switch(curBlockHolder.getBlock().getType()){
												case ROTATE_BLOCK: //destroy by spinjumping
													if(wasSpinJumping && 
															/*Math.abs(movable.getCollisionLocation().getX() - offset.x - 
															curBlockHolder.getCollisionLocation().getX()) < Constants.BLOCK_SIZE.width/2 && */
															((Mario)movable).isSuper()){
														RotateBlock brick = (RotateBlock)curBlockHolder.getBlock();
														curMap.replaceBlock(i, j, new Block(curMap, BlockType.EMPTY));
														addScore(Constants.BRICK_SMASH_SCORE);
														this.blockManager.unregisterBlock(brick);
														this.actionManager.addAction(new BrickSmashAction(curMap, curBlockHolder, 
																brick.getClause(), brick.getVariable()));
														forceNewSpinJump = true;
													}
													break;
												default:
													break;
												}
											}
											
											//Reset location AFTER empty-neighbor-check!!!
											movable.setVelocityY(0);
											//movable.setLocationY(oldLocation.y);
											//movable.setLocationY(curBlockHolder.getLocation().y.value); //avoid "rebouncing"...
											newY = curBlockHolder.getLocation().y.value;
											movable.setFeetOnGround();
											
											break;
										case VERTICAL_CENTER:
											movable.setVelocityY(0);
											newY = movable.getOldLocation().y.value;
											//movable.setLocationY(movable.getOldLocation().y.value);
											break;
										default:
											break;
										}
									}
									
									//Don't react for further collisions on one block. Diagonal collision causes Mario to get stuck in block. 
									break;
								}
							}
						}
					}
			}
			movable.setLocation(newX, newY);
			if(forceNewSpinJump)
				((Mario)movable).jump(true, true);
		
		//if Mario collided with vine, set flag, otherwise, reset it
		if(movable instanceof Mario)
			((Mario)movable).setIsOnVine(isMarioOnVine);
	}
	
	private void checkBricks(RotateBlock brick, MapPart map){
		MapPart curMap;
		for(int ii = -1; ii <= 1; ii++)
			for(int jj = -1; jj <= 1; jj++){
				curMap = getMap(map.getIndex().x + ii, map.getIndex().y + jj);
				if(curMap == null)
					continue;
				
				for(int i = 0; i < Constants.MAP_PART_SIZE.width; i++)
					for(int j = 0; j < Constants.MAP_PART_SIZE.height; j++){
						if(curMap.getBlockHolder(i, j).getBlock().getType() == BlockType.ROTATE_BLOCK && 
								((RotateBlock)curMap.getBlockHolder(i, j).getBlock()).getClause() != null && 
								((RotateBlock)curMap.getBlockHolder(i, j).getBlock()).getClause() == brick.getClause()){
							return; //further bricks regarding given clause left; do nothing
						}
					}
			}
		
		//no more bricks regarding given clause left; satisfy clause
		if(brick.getClause() != null){
			this.curFormula.satisfyClause(brick.getClause());
			this.actionManager.addAction(new ClauseAction(brick.getClause()));
		}
	}
	
	public MapPart getCurMap(){
		return this.mario.getCurMap(); //TODO: Needed?
	}
	public MapPart getMap(int i, int j){
		return this.mapParts.get(new Point(i, j));
	}
	public boolean isCreated(){
		return this.isCreated;
	}
	
	public void reset(){
		if(this.mario != null)
			this.mario.reset();
		if(this.finishGate != null)
			this.finishGate.getBar().reset();
		this.state = GameState.RUNNING;
		this.actionManager.undoAll();
	}
	/** Do NOT call this method outside of Action-subclasses. */
	public void resetCurrentMap(MapPart mapPart, MyPoint marioLocation){
		this.mario.resetMovement();
		this.mario.setCurMap(mapPart);
		this.mario.setLocation(marioLocation.x.value, marioLocation.y.value);
	}
	/** Do NOT call this method outside of Action-subclasses. */
	public void resetTime(long time){
		this.time = time;
	}
	/** Do NOT call this method outside of Action-subclasses. */
	public void resetScore(long score){
		this.score = score;
	}
	
	public void addKoopa(MapPart map, MyPoint location){
		this.koopas.add(new Koopa(this, map, location));
	}
	public void addScore(int score){
		this.score += score;
	}
	
	public void removeMushroom(Mushroom mushroom){
		this.mushrooms.remove(mushroom);
	}
	
	public void win(){
		this.state = GameState.WON;
		
		update(ObservableType.GAME_STATE);
		System.out.println("Gewonnen... Holdudiladioho!");
	}
	public void lose(){
		this.state = GameState.LOST;
		
		update(ObservableType.GAME_STATE);
		System.out.println("T��t!");
	}
	
	public void pause(){
		if(this.state != GameState.PAUSED){
			this.oldState = this.state;
			this.state = GameState.PAUSED;
			this.mario.clearMoveDirections();
		}else
			this.state = this.oldState;
	}
	
	public void stop(){
		this.running = false;
	}
	
	public void toggleShowMinimap(){
		this.isShowMinimap = !this.isShowMinimap;
		this.minimapScroll.x.value = this.minimapScroll.y.value = 0; //reset minimap scroll value
	}
	public void setMinimapScrollDirection(Direction direction, boolean set){
		switch(direction){
		case WEST:
		case EAST:
			if(set && !this.minimapScrollDirections.contains(direction)) //not yet set
				this.minimapScrollDirections.add(direction);
			else if(!set)
				this.minimapScrollDirections.remove(direction);
			break;
		case NORTH:
		case SOUTH:
			if(set && !this.minimapScrollDirections.contains(direction)) //not yet set
				this.minimapScrollDirections.add(direction);
			else if(!set)
				this.minimapScrollDirections.remove(direction);
			break;
		default: 
			break; //dummy
		}
	}
	public void scrollMinimap(){
		for(Direction direction : this.minimapScrollDirections){
			switch(direction){
			case WEST:
				if(!this.minimapScrollDirections.contains(Direction.EAST))
					this.minimapScroll.x.value += Constants.MINIMAP_SCROLL_SPEED / 1000 * Constants.TIMER_INTERVAL;
				break;
			case EAST:
				if(!this.minimapScrollDirections.contains(Direction.WEST))
					this.minimapScroll.x.value -= Constants.MINIMAP_SCROLL_SPEED / 1000 * Constants.TIMER_INTERVAL;
				break;
			case NORTH:
				if(!this.minimapScrollDirections.contains(Direction.SOUTH))
					this.minimapScroll.y.value += Constants.MINIMAP_SCROLL_SPEED / 1000 * Constants.TIMER_INTERVAL;
				break;
			case SOUTH:
				if(!this.minimapScrollDirections.contains(Direction.NORTH))
					this.minimapScroll.y.value -= Constants.MINIMAP_SCROLL_SPEED / 1000 * Constants.TIMER_INTERVAL;
				break;
			default:
				break; //dummy
			}
		}
	}
	public Point getMinimapOriginScrollIndex(){
		double dX = this.mario.getLocation().x.value - this.minimapScroll.x.value;
		double dY = this.mario.getLocation().y.value - this.minimapScroll.y.value;
		
		return new Point(getCurMap().getIndex().x + (int)(dX / (Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width)), 
				getCurMap().getIndex().y + (int)(dY / (Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height)));
	}
	
	public List<StoneChainLink> getStoneBallsInMapPart(int x, int y){
		List<StoneChainLink> stoneBalls = new LinkedList<StoneChainLink>();
		
		MapPart curMap = getMap(x + 0, y + 0);
		if(curMap == null)
			return stoneBalls;
		
		for(int i = 0; i < Constants.MAP_PART_SIZE.width; i++)
			for(int j = 0; j < Constants.MAP_PART_SIZE.height; j++)
				if(curMap.getBlockHolder(i, j).getBlock() instanceof StoneBlock)
					stoneBalls.addAll(((StoneBlock)curMap.getBlockHolder(i, j).getBlock()).getStoneBalls());
		
		return stoneBalls;
	}
	public List<StoneChainLink> getStoneChainLinksInMapPart(int x, int y){
		List<StoneChainLink> stoneBalls = new LinkedList<StoneChainLink>();
		
		MapPart curMap = getMap(x + 0, y + 0);
		if(curMap == null)
			return stoneBalls;
		
		for(int i = 0; i < Constants.MAP_PART_SIZE.width; i++)
			for(int j = 0; j < Constants.MAP_PART_SIZE.height; j++)
				if(curMap.getBlockHolder(i, j).getBlock() instanceof StoneBlock)
					stoneBalls.addAll(((StoneBlock)curMap.getBlockHolder(i, j).getBlock()).getChainLinks());
		
		return stoneBalls;
	}
	
	public List<Movable> getMovables(){
		List<Movable> movables = new LinkedList<Movable>();
		movables.add(this.mario);
		movables.addAll(this.koopas);
		movables.addAll(this.mushrooms);
		movables.addAll(this.trampolines);
		return movables;
	}
	public List<Collidable> getNonMovableCollidables(){
		List<Collidable> collidables = new LinkedList<Collidable>();
		collidables.addAll(this.coins);
		collidables.addAll(this.fireBalls);
		return collidables;
	}
	
	public List<Koopa> getKoopas(){
		return this.koopas;
	}
	public List<Trampoline> getTrampolines(){
		return this.trampolines;
	}
	public List<FireBall> getFireballs(){
		return this.fireBalls;
	}
	public List<Coin> getCoins(){
		return this.coins;
	}
	
	public Mario getMario(){
		return this.mario;
	}
	public ActionManager getActionManager(){
		return this.actionManager;
	}
	public List<CnfInfo> getFormulas(){
		return this.formulas;
	}
	public Formula getCurFormula(){
		return this.curFormula;
	}
	public Dimension getNumMapParts(){
		return this.numMapParts;
	}
	public Dimension getGameSize(){
		return this.gameSize;
	}
	public GameState getState(){
		return this.state;
	}
	public boolean isOver(){
		return this.state == GameState.WON || this.state == GameState.LOST;
	}
	public boolean isShowMinimap(){
		return this.isShowMinimap;
	}
	public BlockManager getBlockManager(){
		return this.blockManager;
	}
	/*public ActionManager getActionManager(){
		return this.actionManager;
	}*/
	public long getTime(){
		return this.time;
	}
	public long getScore(){
		return this.score;
	}
	/*public Flag getFlag(){
		return this.flag;
	}*/
	public FinishGate getFinishGate(){
		return this.finishGate;
	}
	public Background getBackground(){
		return this.background;
	}
	public MyPoint getMinimapScroll(){
//		return new MyPoint(this.minimapScroll.x.value % (Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width),
	//			this.minimapScroll.y.value % (Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height));
		return new MyPoint((this.minimapScroll.x.value - this.mario.getLocation().x.value) % (Constants.MAP_PART_SIZE.width * Constants.BLOCK_SIZE.width),
				(this.minimapScroll.y.value - this.mario.getLocation().y.value) % (Constants.MAP_PART_SIZE.height * Constants.BLOCK_SIZE.height));
		//return this.minimapScroll;
	}
	
	public void updateSlideshows(){
		this.mario.updateImage();
		for(Koopa koopa : this.koopas)
			koopa.updateImage();;
		for(Coin coin : this.coins)
			coin.setupSlideshows();
		for(Mushroom mushroom : this.mushrooms)
			mushroom.updateImage();
	}
	
	public void changeSlomoFactor(float factor){
		Constants.SLOMO_FACTOR *= factor;
		if(Constants.SLOMO_FACTOR < 0.2)
			Constants.SLOMO_FACTOR = 0.2f;
		else if(Constants.SLOMO_FACTOR > 3)
			Constants.SLOMO_FACTOR = 3;
	}
	public void setSlomoFactor(float factor){
		Constants.SLOMO_FACTOR = factor;
	}
	
	private void doWork(){
		if(this.state != GameState.PAUSED && this.isCreated && this.getMario() != null && !isOver()){
			this.slideshowManager.incrementTime(this, Constants.TIMER_INTERVAL);
			this.blockManager.incrementTime(Constants.TIMER_INTERVAL);
			this.finishGate.getBar().update();
			
			for(Movable movable : getMovables()){
				//for performance reasons, only consider movables near Mario
				//if(Math.abs(movable.getCurMap().getIndex().x - this.mario.getCurMap().getIndex().x) <= 1 && 
				//		Math.abs(movable.getCurMap().getIndex().y - this.mario.getCurMap().getIndex().y) <= 1){
					movable.move();
					checkCollision(movable);
				//}
			}
			//if(this.flag != null)
			//	this.flag.move();
			
			this.timerTicks++;
			if((this.timerTicks %= (1000/Constants.TIMER_INTERVAL)) == 0)
				this.time++;
		}
		
		if(this.isCreated && this.getMario() != null && this.isShowMinimap)
			scrollMinimap();
	}
	
	public void update(){
		update(ObservableType.GUI_DEFAULT);
	}
	public void update(ObservableType type){
		setChanged();
		notifyObservers(type);
	}
	
	private void startTimerThread(){
		new Thread(new Runnable(){
			private long nextTime;
			private long difference;
			
			@Override
			public void run(){
				int fps = 0;
				long oldTime = System.nanoTime();
				while(Game.this.running){
					try{
						this.nextTime = System.nanoTime() + (long)((Constants.TIMER_INTERVAL * 1000000) / Constants.SLOMO_FACTOR);
						
						doWork();
						update();
						
						if(System.nanoTime() - oldTime > 1000000000){
							//System.out.println("FPS: " + fps);
							fps = 0;
							oldTime = System.nanoTime();
						}else{
							fps++;
						}
						this.difference = this.nextTime - System.nanoTime();
						if(this.difference > 0)
							Thread.sleep(this.difference/1000000, (int)this.difference%1000000);
						else
							System.out.println("Slowed down...");
						
						//while(System.nanoTime() < this.nextTime); //Works much better than Thread.sleep()!
					}catch(Exception e){
						e.printStackTrace();
					}
				}
			}
		}).start();
	}
}