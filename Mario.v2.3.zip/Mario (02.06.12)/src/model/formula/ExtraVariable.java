package model.formula;

import util.VariableState;

public class ExtraVariable extends Variable{
	public ExtraVariable(String name){
		this(name, VariableState.UNDEFINED);
	}
	public ExtraVariable(String name, VariableState state){
		super(name, state);
	}
}