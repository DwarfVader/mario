package model.formula;

import java.util.LinkedList;
import java.util.List;

import util.VariableState;

public class Clause{
	private List<Variable> literals;
	private VariableState satisfied;
	
	public Clause(List<Variable> literals){
		this.literals = new LinkedList<Variable>(literals);
		this.satisfied = VariableState.UNDEFINED;
	}
	
	public boolean containsLiteral(String variableName, VariableState state){
		for(Variable variable : this.literals)
			if(variable.getName().equals(variableName) && variable.getState() == state)
				return true;
		
		return false;
	}
	
	public void setSatisfied(VariableState satisfied){
		this.satisfied = satisfied;
	}
	
	public List<Variable> getLiterals(){
		return this.literals;
	}
	public Variable getLiteral(int index){
		if(index < 0 || index >= this.literals.size())
			return null;
		
		return this.literals.get(index);
	}
	public VariableState getSatisfied(){
		return this.satisfied;
	}
}