package model.formula;

public class ClosingBracket implements Token{
	public ClosingBracket(){}
}