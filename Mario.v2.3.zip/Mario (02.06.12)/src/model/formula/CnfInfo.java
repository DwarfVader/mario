package model.formula;

public class CnfInfo{
	private FormulaStateInfo formulaStateInfo;
	private QuantifierInfo quantifierInfo;
	
	public CnfInfo(FormulaStateInfo formulaStateInfo, QuantifierInfo quantifierInfo){
		this.formulaStateInfo = formulaStateInfo;
		this.quantifierInfo = quantifierInfo;
	}
	
	public FormulaStateInfo getFormulaStateInfo(){
		return this.formulaStateInfo;
	}
	public QuantifierInfo getQuantifierInfo(){
		return this.quantifierInfo;
	}
}