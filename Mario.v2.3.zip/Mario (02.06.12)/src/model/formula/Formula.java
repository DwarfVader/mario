package model.formula;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;

import model.Game;
import model.action.ClauseAction;
import model.action.VariableAction;
import model.blocks.VariableAssignmentBlock;
import util.ColoredString;
import util.Constants;
import util.ObservableType;
import util.VariableState;

public class Formula{
	private Game game;
	private List<Variable> variables;
	private List<Clause> clauses;
	private CnfInfo cnfInfo;
	private QuantifierInfo quantInfo;
	
	public Formula(Game game, CnfInfo cnfInfo){
		this.game = game;
		this.variables = new LinkedList<Variable>();
		this.clauses = new LinkedList<Clause>();
		this.cnfInfo = cnfInfo;
		this.quantInfo = null;
	}
	private void collectQuantifierInfo(){
		QuantifierInfo quantInfo = new QuantifierInfo();
		//QuantifierType curQuantType;
		/* Take useful information from origQuantInfo. This means, only consider information about 
		 * variables that actually occur in the formula. Ignore information about unused variables. 
		 * Treat free variables as existentially quantified. */
		/*for(Variable variable : this.variables){
			curQuantType = this.cnfInfo.getQuantifierInfo().getQuantifierType(variable.getName());
			curQuantType = curQuantType != null ? curQuantType : QuantifierType.EXISTENTIAL;
			quantInfo.putVariableMapping(variable.getName(), curQuantType);
		}*/
		
		//fill new map with variable names in specified order of prefix
		for(String name : this.cnfInfo.getQuantifierInfo().getVariableNamesOrdered()){
			//check whether there is a variable called name; if so, put in new map
			for(Variable variable : this.variables)
				if(variable.getName().equals(name))
					quantInfo.putVariableMapping(name, this.cnfInfo.getQuantifierInfo().getQuantifierType(name));
		}
		
		//add missing (free) variables as existentially quantified to the map (order of insertion is kept internally)
		for(int i = this.variables.size()-1; i >= 0; i--)
			if(!quantInfo.getVariableNamesOrdered().contains(this.variables.get(i).getName()))
				quantInfo.putVariableMapping(this.variables.get(i).getName(), QuantifierType.EXISTENTIAL, true);
		
		this.quantInfo = quantInfo;
	}
	
	public void addClause(Clause clause){
		this.clauses.add(clause);
		
		updateVariables(clause);
	}
	
	public void updateVariables(){
		updateVariables(this.clauses);
	}
	public void updateVariables(Clause clause){
		List<Clause> relevantClauses = new LinkedList<Clause>();
		relevantClauses.add(clause);
		updateVariables(relevantClauses);
	}
	public void updateVariables(List<Clause> relevantClauses){
		boolean alreadyKnown;
		for(Clause clause : relevantClauses)
			for(Variable otherVariable : clause.getLiterals()){ //probably new variable
				alreadyKnown = false;
				for(Variable variable : this.variables) //already known variable
					if(variable.getName().equals(otherVariable.getName())){
						alreadyKnown = true;
						break;
					}
				
				/* 
				 * If variable name is not known yet, a new variable object will be added, 
				 * since all variables occuring in clauses have already been set to their 
				 * "target" value (, which variables will be checked against after making 
				 * a decision). 
				 */
				if(!alreadyKnown){
					if(otherVariable instanceof NormalVariable)
						this.variables.add(new NormalVariable(otherVariable.getName()));
					else
						this.variables.add(new ExtraVariable(otherVariable.getName()));
				}
			}
	}
	
	/** Reused for Hardcore mode! */
	public List<ColoredString> getColoredOriginalExpression(){
		return this.cnfInfo.getFormulaStateInfo().getOriginalExpression().getColoredStrings(this);
	}
	public String print(){
		String result = "";
		List<ColoredString> coloredStrings;
		
		if(this.quantInfo != null) //QBF
			coloredStrings = getColoredClauseStringsPSPACE();
		else
			coloredStrings = getColoredClauseStringsNP();
		
		for(ColoredString coloredString : coloredStrings)
			result = result.concat(coloredString.getString());
		
		return result;
	}
	public List<ColoredString> getColoredClauseStrings(){
		if(this.quantInfo != null) //QBF
			return getColoredClauseStringsPSPACE();
		else
			return getColoredClauseStringsNP();
	}
	public List<ColoredString> getColoredClauseStringsNP(){
		List<ColoredString> coloredStrings = new LinkedList<ColoredString>();
		
		Clause clause;
		Variable literal;
		VariableState assignment;
		for(int c = 0; c < this.clauses.size(); c++){
			clause = this.clauses.get(c);
			coloredStrings.add(new ColoredString("(", Color.WHITE));
			
			switch(clause.getSatisfied()){
			case TRUE:
				coloredStrings.add(new ColoredString("T", Color.GREEN));
				break;
			case FALSE:
				coloredStrings.add(new ColoredString("F", Color.RED));
				break;
			case UNDEFINED:
				for(int l = 0; l < clause.getLiterals().size(); l++){
					literal = clause.getLiteral(l);
					assignment = getVariable(literal.getName()).getSatisfied();
					
					//check literal state against decision of player
					if(assignment != VariableState.UNDEFINED && literal.getState() != assignment)
						coloredStrings.add(new ColoredString("F", Color.RED));
					else
						coloredStrings.add(new ColoredString((literal.getState() == VariableState.FALSE ? Constants.NOT : "") + 
								literal.getName(), Color.WHITE));
					
					if(l < clause.getLiterals().size() - 1)
						coloredStrings.add(new ColoredString(" " + Constants.OR + " ", Color.WHITE));
				}
				break;
			}
			
			if(c == this.clauses.size()-1)
				coloredStrings.add(new ColoredString(")", Color.WHITE));
			else
				coloredStrings.add(new ColoredString(") " + Constants.AND + " ", Color.WHITE));
		}
		
		return coloredStrings;
	}
	public List<ColoredString> getColoredClauseStringsPSPACE(){
		List<ColoredString> coloredStrings = new LinkedList<ColoredString>();
		
		Clause clause;
		Variable literal;
		for(int c = 0; c < this.clauses.size(); c++){
			clause = this.clauses.get(c);
			coloredStrings.add(new ColoredString("(", Color.WHITE));
			
			for(int l = 0; l < clause.getLiterals().size(); l++){
				literal = clause.getLiteral(l);
				
				//check literal state
				coloredStrings.add(new ColoredString((literal.getState() == VariableState.FALSE ? Constants.NOT : "") + 
						literal.getName(), literal.getSatisfied() == VariableState.UNDEFINED ? Color.WHITE : 
						(literal.getSatisfied() == VariableState.TRUE ? Color.GREEN : Color.RED)));
				
				if(l < clause.getLiterals().size() - 1)
					coloredStrings.add(new ColoredString(" " + Constants.OR + " ", Color.WHITE));
			}
			
			if(c == this.clauses.size()-1)
				coloredStrings.add(new ColoredString(")", Color.WHITE));
			else
				coloredStrings.add(new ColoredString(") " + Constants.AND + " ", Color.WHITE));
		}
		
		return coloredStrings;
	}
	
	public List<Clause> getClausesContaining(String variableName, VariableState state){
		List<Clause> clauses = new LinkedList<Clause>();
		
		for(Clause clause : this.clauses)
			if(clause.containsLiteral(variableName, state))
				clauses.add(clause);
		
		return clauses;
	}
	
	public List<Variable> getNormalVariables(){
		List<Variable> normalVariables = new LinkedList<Variable>();
		for(Variable variable : this.variables)
			if(variable instanceof NormalVariable)
				normalVariables.add(variable);
		return normalVariables;
	}
	public Variable getNormalVariable(int index){
		List<Variable> normalVariables = getNormalVariables();
		if(index < 0 || index >= normalVariables.size())
			return null;
		
		return normalVariables.get(index);
	}
	public Variable getVariable(String name){
		for(Variable variable : this.variables)
			if(variable.getName().equals(name))
				return variable;
		
		//no such variable
		return null;
	}
	public List<Clause> getClauses(){
		return this.clauses;
	}
	public Clause getClause(int index){
		if(index < 0 || index >= this.clauses.size())
			return null;
		
		return this.clauses.get(index);
	}
	public CnfInfo getCnfInfo(){
		return this.cnfInfo;
	}
	public QuantifierInfo getQuantifierInfo(){
		return this.quantInfo;
	}
	public QuantifierType getQuantifierInfo(String variable){
		return this.quantInfo.getQuantifierType(variable);
	}
	public QuantifierInfo getOrigQuantifierInfo(){
		return this.cnfInfo.getQuantifierInfo();
	}
	public QuantifierType getOrigQuantifierInfo(String variable){
		return this.cnfInfo.getQuantifierInfo().getQuantifierType(variable);
	}
	
	public static Formula createFormula(Game game, CnfInfo cnfInfo){
		Formula formula = new Formula(game, cnfInfo);
		
		String clauseStrings[] = cnfInfo.getFormulaStateInfo().getFormula().split("[" + Constants.AND + "]");
		String variableStrings[];
		String curString;
		List<Variable> variableList = new LinkedList<Variable>();
		for(String clauseString : clauseStrings){
			variableList.clear();
			variableStrings = removeSurroundingBrackets(clauseString.trim()).split("[" + Constants.OR + "]"); //TODO: Improve that.
			for(String variableString : variableStrings){
				curString = variableString.trim();
				if(curString.charAt(0) == Constants.NOT){ //negated variable
					curString = curString.substring(1);
					variableList.add(new NormalVariable(curString, VariableState.FALSE));
				}else{ //non-negated variable
					variableList.add(new NormalVariable(curString, VariableState.TRUE));
				}
			}
			formula.addClause(new Clause(variableList));
		}
		//in case of prenex normal form declaration, this will not be null; do NOT call collectQuantifierInfo() in the other case
		if(cnfInfo.getQuantifierInfo() != null)
			formula.collectQuantifierInfo();
		
		//in case of QSAT: NEED to sort literal within clauses according to variable order in quant info
		if(cnfInfo.getQuantifierInfo() != null)
			formula.sortLiteralsWithinClauses();
		
		return formula;
	}
	
	/** If literals within clauses are not sorted according to quantifier/variable order in quant info, 
	 * the following special case could break the game (crossovers are missing): 
	 * Literal x occurring in last clause crosses literal path y, with y < x, which also occurs in last clause 
	 * but after/right of x. NO crossover will be inserted as crossover creation assumes literals within 
	 * clauses sorted, such that literal paths of x and y would not cross each other. */
	private void sortLiteralsWithinClauses(){
		if(Formula.this.quantInfo == null)
			return;
		
		for(Clause clause : Formula.this.clauses)
			Collections.sort(clause.getLiterals(), new Comparator<Variable>(){
				@Override
				public int compare(Variable arg0, Variable arg1){
					return Formula.this.quantInfo.getIndexOf(arg0.getName()) - Formula.this.quantInfo.getIndexOf(arg1.getName());
				}
			});
	}
	
	private static String removeSurroundingBrackets(String string){
		if(string.charAt(0) == '(' && string.charAt(string.length()-1) == ')')
			return string.substring(1, string.length()-1);
		return string;
	}
	
	public static boolean isValid(String string){
		return getCnfString(string) != null;
	}
	
	public static CnfInfo getCnf(String string){
		string = string.replaceAll("[\\r\\n]", " "); //remove new line characters
		string = string.replaceAll("[\\s]+", " "); //remove multiple white spaces
		string = string.trim();
		
		String parts[] = string.split(":");
		String matrixPart = "", prefixPart = "";
		QuantifierInfo quantInfo = null;
		switch(parts.length){
		case 1: //quantInfo will be returned as null if matrix part works; this is used in MainController
			matrixPart = parts[0];
			break;
		case 2: //TODO: check for correct order: prefix first, matrix second
			prefixPart = parts[0];
			matrixPart = parts[1];
			quantInfo = createQuantifierInfo(prefixPart);
			if(quantInfo == null) //problem with prefix
				return new CnfInfo(new FormulaStateInfo(null, null, FormulaState.INVALID_PREFIX), null);
			break;
		default: //invalid input: multiple colons
			return new CnfInfo(new FormulaStateInfo(null, null, FormulaState.INVALID_PREFIX), null);
		}
		
		//input successfully parsed
		return new CnfInfo(simplify(getFormattedString(getCnfString(matrixPart))), quantInfo);
	}
	public static List<CnfInfo> get3CnfStrings(String string){
		List<CnfInfo> list = new LinkedList<CnfInfo>();
		list.add(getCnf(string));
		return list;
	}
	
	
	public static FormulaFileInfo getFormulaFileInfo(File file){
		File files[] = new File [1];
		files[0] = file;
		return getFormulaFileInfo(files);
	}
	public static FormulaFileInfo getFormulaFileInfo(File files[]){
		List<CnfInfo> formulas = new LinkedList<CnfInfo>();
		String infoString = "";
		FormulaFileInfo curFormulaFileInfo;
		
		for(File file : files){
			if(file.getName().toLowerCase().endsWith(".frm")){
				curFormulaFileInfo = getFormulaFileInfoFrm(file);
				formulas.addAll(curFormulaFileInfo.getFormulas());
				infoString += curFormulaFileInfo.getInfoString();
			}else if(file.getName().toLowerCase().endsWith(".cnf")){
				curFormulaFileInfo = getFormulaFileInfoCnf(file);
				if(curFormulaFileInfo.getFormulas() != null && 
						curFormulaFileInfo.getFormulas().get(0).getFormulaStateInfo().getState() == FormulaState.VALID)
					formulas.add(curFormulaFileInfo.getFormulas().get(0)); //TODO: improve that in getFormulaFileInfoCnf()
				infoString += curFormulaFileInfo.getInfoString();
			}
		}
		
		return new FormulaFileInfo(formulas, infoString, Color.RED);
	}
	public static FormulaFileInfo getFormulaFileInfoFrm(File file){	
		List<CnfInfo> list = new LinkedList<CnfInfo>();
		String infoString = "";
		
		if(!file.getName().toLowerCase().endsWith(".frm"))
			return new FormulaFileInfo(list, "This is no '.frm' file.");
		
		try{
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line, tokens[];
			CnfInfo cnfInfo;
			int lineCount = 0;
			while((line = reader.readLine()) != null){
				lineCount++;
				
				tokens = line.split(" ");
				if(tokens.length > 0 && tokens[0].compareToIgnoreCase("frm") == 0) //line containing formula
					line = line.replaceFirst("frm", ""); //delete "frm" token
				else
					continue; //ignore comment or empty lines
				
				switch((cnfInfo = getCnf(line)).getFormulaStateInfo().getState()){
				case VALID:
					list.add(cnfInfo);
					break;
				case INVALID_MATRIX:
					//inform user about invalid formulas in file
					//reader.close();
					//return new FormulaFileInfo(null, "Error: Invalid formula in line " + lineCount + 
					//		" in file " + file.getName() + ".\n");
					infoString = infoString.concat("Error: Invalid formula in line " + lineCount + 
							" in file " + file.getName() + ".\n");
				case TAUTOLOGY:
					infoString = infoString.concat("Warning: Tautology in line " + lineCount + 
							" in file " + file.getName() + ".\n");
					break; //ignore tautologies, if they appear in files
				default:
					break;
				}
			}
			
			reader.close();
		}catch(Exception e){
			e.printStackTrace();
			return new FormulaFileInfo(list, "Error: File '" + file.getName() + "' could not be read.");
		}
		
		return new FormulaFileInfo(list, infoString);
	}
	public static FormulaFileInfo getFormulaFileInfoCnf(File file){
		List<CnfInfo> list = new LinkedList<CnfInfo>();
		String infoString = "";
		
		if(!file.getName().toLowerCase().endsWith(".cnf"))
			return new FormulaFileInfo(list, "This is no '.cnf' file.");
		
		List<String> tokens = new LinkedList<String>();
		
		try{
			BufferedReader reader = new BufferedReader(new FileReader(file));
			
			//read tokens from file
			String line, curTokens[];
			boolean inPreamble = true;
			int lineCount = 0;
			while((line = reader.readLine()) != null){
				lineCount++;
				
				curTokens = line.split(" ");
				if(line.isEmpty() || 
						(curTokens.length > 0 && curTokens[0].compareToIgnoreCase("c") == 0))
					continue; //ignore empty or comment lines
				else if(curTokens.length > 0 && curTokens[0].compareToIgnoreCase("p") == 0){
					if(inPreamble)
						inPreamble = false;
					else{
						reader.close();
						return new FormulaFileInfo(null, "Error: Multiple problem declaration (p) in line " + lineCount + ".");
					}
				}
				
				tokens.addAll(Arrays.asList(curTokens));
			}
			reader.close();
		}catch(Exception e){
			e.printStackTrace();
			return new FormulaFileInfo(null, "Error: File '" + file.getName() + "' could not be read.");
		}
		
		//check and parse tokens; create formula string
		int /*variableCount = 0,*/ expectedClauseCount = 0, actualClauseCount = 0;
		List<String> clauses = new LinkedList<String>();
		String curClause = "", curVariable = "";
		String formula = "";
		boolean negated = false;
		
		int curToken = 0;
		//check problem declaration
		for(int i = 0; i < 4; i++){
			switch(i){
			case 0:
				if(tokens.get(i).compareToIgnoreCase("p") != 0)
					return new FormulaFileInfo(null, "Error: File has to begin with " +
							"(p [FORMAT] [#VARIABLES] [#CLAUSES]).");
				break;
			case 1:
				if(tokens.get(i).compareToIgnoreCase("cnf") != 0)
					return new FormulaFileInfo(null, "Error: The format of the problem declaration has to be 'cnf'.");
				break;
			case 2:
				try{
					//variableCount = Integer.parseInt(tokens.get(i));
				}catch(Exception e){
					return new FormulaFileInfo(null, "Error: The number of variables has to be a whole number.");
				}
				break;
			case 3:
				try{
					expectedClauseCount = Integer.parseInt(tokens.get(i));
				}catch(Exception e){
					return new FormulaFileInfo(null, "Error: The number of clauses has to be a whole number.");
				}
				break;
			}
			
			curToken++;
		}
		
		QuantifierInfo quantInfo = new QuantifierInfo();
		/* Check for quantified sets; allow contiguous 'e' or 'a' sets; to achieve quantifier order, allow multiple 
		 * 'e' or 'a' sets */
		int curValue;
		while(tokens.get(curToken).compareToIgnoreCase("e") == 0 || 
				tokens.get(curToken).compareToIgnoreCase("a") == 0){
			if(tokens.get(curToken).compareToIgnoreCase("e") == 0){
				curToken++; //skip 'e'
				while(tokens.get(curToken).compareToIgnoreCase("0") != 0){ //end of line not yet reached
					try{
						curValue = Integer.parseInt(tokens.get(curToken));
					}catch(Exception e){
						return new FormulaFileInfo(null, "Error: Integer values needed in quantified sets.");
					}
					if(quantInfo.getIndexOf("x" + curValue) != -1)
						return new FormulaFileInfo(null, "Error: Multiply quantified variables not allowed.");
					quantInfo.putVariableMapping("x" + curValue, QuantifierType.EXISTENTIAL);
					curToken++;
				}
				curToken++; //skip '0'
			}else if(tokens.get(curToken).compareToIgnoreCase("a") == 0){
				curToken++; //skip 'a'
				while(tokens.get(curToken).compareToIgnoreCase("0") != 0){ //end of line not yet reached
					try{
						curValue = Integer.parseInt(tokens.get(curToken));
					}catch(Exception e){
						return new FormulaFileInfo(null, "Error: Integer values needed in quantified sets.");
					}
					if(quantInfo.getIndexOf("x" + curValue) != -1)
						return new FormulaFileInfo(null, "Error: Multiply quantified variables not allowed.");
					quantInfo.putVariableMapping("x" + curValue, QuantifierType.UNIVERSAL);
					curToken++;
				}
				curToken++; //skip '0'
			}
		}
		
		//rest of tokens defines clauses
		for(int i = curToken; i < tokens.size(); i++){
			switch(i){
			default:
				if(tokens.get(i).compareToIgnoreCase("0") == 0){ //end of clause
					clauses.add("(" + curClause + ")");
					actualClauseCount++;
					curClause = "";
				}else{
					if(tokens.get(i).charAt(0) == '-'){ //negated variable
						negated = true;
						curVariable = tokens.get(i).substring(1);
					}else{
						negated = false;
						curVariable = tokens.get(i);
					}
					
					try{
						if(curClause.isEmpty()) //first variable in clause
							curClause = curClause.concat((negated ? Constants.NOT : "") + 
									"x" + Integer.parseInt(curVariable));
						else //later variable in clause
							curClause = curClause.concat(" " + Constants.OR + " " + (negated ? Constants.NOT : "") + 
									"x" + Integer.parseInt(curVariable));
					}catch(Exception e){
						return new FormulaFileInfo(null, "Error: Variables have to be whole numbers (>= 1).");
					}
				}
			}
		}
		for(String clause : clauses){
			if(formula.isEmpty())
				formula = formula.concat(clause);
			else
				formula = formula.concat(" " + Constants.AND + " " + clause);
		}
		
		//quant info needs to be null in order to recognize the formula as CNF/SAT
		if(quantInfo.getVariableNamesOrdered().isEmpty())
			quantInfo = null;
		list.add(new CnfInfo(new FormulaStateInfo(formula, makeExpression(createTokens(formula)), FormulaState.VALID), 
				quantInfo)); 
		if(actualClauseCount != expectedClauseCount)
			infoString = infoString.concat("Warning: Number of clauses in problem declaration " +
					"does not match the actual number.");
		
		return new FormulaFileInfo(list, infoString, Color.GREEN);
	}
	
	private static QuantifierInfo createQuantifierInfo(String prenexString){
		QuantifierInfo quantifierInfo = new QuantifierInfo();
		
		if(prenexString.length() == 0)
			return quantifierInfo;
		
		String quantVars[] = prenexString.split(" ");
		for(String quantVar : quantVars){
			if(quantVar.length() < 2) //quantifier + variable name
				return null;
			
			switch(quantVar.charAt(0)){
			case 'A':
				for(String name : extractVariableNames(quantVar.substring(1)))
					quantifierInfo.putVariableMapping(name, QuantifierType.UNIVERSAL);
				break;
			case 'E':
				for(String name : extractVariableNames(quantVar.substring(1)))
					quantifierInfo.putVariableMapping(name, QuantifierType.EXISTENTIAL);
				break;
			default: //quantifier missing: do not accept
				return null;
			}
		}
		
		return quantifierInfo;
	}
	private static List<String> extractVariableNames(String quantString){
		List<String> names = new LinkedList<String>();
		
		String quantNames[] = quantString.split(",");
		for(String name : quantNames)
			if(!name.equals(""))
				names.add(name);
		
		return names;
	}
	
	private static FormulaStateInfo getCnfString(String string){
		string = string.replaceAll("[\\r\\n]", " "); //remove new line characters
		string = string.replaceAll("[\\s]+", " "); //remove multiple white spaces
		
		Expression origExpression = makeExpression(createTokens(string));
		if(origExpression == null)
			return new FormulaStateInfo(null, null, FormulaState.INVALID_MATRIX);
		else
			System.out.println(origExpression);
		
		Expression expression = cnf(nnf(implFree(xorFree(origExpression))));
		
		String formula = expression.toString();
		if(formula == null || formula.isEmpty())
			return new FormulaStateInfo(null, null, FormulaState.INVALID_MATRIX);
		else
			return new FormulaStateInfo(formula, origExpression, FormulaState.VALID);
	}
	public static List<Token> createTokens(String string){
		List<Token> tokens = new LinkedList<Token>();
		
		int startIndex = -1;
		for(int i = 0; i < string.length(); i++){
			switch(string.charAt(i)){
			case '(':
				tokens.add(new OpeningBracket());
				break;
			case ')':
				tokens.add(new ClosingBracket());
				break;
			case Constants.OR_1:
			case Constants.OR_2:
				tokens.add(new OrOperator());
				break;
			case Constants.AND_1:
			case Constants.AND_2:
				tokens.add(new AndOperator());
				break;
			case Constants.NOT_1:
			case Constants.NOT_2:
				tokens.add(new NotOperator());
				break;
			case Constants.IMPLICATION_1:
				tokens.add(new ImplicationOperator());
				break;
			case Constants.XOR_1:
				tokens.add(new XorOperator());
				break;
			case ' ':
				break;
			default:
				if(Character.isLetter(string.charAt(i)) || 
						Character.isDigit(string.charAt(i))){ //variable begins
					if(startIndex == -1) //remember index to build variable name string later
						startIndex = i;
					
					if(i == string.length()-1 || //not the last character and next character not allowed for variables
							(!Character.isLetter(string.charAt(i+1)) && !Character.isDigit(string.charAt(i+1)))){
						tokens.add(new Atom(string.substring(startIndex, i+1) + ""));
						startIndex = -1;
					}
				}else //illegal character
					return null;
			}
		}
		
		return tokens;
	}
	public static Expression makeExpression(List<Token> tokens){
		if(tokens == null || tokens.isEmpty())
			return null;
		
		//literal check
		if(tokens.size() == 1 && tokens.get(0) instanceof Atom)
			return (Atom)tokens.get(0);
		
		//surrounding bracket check; perform before XOR-check
		int openBrackets = 0;
		if(tokens.get(0) instanceof OpeningBracket && tokens.get(tokens.size()-1) instanceof ClosingBracket){
			/* Remove surrounding brackets, iff they relate to each other. */
			boolean canRemove = true;
			for(int i = 0; i < tokens.size(); i++){
				if(tokens.get(i) instanceof OpeningBracket)
					openBrackets++;
				else if(tokens.get(i) instanceof ClosingBracket)
					openBrackets--;
				
				if(openBrackets <= 0 && i < tokens.size()-1){ //first opening bracket got closed too early
					canRemove = false;
					break;
				}
			}
			
			if(canRemove)
				return makeExpression(tokens.subList(1, tokens.size()-1)); //upper limit is exclusive
		}
		
		//XOR-check; perform bevore implication-check
		openBrackets = 0;
		for(int i = 0; i < tokens.size(); i++){
			if(tokens.get(i) instanceof OpeningBracket)
				openBrackets++;
			else if(tokens.get(i) instanceof ClosingBracket)
				openBrackets--;
			else if(tokens.get(i) instanceof XorOperator && openBrackets == 0){
				try{
					List<Token> subList1 = new LinkedList<Token>(tokens.subList(0, i)); //upper limit is exclusive
					List<Token> subList2 = new LinkedList<Token>(tokens.subList(i+1, tokens.size())); //upper limit is exclusive
					Expression expression1 = makeExpression(subList1);
					Expression expression2 = makeExpression(subList2);
					
					if(expression1 != null && expression2 != null)
						return new BinaryExpression(new XorOperator(), expression1, expression2);
					
					return null;
				}catch(Exception e){
					return null; //misplaced operator
				}
			}
		}
		
		//implication-check; perform before OR-check
		openBrackets = 0;
		for(int i = 0; i < tokens.size(); i++){
			if(tokens.get(i) instanceof OpeningBracket)
				openBrackets++;
			else if(tokens.get(i) instanceof ClosingBracket)
				openBrackets--;
			else if(tokens.get(i) instanceof ImplicationOperator && openBrackets == 0){
				try{
					List<Token> subList1 = new LinkedList<Token>(tokens.subList(0, i)); //upper limit is exclusive
					List<Token> subList2 = new LinkedList<Token>(tokens.subList(i+1, tokens.size())); //upper limit is exclusive
					Expression expression1 = makeExpression(subList1);
					Expression expression2 = makeExpression(subList2);
					
					if(expression1 != null && expression2 != null)
						return new BinaryExpression(new ImplicationOperator(), expression1, expression2);
					
					return null;
				}catch(Exception e){
					return null; //misplaced operator
				}
			}
		}
		
		//OR-check; perform before AND-check
		openBrackets = 0;
		for(int i = 0; i < tokens.size(); i++){
			if(tokens.get(i) instanceof OpeningBracket)
				openBrackets++;
			else if(tokens.get(i) instanceof ClosingBracket)
				openBrackets--;
			else if(tokens.get(i) instanceof OrOperator && openBrackets == 0){
				try{
					List<Token> subList1 = new LinkedList<Token>(tokens.subList(0, i)); //upper limit is exclusive
					List<Token> subList2 = new LinkedList<Token>(tokens.subList(i+1, tokens.size())); //upper limit is exclusive
					Expression expression1 = makeExpression(subList1);
					Expression expression2 = makeExpression(subList2);
					
					if(expression1 != null && expression2 != null)
						return new BinaryExpression(new OrOperator(), expression1, expression2);
					
					return null;
				}catch(Exception e){
					return null; //misplaced operator
				}
			}
		}
		
		//no OR -> AND-check
		openBrackets = 0;
		for(int i = 0; i < tokens.size(); i++){
			if(tokens.get(i) instanceof OpeningBracket)
				openBrackets++;
			else if(tokens.get(i) instanceof ClosingBracket)
				openBrackets--;
			else if(tokens.get(i) instanceof AndOperator && openBrackets == 0){
				try{
					List<Token> subList1 = new LinkedList<Token>(tokens.subList(0, i)); //upper limit is exclusive
					List<Token> subList2 = new LinkedList<Token>(tokens.subList(i+1, tokens.size())); //upper limit is exclusive
					Expression expression1 = makeExpression(subList1);
					Expression expression2 = makeExpression(subList2);
					
					if(expression1 != null && expression2 != null)
						return new BinaryExpression(new AndOperator(), expression1, expression2);
					
					return null;
				}catch(Exception e){
					return null; //misplaced operator
				}
			}
		}
		
		//neiter OR nor AND -> NOT-check
		if(tokens.get(0) instanceof NotOperator){
			try{
				List<Token> subList = new LinkedList<Token>(tokens.subList(1, tokens.size())); //upper limit is exclusive
				Expression expression = makeExpression(subList);
				
				if(expression != null)
					return new UnaryExpression(new NotOperator(), expression);
				
				return null;
			}catch(Exception e){
				return null; //misplaced operator
			}
		}
		
		return null;
	}
	
	private static Expression xorFree(Expression expression){
		if(expression instanceof Atom)
			return expression;
		if(expression instanceof UnaryExpression && ((UnaryExpression)expression).getOperator() instanceof NotOperator)
			return new UnaryExpression(new NotOperator(), 
					xorFree(((UnaryExpression)expression).getExpression()));
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof AndOperator)
			return new BinaryExpression(new AndOperator(), 
					xorFree(((BinaryExpression)expression).getExpression1()), 
					xorFree(((BinaryExpression)expression).getExpression2()));
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof OrOperator)
			return new BinaryExpression(new OrOperator(), 
					xorFree(((BinaryExpression)expression).getExpression1()), 
					xorFree(((BinaryExpression)expression).getExpression2()));
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof ImplicationOperator)
			return new BinaryExpression(new ImplicationOperator(), 
					xorFree(((BinaryExpression)expression).getExpression1()), 
					xorFree(((BinaryExpression)expression).getExpression2()));
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof XorOperator)
			return new BinaryExpression(new OrOperator(), 
					new BinaryExpression(new AndOperator(), 
							xorFree(((BinaryExpression)expression).getExpression1()), 
							new UnaryExpression(new NotOperator(), 
									xorFree((((BinaryExpression)expression).getExpression2())))), 
					new BinaryExpression(new AndOperator(), 
							new UnaryExpression(new NotOperator(), 
									xorFree((((BinaryExpression)expression).getExpression1()))), 
							xorFree(((BinaryExpression)expression).getExpression2())));
		
		return null; //dummy
	}
	private static Expression implFree(Expression expression){
		if(expression instanceof Atom)
			return expression;
		if(expression instanceof UnaryExpression && ((UnaryExpression)expression).getOperator() instanceof NotOperator)
			return new UnaryExpression(new NotOperator(), 
					implFree(((UnaryExpression)expression).getExpression()));
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof AndOperator)
			return new BinaryExpression(new AndOperator(), 
					implFree(((BinaryExpression)expression).getExpression1()), 
					implFree(((BinaryExpression)expression).getExpression2()));
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof OrOperator)
			return new BinaryExpression(new OrOperator(), 
					implFree(((BinaryExpression)expression).getExpression1()), 
					implFree(((BinaryExpression)expression).getExpression2()));
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof ImplicationOperator)
			return new BinaryExpression(new OrOperator(), 
					new UnaryExpression(new NotOperator(), 
							implFree(((BinaryExpression)expression).getExpression1())), //Fuck! Forgot implFree()...
					implFree(((BinaryExpression)expression).getExpression2()));
		
		return null; //dummy
	}
	private static Expression nnf(Expression expression){
		if(expression instanceof Atom || (expression instanceof UnaryExpression && 
				((UnaryExpression)expression).getOperator() instanceof NotOperator && 
				((UnaryExpression)expression).getExpression() instanceof Atom))
			return expression; //an atom or its negation
		if(expression instanceof UnaryExpression && ((UnaryExpression)expression).getOperator() instanceof NotOperator && 
				((UnaryExpression)expression).getExpression() instanceof UnaryExpression && 
				((UnaryExpression)((UnaryExpression)expression).getExpression()).getOperator() instanceof NotOperator)
			return nnf(((UnaryExpression)((UnaryExpression)expression).getExpression()).getExpression()); //double negation elimination
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof AndOperator)
			return new BinaryExpression(new AndOperator(), 
					nnf(((BinaryExpression)expression).getExpression1()), 
					nnf(((BinaryExpression)expression).getExpression2()));
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof OrOperator)
			return new BinaryExpression(new OrOperator(), 
					nnf(((BinaryExpression)expression).getExpression1()), 
					nnf(((BinaryExpression)expression).getExpression2()));
		//De Morgan's law 1
		if(expression instanceof UnaryExpression && ((UnaryExpression)expression).getOperator() instanceof NotOperator && 
				((UnaryExpression)expression).getExpression() instanceof BinaryExpression && 
				((BinaryExpression)((UnaryExpression)expression).getExpression()).getOperator() instanceof AndOperator)
			return new BinaryExpression(new OrOperator(), 
					nnf(new UnaryExpression(new NotOperator(), 
							((BinaryExpression)((UnaryExpression)expression).getExpression()).getExpression1())), 
					nnf(new UnaryExpression(new NotOperator(), 
							((BinaryExpression)((UnaryExpression)expression).getExpression()).getExpression2())));
		//De Morgan's law 2
		if(expression instanceof UnaryExpression && ((UnaryExpression)expression).getOperator() instanceof NotOperator && 
				((UnaryExpression)expression).getExpression() instanceof BinaryExpression && 
				((BinaryExpression)((UnaryExpression)expression).getExpression()).getOperator() instanceof OrOperator)
			return new BinaryExpression(new AndOperator(), 
					nnf(new UnaryExpression(new NotOperator(), 
							((BinaryExpression)((UnaryExpression)expression).getExpression()).getExpression1())), 
					nnf(new UnaryExpression(new NotOperator(), 
							((BinaryExpression)((UnaryExpression)expression).getExpression()).getExpression2())));
		
		return null; //dummy
	}
	private static Expression cnf(Expression expression){
		if(expression instanceof Atom || (expression instanceof UnaryExpression && 
				((UnaryExpression)expression).getOperator() instanceof NotOperator && 
				((UnaryExpression)expression).getExpression() instanceof Atom))
			return expression; //an atom or its negation
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof AndOperator)
			return new BinaryExpression(new AndOperator(), 
					cnf(((BinaryExpression)expression).getExpression1()), 
					cnf(((BinaryExpression)expression).getExpression2()));
		if(expression instanceof BinaryExpression && ((BinaryExpression)expression).getOperator() instanceof OrOperator)
			return distr( 
					cnf(((BinaryExpression)expression).getExpression1()), 
					cnf(((BinaryExpression)expression).getExpression2()));
		
		return null; //dummy
	}
	private static Expression distr(Expression expression1, Expression expression2){
		if(expression1 instanceof BinaryExpression && ((BinaryExpression)expression1).getOperator() instanceof AndOperator)
			return new BinaryExpression(new AndOperator(), 
					distr(((BinaryExpression)expression1).getExpression1(), expression2), 
					distr(((BinaryExpression)expression1).getExpression2(), expression2));
		if(expression2 instanceof BinaryExpression && ((BinaryExpression)expression2).getOperator() instanceof AndOperator)
			return new BinaryExpression(new AndOperator(), 
					distr(expression1, ((BinaryExpression)expression2).getExpression1()), 
					distr(expression1, ((BinaryExpression)expression2).getExpression2()));
		
		return new BinaryExpression(new OrOperator(), expression1, expression2); //otherwise
	}
	
	public static FormulaStateInfo getFormattedString(FormulaStateInfo formulaStateInfo){
		if(formulaStateInfo.getState() != FormulaState.VALID)
			return formulaStateInfo;
		
		String string = formulaStateInfo.getFormula();
		
		/*if(string == null || string.isEmpty())
			return formulaStateInfo;*/
		
		//remove surrounding brackets
		while(string.charAt(0) == '(' && string.charAt(string.length()-1) == ')'){
			boolean canRemove = true;
			int openBrackets = 0;
			for(int i = 0; i < string.length(); i++){
				if(string.charAt(i) == '(')
					openBrackets++;
				else if(string.charAt(i) == ')')
					openBrackets--;
				
				if(openBrackets <= 0 && i < string.length()-1){ //first opening bracket got closed too early
					canRemove = false;
					break;
				}
			}
			
			if(canRemove)
				string = string.substring(1, string.length()-1); //upper limit is exclusive
			else
				break;
		}
		
		/*string = string.replaceAll("[+]", ":");
		string = string.replaceAll("[*]", "&");*/
		
		return new FormulaStateInfo(string, formulaStateInfo.getOriginalExpression(), FormulaState.VALID);
	}
	
	public static FormulaStateInfo simplify(FormulaStateInfo formulaStateInfo){
		if(formulaStateInfo.getState() != FormulaState.VALID)
			return formulaStateInfo;
		
		String string = formulaStateInfo.getFormula();
		
		/*if(string == null || string.isEmpty())
			return null;*/
		
		List<String> finalClauses = new LinkedList<String>();
		List<String> clauses = trimStrings(string.split("[" + Constants.AND + "]"));
		for(String clause : clauses){
			List<String> variables = trimStrings(removeSurroundingBrackets(clause).split("[" + Constants.OR + "]"));
			
			//remove tautology clauses
			boolean isTautologyClause = false;
			String negatedLiteral;
			for(int i = 0; i < variables.size(); i++){
				//create negated literal
				if(variables.get(i).charAt(0) == Constants.NOT)
					negatedLiteral = variables.get(i).substring(1);
				else
					negatedLiteral = Constants.NOT + variables.get(i);
			
				for(int j = i+1; j < variables.size(); j++)
					if(variables.get(j).compareToIgnoreCase(negatedLiteral) == 0){ //found dual literals
						isTautologyClause = true;
						break;
					}
			}
			if(isTautologyClause)
				continue; //ignore tautology clauses
			
			//remove duplicates using sets
			List<String> newVariables = new LinkedList<String>(new LinkedHashSet<String>(variables));
			
			String newClause = "(";
			for(int i = 0; i < newVariables.size(); i++){
				newClause = newClause.concat(newVariables.get(i));
				if(i < newVariables.size()-1)
					newClause = newClause.concat(" " + Constants.OR + " ");
			}
			newClause = newClause.concat(")");
			
			finalClauses.add(newClause);
		}
		
		//rebuild formula string of final clauses
		String finalString = "";
		for(int i = 0; i < finalClauses.size(); i++){
			finalString = finalString + finalClauses.get(i);
			if(i < finalClauses.size()-1)
				finalString = finalString + " " + Constants.AND + " ";
		}
		
		//signalize tautology formula
		if(finalString.isEmpty() && !string.isEmpty())
			return new FormulaStateInfo(string, formulaStateInfo.getOriginalExpression(), FormulaState.TAUTOLOGY);
		
		return new FormulaStateInfo(finalString, formulaStateInfo.getOriginalExpression(), FormulaState.VALID);
	}
	
	private static List<String> trimStrings(String strings[]){
		List<String> trimmedStrings = new LinkedList<String>();
		
		for(String string : strings)
			trimmedStrings.add(string.trim());
		
		return trimmedStrings;
	}
	
	public void setVariables(VariableAssignmentBlock variableAssignmentBlock){
		//set normal variable
		Variable variable = variableAssignmentBlock.getVariable();
		variable.setState(variableAssignmentBlock.getAssignment());
		
		//need that to undo variable assignments later on
		this.game.getActionManager().addAction(new VariableAction(variable));

		this.game.update(ObservableType.FORMULA);
	}
	/** Used for the second approach, assigning only whole clauses, when Koopa smashes 
	 * the bricks in a clause. Also need to update clauses, when variables are assigned. 
	 * If all variables within a clause are negatively set, the clause is unsatisfiable 
	 * and its state is updatet accordingly. 
	 * 
	 * Checking for unsatisfiable clauses within this method. */
	/*public void updateClauses(VariableLinkBlock variableLinkBlock){
		setVariables(variableLinkBlock);
		
		//check for unsatisfiable clauses
		boolean satisfiableClause;
		for(Clause clause : this.clauses){
			if(clause.getState() != VariableState.UNDEFINED)
				continue; //already assigned TRUE or FALSE
			
			satisfiableClause = false;
			for(Variable variable : clause.getLiterals()){
				if(getVariable(variable.getName()).getState() == VariableState.UNDEFINED || 
						variable.getState() == getVariable(variable.getName()).getState()){
					satisfiableClause = true;
					break;
				}
			}
			
			if(!satisfiableClause){ //all variables of the clause unsatisfied
				clause.setState(VariableState.FALSE);
				//this.game.getActionManager().addAction(new ClauseAction(clause));
			}
		}
		
		this.game.update(ObservableType.FORMULA);
	}*/
	/** Used for the second approach, assigning only whole clauses, when Koopa smashes 
	 * the bricks in a clause. Also need to update clauses, when variables are assigned. 
	 * If all variables within a clause are negatively set, the clause is unsatisfiable 
	 * and its state is updatet accordingly. 
	 * 
	 * Updating an unlocked clause within this method. */
	public void satisfyClause(Clause clause){
		clause.setSatisfied(VariableState.TRUE);
		
		this.game.update(ObservableType.FORMULA);
	}
	public void checkClausesNP(){
		for(Clause clause : this.clauses)
			checkClauseNP(clause);
	}
	public void checkClauseNP(Clause clause){
		if(clause.getSatisfied() == VariableState.TRUE)
			return;
		
		VariableState clauseSatisfied = VariableState.FALSE; //if all variables are false, state will remain false
		VariableState variableAssignment;
		for(Variable literal : clause.getLiterals()){
			variableAssignment = getVariable(literal.getName()).getSatisfied();
			//check literal state against decision of player; do NOT set clause true if all literals are satisfied
			if(variableAssignment == VariableState.UNDEFINED || literal.getState() == variableAssignment)
				clauseSatisfied = VariableState.UNDEFINED; //clause can not be false anymore
		}
		
		if(clause.getSatisfied() != clauseSatisfied)
			this.game.getActionManager().addAction(new ClauseAction(clause));
		clause.setSatisfied(clauseSatisfied);
		this.game.update(ObservableType.FORMULA);
	}
	
	public void setGame(Game game){
		this.game = game;
	}
}