package model.formula;

import util.Constants;

public class OrOperator implements BinaryOperator{
	public OrOperator(){}
	
	@Override
	public String toString(){
		return Constants.OR + "";
	}
}