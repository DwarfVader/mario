package model.formula;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class QuantifierInfo{
	private List<String> variableNamesOrdered;
	private Map<String, QuantifierType> variables;
	
	public QuantifierInfo(){
		this.variables = new HashMap<String, QuantifierType>();
		this.variableNamesOrdered = new LinkedList<String>();
	}
	
	public void putVariableMapping(String variable, QuantifierType type){
		putVariableMapping(variable, type, false);
	}
	public void putVariableMapping(String variable, QuantifierType type, boolean addOrderedFirst){
		this.variables.put(variable, type);
		if(addOrderedFirst)
			this.variableNamesOrdered.add(0, variable);
		else
			this.variableNamesOrdered.add(variable);
	}
	
	public Map<String, QuantifierType> getVariableMapping(){
		return this.variables;
	}
	public QuantifierType getQuantifierType(String variable){
		return this.variables.get(variable);
	}
	public List<String> getVariableNamesOrdered(){
		return this.variableNamesOrdered;
	}
	public String getVariableName(int index){
		if(index < 0 || index >= this.variableNamesOrdered.size())
			return "index out of bounds";
		
		return this.variableNamesOrdered.get(index);
	}
	public int getIndexOf(String variable){
		return this.variableNamesOrdered.indexOf(variable);
	}
	
	@Override
	public String toString(){
		String string = "";
		
		for(String name : this.variableNamesOrdered)
			string += (this.variables.get(name) == QuantifierType.EXISTENTIAL ? "\u2203" : "\u2200") + name + " ";
		string += ": ";
		
		return string;
	}
}