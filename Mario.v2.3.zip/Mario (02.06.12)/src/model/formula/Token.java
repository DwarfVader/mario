package model.formula;

public interface Token{}