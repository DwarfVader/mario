package model.formula;

public class OpeningBracket implements Token{
	public OpeningBracket(){}
}