package model.animation;

import util.MyBoolean;

public class BooleanCondition implements Condition{
	private MyBoolean value;
	
	public BooleanCondition(MyBoolean value){
		this.value = value;
	}
	
	@Override
	public boolean getState(){
		return value.value;
	}
}