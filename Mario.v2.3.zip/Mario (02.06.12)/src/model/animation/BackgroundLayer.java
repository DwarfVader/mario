package model.animation;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.util.List;

import model.MapPart;
import util.Constants;
import util.MyPoint;

public class BackgroundLayer{
	private int layer; //Starts at 1!
	private Image image;
	private Slideshow slideshow;
	private Dimension imageSize;
	private Dimension size; //defines the number of images in width / height to fill the screen
	private MapPart oldMap;
	private MyPoint offset;
	private Point oldScroll;
	
	public BackgroundLayer(Image image){
		this.image = image;
		this.slideshow = null;
		this.offset = new MyPoint(0, 0);
		this.oldScroll = new Point(0, 0);
		calcSize(image);
	}
	public BackgroundLayer(List<Image> images, int slideshowTime){
		this.image = null;
		this.slideshow = new Slideshow(images, slideshowTime);
		SlideshowManager.getInstance().addBackgroundSlideshow(this.slideshow);
		this.offset = new MyPoint(0, 0);
		this.oldScroll = new Point(0, 0);
		calcSize(this.slideshow.getCurrentImage());
	}
	
	private void calcSize(Image image){
		this.imageSize = new Dimension(image.getWidth(null), image.getHeight(null));
		this.size = new Dimension((int)(Toolkit.getDefaultToolkit().getScreenSize().getWidth()/this.imageSize.width) + 3, 
				(int)(Toolkit.getDefaultToolkit().getScreenSize().getHeight()/this.imageSize.height) + 3);
	}
	
	public void setLayer(int layer){
		if(layer <= 0)
			layer = 1;
		this.layer = layer;
	}
	
	public MyPoint calcOffset(Point scroll, MapPart map){
		if(this.oldMap == null)
			this.oldMap = map;
		
		/*MyPoint offset = new MyPoint(((scroll.x + (map.getIndex().x - this.oldMap.getIndex().x) * 
				Constants.BLOCK_SIZE.width * Constants.MAP_PART_SIZE.width)/(this.layer+1) + 
				this.imageSize.getWidth()) % (int)this.imageSize.getWidth(), 
				((scroll.y + (map.getIndex().y - this.oldMap.getIndex().y) * 
				Constants.BLOCK_SIZE.height * Constants.MAP_PART_SIZE.height)/(this.layer+1) + 
				this.imageSize.getHeight()) % (int)this.imageSize.getHeight());
		//System.out.println(scroll.x + " " + scroll.y);
		System.out.println(offset.x + " " + offset.y);
		this.oldMap = map;*/
		
		/* 1280, 877 */
		double dX = oldScroll.x - scroll.x + (map.getIndex().x - this.oldMap.getIndex().x) * 
				Constants.BLOCK_SIZE.width * Constants.MAP_PART_SIZE.width;
		double dY = oldScroll.y - scroll.y + (map.getIndex().y - this.oldMap.getIndex().y) * 
				Constants.BLOCK_SIZE.height * Constants.MAP_PART_SIZE.height;
		
		this.offset.x.value = (this.offset.x.value - dX/(this.layer+1) + this.imageSize.getWidth()) % this.imageSize.getWidth();
		this.offset.y.value = (this.offset.y.value - dY/(this.layer+1) + this.imageSize.getHeight()) % this.imageSize.getHeight();

		this.oldMap = map;
		this.oldScroll.x = scroll.x;
		this.oldScroll.y = scroll.y;
				
		return this.offset;
		
		/*double dX = (scroll.x - this.oldScroll.x) / (this.layer+1);
		double dY = (scroll.y - this.oldScroll.y) / (this.layer+1);
		
		this.offset.x = (this.offset.x + dX + this.imageSize.getWidth()) % (int)this.imageSize.getWidth();
		this.offset.y = (this.offset.y + dY + this.imageSize.getHeight()) % (int)this.imageSize.getHeight();
		
		this.oldScroll.x = scroll.x;
		this.oldScroll.y = scroll.y;*/
		
		//return offset;
	}
	
	public int getLayer(){
		return this.layer;
	}
	public Image getImage(){
		if(this.image != null)
			return this.image;
		else
			return this.slideshow.getCurrentImage();
	}
	public Dimension getImageSize(){
		return this.imageSize;
	}
	public Dimension getSize(){
		return this.size;
	}
}