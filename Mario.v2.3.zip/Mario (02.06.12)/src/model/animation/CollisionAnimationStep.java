package model.animation;

import java.util.List;

import util.Constants.Direction;

public class CollisionAnimationStep extends AnimationStep{
	protected Direction desiredCollisionDirection;
	
	public CollisionAnimationStep(Direction desiredCollisionDirection, float vx, float vy, boolean ignoreGravity){
		super(vx, vy, ignoreGravity);
		
		this.desiredCollisionDirection = desiredCollisionDirection;
	}
	
	@Override
	public void checkFinishCondition(Object destinationValue){
		if(destinationValue instanceof List<?> && !((List<?>)destinationValue).isEmpty() && 
				((List<?>)destinationValue).get(0) instanceof Direction){
			for(Object collisionDirection : (List<?>)destinationValue)
				if(collisionDirection instanceof Direction && collisionDirection == this.desiredCollisionDirection)
					this.isDone = true;
		}
	}
}