package model.animation;

import java.awt.Image;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import util.ImageLoader;

public class Slideshow{
	private List<Image> images;
	private Image currentImage;
	private int totalTime; //in ms
	private int currentTime;//in ms
	
	private Condition startCondition;
	private boolean resetOnStop;
	
	public Slideshow(Image image, int totalTime){
		this(image, totalTime, null);
	}
	public Slideshow(Image image, int totalTime, Condition startCondition){
		this(image, totalTime, startCondition, true);
	}
	public Slideshow(Image image, int totalTime, Condition startCondition, boolean resetOnStop){
		this(ImageLoader.makeImageList(image), totalTime, startCondition, resetOnStop);
	}	
	public Slideshow(Collection<Image> images, int totalTime){
		this(images, totalTime, null);
	}
	public Slideshow(Collection<Image> images, int totalTime, Condition startCondition){
		this(images, totalTime, startCondition, true);
	}
	public Slideshow(Collection<Image> images, int totalTime, Condition startCondition, boolean resetOnStop){
		if(images != null && !images.isEmpty())
			this.images = new LinkedList<Image>(images);
		else{
			this.images = new LinkedList<Image>();
			this.images.add(ImageLoader.dummyImage);
		}
				
		this.currentImage = this.images.get(0);
		this.totalTime = totalTime;
		this.currentTime = 0;
		this.startCondition = startCondition;
		this.resetOnStop = resetOnStop;
	}
	
	public void incrementTime(int value){
		if(/*!this.isStopped*/ (this.startCondition == null || this.startCondition.getState()) && this.totalTime > 0){ //do not change image on 0 interval
			this.currentTime += value;
			this.currentTime %= this.totalTime;
		}else if(this.resetOnStop){
			this.currentTime = 0;
		}
		
		this.currentImage = this.images.get((int)(((float)this.currentTime / this.totalTime) * this.images.size()));
	}
	
	public void setStartCondition(Condition startCondition){
		this.startCondition = startCondition;
	}
	
	public Image getCurrentImage(){
		return this.currentImage;
	}
	public Image getImage(int index){
		if(index >= 0 && index < this.images.size())
			return this.images.get(index);
		else
			return this.images.get(0);
	}
	public int getTotalTime(){
		return this.totalTime;
	}
}