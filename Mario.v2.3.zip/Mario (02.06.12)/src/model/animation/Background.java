package model.animation;

import java.util.LinkedList;
import java.util.List;

public class Background{
	private List<BackgroundLayer> layers;
	
	public Background(){
		this.layers = new LinkedList<BackgroundLayer>();
	}
	
	public void addLayer(BackgroundLayer layer){
		this.layers.add(layer);
		layer.setLayer(this.layers.size());
	}
	
	public List<BackgroundLayer> getLayers(){
		return this.layers;
	}
	public BackgroundLayer getLayer(int layer){
		if(this.layers.isEmpty() || layer < 0 || layer >= this.layers.size())
			return null;
		
		return this.layers.get(layer);
	}
}