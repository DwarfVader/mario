package model.animation;

import java.awt.Dimension;
import java.awt.Point;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import model.Game;
import model.MapPart;
import util.Constants;

public class SlideshowManager{
	private static SlideshowManager instance;
	
	private Queue<Slideshow> movableSlideshows;
	private Queue<Slideshow> coinSlideshows;
	private Queue<Slideshow> backgroundSlideshows;
	private Map<MapPart, Queue<Slideshow>> slideshowMapping;
	
	private SlideshowManager(){
		this.movableSlideshows = new ConcurrentLinkedQueue<Slideshow>();
		this.coinSlideshows = new ConcurrentLinkedQueue<Slideshow>();
		this.backgroundSlideshows = new ConcurrentLinkedQueue<Slideshow>();
		this.slideshowMapping = new HashMap<MapPart, Queue<Slideshow>>();
	}
	public static SlideshowManager getInstance(){
		if(instance == null)
			instance = new SlideshowManager();
		
		return instance;
	}
	
	public static void reset(){
		instance = new SlideshowManager();
	}
	
	public void addMovableSlideshow(Slideshow slideshow){
		this.movableSlideshows.add(slideshow);
	}
	public void addMovableSlideshows(Collection<Slideshow> slideshows){
		this.movableSlideshows.addAll(slideshows);
	}
	public void removeMovableSlideshow(Slideshow slideshow){
		this.movableSlideshows.remove(slideshow);
	}
	public void removeMovableSlideshows(Collection<Slideshow> slideshows){
		this.movableSlideshows.removeAll(slideshows);
	}
	
	public void addCoinSlideshow(Slideshow slideshow){
		this.coinSlideshows.add(slideshow);
	}
	public void addCoinSlideshows(Collection<Slideshow> slideshows){
		this.coinSlideshows.addAll(slideshows);
	}
	public void removeCoinSlideshow(Slideshow slideshow){
		this.coinSlideshows.remove(slideshow);
	}
	public void removeCoinSlideshows(Collection<Slideshow> slideshows){
		this.coinSlideshows.removeAll(slideshows);
	}
	
	public void addBackgroundSlideshow(Slideshow slideshow){
		this.backgroundSlideshows.add(slideshow);
	}
	public void addBackgroundSlideshows(Collection<Slideshow> slideshows){
		this.backgroundSlideshows.addAll(slideshows);
	}
	public void removeBackgroundSlideshow(Slideshow slideshow){
		this.backgroundSlideshows.remove(slideshow);
	}
	public void removeBackgroundSlideshows(Collection<Slideshow> slideshows){
		this.backgroundSlideshows.removeAll(slideshows);
	}
	
	public void addSlideshow(MapPart map, Slideshow slideshow){
		if(!this.slideshowMapping.keySet().contains(map))
			this.slideshowMapping.put(map, new ConcurrentLinkedQueue<Slideshow>());
		
		this.slideshowMapping.get(map).add(slideshow);
	}
	public void addSlideshows(MapPart map, Collection<Slideshow> slideshows){
		if(!this.slideshowMapping.keySet().contains(map))
			this.slideshowMapping.put(map, new ConcurrentLinkedQueue<Slideshow>());
		
		this.slideshowMapping.get(map).addAll(slideshows);
	}
	public void removeSlideshow(MapPart map, Slideshow slideshow){
		if(this.slideshowMapping.keySet().contains(map))
			this.slideshowMapping.get(map).remove(slideshow);
	}
	public void removeSlideshows(MapPart map, Collection<Slideshow> slideshows){
		if(this.slideshowMapping.keySet().contains(map))
			this.slideshowMapping.get(map).removeAll(slideshows);
	}
	
	public void incrementTime(Game game, int value){
		for(Slideshow slideshow : this.movableSlideshows)
			slideshow.incrementTime(value);
		for(Slideshow slideshow : this.coinSlideshows)
			slideshow.incrementTime(value);
		for(Slideshow slideshow : this.backgroundSlideshows)
			slideshow.incrementTime(value);
		
		//consider all blocks that are going to be rendered
		Dimension numMapsToRender = Constants.NUM_MAPS_TO_RENDER;
		Point offset = new Point(-numMapsToRender.width/2, -numMapsToRender.height/2);
		if(game.getCurMap().getIndex().x + offset.x < 0)
			offset.x = -game.getCurMap().getIndex().x;
		else if(game.getCurMap().getIndex().x + offset.x + numMapsToRender.width >= game.getNumMapParts().width)
			offset.x = game.getNumMapParts().width - game.getCurMap().getIndex().x - numMapsToRender.width;
		if(game.getCurMap().getIndex().y + offset.y < 0)
			offset.y = -game.getCurMap().getIndex().y;
		else if(game.getCurMap().getIndex().y + offset.y + numMapsToRender.height >= game.getNumMapParts().height)
			offset.y = game.getNumMapParts().height - game.getCurMap().getIndex().y - numMapsToRender.height;
		for(int ii = 0 + offset.x; ii < numMapsToRender.width + offset.x; ii++)
			for(int jj = 0 + offset.y; jj < numMapsToRender.height + offset.y; jj++){
				MapPart map = game.getMap(game.getCurMap().getIndex().x + ii, game.getCurMap().getIndex().y + jj);
				if(map == null)
					continue;
				
				for(int i = 0; i < Constants.MAP_PART_SIZE.width; i++)
					for(int j = 0; j < Constants.MAP_PART_SIZE.height; j++){
						map.getBlockHolder(i, j).getBlock().getSlideshow().incrementTime(value);
					}
			}
	}
}