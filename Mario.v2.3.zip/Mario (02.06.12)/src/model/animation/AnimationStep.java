package model.animation;

import util.Constants;
import util.MyPoint;

public abstract class AnimationStep{
	protected MyPoint moveVelocity;
	protected boolean ignoreGravity;
	protected boolean isDone;
	protected boolean isRunning;
	
	public AnimationStep(float vx, float vy, boolean ignoreGravity){
		this.moveVelocity = new MyPoint(vx / 1000 * Constants.TIMER_INTERVAL, vy / 1000 * Constants.TIMER_INTERVAL);
		this.ignoreGravity = ignoreGravity;
		this.isRunning = false;
	}
	
	/*public void updateVelocity(Mario mario){
		//if(!isRunning){
			double speedX = Math.abs(mario.getVelocityX()) + 
					(Math.abs(this.moveVelocity.x.value) > Math.abs(mario.getVelocityX()) ? 1 : -1) * 
					(Constants.MARIO_ACCELERATION/10 / 1000 * Constants.TIMER_INTERVAL) / 1000 * Constants.TIMER_INTERVAL;
			
			mario.setVelocityX(speedX * (this.moveVelocity.getX() > 0 ? 1 : -1));
			mario.setVelocityY(this.moveVelocity.y.value);
			
			this.isRunning = true;
		//}
	}*/
	
	public abstract void checkFinishCondition(Object destinationValue);
	
	public boolean isIgnoreHorizontalCollision(){
		return false; //default
	}
	public boolean isIgnoreVerticalCollision(){
		return false; //default
	}
	
	public double getVelocityX(){
		return this.moveVelocity.x.value;
	}
	public double getVelocityY(){
		return this.moveVelocity.y.value;
	}
	public boolean isIgnoreGravity(){
		return this.ignoreGravity;
	}
	public boolean isDone(){
		return this.isDone;
	}
	public boolean isRunning(){
		return this.isRunning;
	}
}