package model;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.util.List;

import util.Collidable;
import util.Constants;
import util.Constants.Direction;
import util.ImageLoader;
import util.MyPoint;

public class FinishGate implements Collidable{
	private MapPart map;
	private MyPoint location;
	private Image frontImage;
	private Image backImage;
	private FinishBar bar;
	
	public FinishGate(MapPart map, MyPoint location){
		this.map = map;
		this.location = location;
		this.frontImage = ImageLoader.finishFrontImage;
		this.backImage = ImageLoader.finishBackImage;
		this.bar = new FinishBar(map, new MyPoint(location.getX(), location.getY() + Constants.BLOCK_SIZE.height), 
				getCollisionSize().height - Constants.BLOCK_SIZE.height);
	}
	
	public MapPart getMap(){
		return this.map;
	}
	
	public Image getFrontImage(){
		return this.frontImage;
	}
	public Image getBackImage(){
		return this.backImage;
	}
	
	public MyPoint getRenderLocationFront(){
		return new MyPoint(this.location.x.value - Constants.BLOCK_SIZE.width, 
				this.location.y.value - this.frontImage.getHeight(null) + Constants.BLOCK_SIZE.height);
	}
	public MyPoint getRenderLocationBack(){
		return new MyPoint(this.location.x.value + Constants.BLOCK_SIZE.width, 
				this.location.y.value - this.backImage.getHeight(null) + Constants.BLOCK_SIZE.height);
	}
	
	@Override
	public List<Direction> collides(Collidable collidable, Point offset){
		return null;
	}
	@Override
	public List<Direction> collides(Collidable collidable, Point offset, boolean ignorePassable){
		return null;
	}

	@Override
	public MyPoint getLocation(){
		return new MyPoint(this.location);
	}
	@Override
	public MyPoint getCollisionLocation(){
		return new MyPoint(this.location.x.value, this.location.y.value - getCollisionSize().height + Constants.BLOCK_SIZE.height);
	}
	@Override
	public MyPoint getOldCollisionLocation(){
		return getCollisionLocation();
	}
	@Override
	public Dimension getCollisionSize(){
		return new Dimension(Constants.BLOCK_SIZE.width, 9 * Constants.BLOCK_SIZE.height);
	}
	@Override
	public MapPart getCurMap(){
		return this.map;
	}

	@Override
	public Image getImage(){
		return ImageLoader.dummyImage; //dummy
	}
	public FinishBar getBar(){
		return this.bar;
	}
}