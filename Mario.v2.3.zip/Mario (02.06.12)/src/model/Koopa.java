package model;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

import model.animation.SlideshowManager;
import model.blocks.BlockHolder;
import util.Collidable;
import util.Constants;
import util.Constants.Direction;
import util.ImageLoader;
import util.Movable;
import util.MyPoint;

public class Koopa implements Movable{
	private Game game;
	private MapPart curMap;
	private MyPoint location;
	private MyPoint oldLocation;
	private MyPoint velocity;
	private Stack<Direction> moveDirections;
	private Direction lastMoveDirection;
	private boolean isStunned;
	
	private Image image;
	
	public Koopa(Game game, MapPart map, MyPoint location){
		this.game = game;
		this.curMap = map;
		this.location = new MyPoint(location);
		this.oldLocation = new MyPoint(location);
		this.moveDirections = new Stack<Direction>();
		this.lastMoveDirection = Direction.WEST;
		this.velocity = new MyPoint(0, 0);
		
		reset();
	}
	
	public void reset(){
		this.isStunned = false;
		updateImage();
	}
	
	@Override
	public void move(){
		setOldLocation(this.location);
		
		if(!isStunned){
			this.velocity.x.value = (this.lastMoveDirection == Direction.EAST ? 1 : -1) * 
					Constants.MAX_MOVE_SPEED/10 / 1000 * Constants.TIMER_INTERVAL;
		}
		
		if(this.velocity.y.value < Constants.MAX_FALLING_SPEED / 1000 * Constants.TIMER_INTERVAL) //define a maximum falling speed
			this.velocity.y.value += (Constants.GRAVITY / 1000 * Constants.TIMER_INTERVAL) / 1000 * Constants.TIMER_INTERVAL; //increase falling speed until it reaches its limit
		
		//change location by velocity values on every method call
		this.location.x.value += this.velocity.x.value;
		this.location.y.value += this.velocity.y.value;
		
		checkMapChange();
		updateImage();
	}
	
	private void checkMapChange(){
		if(this.location.x.value >= Constants.MAP_PART_SIZE.width*Constants.BLOCK_SIZE.width)
			changeMap(this.curMap.getIndex().x + 1, this.curMap.getIndex().y);
		else if(this.location.x.value < 0)
			changeMap(this.curMap.getIndex().x - 1, this.curMap.getIndex().y);
		
		if(this.location.y.value >= Constants.MAP_PART_SIZE.height*Constants.BLOCK_SIZE.height)
			changeMap(this.curMap.getIndex().x, this.curMap.getIndex().y + 1);
		else if(this.location.y.value < 0)
			changeMap(this.curMap.getIndex().x, this.curMap.getIndex().y - 1);
	}
	private void changeMap(int i, int j){
		MapPart newMap = this.game.getMap(i, j);
		int maxWidth = Constants.MAP_PART_SIZE.width*Constants.BLOCK_SIZE.width;
		int maxHeight = Constants.MAP_PART_SIZE.height*Constants.BLOCK_SIZE.height;
		if(newMap != null){
			int dx = this.curMap.getIndex().x - i;
			int dy = this.curMap.getIndex().y - j;
			this.location.x.value += dx * maxWidth;
			this.location.y.value += dy * maxHeight;
			
			//need to change old location as well
			this.oldLocation.x.value += dx * maxWidth;
			this.oldLocation.y.value += dy * maxHeight;

			this.curMap = newMap;
		}
	}
	
	@Override
	public void updateImage(){
		if(this.isStunned){
			if(this.velocity.x.value == 0)
				this.image = ImageLoader.koopaShellImages.get(0);
			else
				this.image = SlideshowManager.getInstance().koopaShellSlideshow.getCurrentImage();
		}else{
			if(this.velocity.x.value >= 0)
				this.image = SlideshowManager.getInstance().koopaRunRightSlideshow.getCurrentImage();
			else
				this.image = SlideshowManager.getInstance().koopaRunLeftSlideshow.getCurrentImage();
		}
	}
	
	@Override
	public List<Direction> collides(Collidable collidable, Point offset){
		return collides(collidable, offset, false);
	}
	@Override
	public List<Direction> collides(Collidable collidable, Point offset, boolean ignorePassable){
		List<Direction> collisionDirections = new LinkedList<Direction>();
		
		//collision with block holder containing a passable block; ignorePassable needed for detection of last block to avoid falling
		if(!ignorePassable && collidable instanceof BlockHolder && 
				Constants.typePassableMapping.get(((BlockHolder)collidable).getBlock().getType()))
			collisionDirections.add(Direction.NONE);
		else{ //collision
			collisionDirections.add(collides(new MyPoint(this.location.x.value, oldLocation.y.value), collidable, offset, Direction.HORIZONTAL));
			collisionDirections.add(collides(new MyPoint(oldLocation.x.value, this.location.y.value), collidable, offset, Direction.VERTICAL));
		}
		
		return collisionDirections;
	}
	public Direction collides(MyPoint koopaLocation, Collidable collidable, Point offset, Direction collisionDirection){
		//have to check for both vertical and horizontal collision
		if(collisionDirection == Direction.HORIZONTAL && collidesVertical(koopaLocation, collidable, offset.y) != Direction.NONE)
			return collidesHorizontal(koopaLocation, collidable, offset.x); //EAST or WEST or NONE
		else if(collisionDirection == Direction.VERTICAL && collidesHorizontal(koopaLocation, collidable, offset.x) != Direction.NONE)
			return collidesVertical(koopaLocation, collidable, offset.y); //NORTH or SOUTH or NONE
		
		return Direction.NONE;
	}
	private Direction collidesHorizontal(MyPoint koopaLocation, Collidable collidable, int offsetX){
		/** Attention: Doesn't make sense without parallel vertical collision check! */
		if(koopaLocation.x.value + Constants.DEFAULT_BLOCK_SIZE.width > collidable.getCollisionLocation().x.value + offsetX + 
				Constants.DEFAULT_KOOPA_SIZE_OFFSET && 
				koopaLocation.x.value < collidable.getCollisionLocation().x.value + offsetX + collidable.getCollisionSize().width - 
				Constants.DEFAULT_KOOPA_SIZE_OFFSET){
			//left side is outside block
			if(koopaLocation.x.value < collidable.getCollisionLocation().x.value + offsetX)
				return Direction.EAST;
			else if(koopaLocation.x.value + Constants.DEFAULT_BLOCK_SIZE.width >= 
					collidable.getCollisionLocation().x.value + offsetX + Constants.DEFAULT_BLOCK_SIZE.width)
				return Direction.WEST;
		}
		return Direction.NONE;
	}
	private Direction collidesVertical(MyPoint koopaLocation, Collidable collidable, int offsetY){
		/** Attention: Doesn't make sense without parallel horizontal collision check! */
		/** Attention: Mario's location is based on his feet! */
		//there is a vertical collision
		if(koopaLocation.y.value > collidable.getCollisionLocation().y.value + offsetY + 0 && 
				koopaLocation.y.value - Constants.DEFAULT_BLOCK_SIZE.height < 
				collidable.getCollisionLocation().y.value + offsetY + collidable.getCollisionSize().height - 
				Constants.DEFAULT_KOOPA_SIZE_OFFSET){
			//head is above the top of the block; his feet touch the block
			if(koopaLocation.y.value - Constants.DEFAULT_BLOCK_SIZE.height < collidable.getCollisionLocation().y.value + offsetY)
				return Direction.SOUTH;
			else if(koopaLocation.y.value >= collidable.getCollisionLocation().y.value + offsetY + 
					Constants.DEFAULT_BLOCK_SIZE.height)
				return Direction.NORTH;
		}
		//no vertical collision
		return Direction.NONE;
	}
	
	public void stun(){
		this.isStunned = true;
		this.velocity.x.value = 0;
	}
	public void kick(Direction direction){
		if(this.isStunned){
			this.velocity.x.value = (direction == Direction.WEST ? -1 : 1) * 
					Constants.MAX_MOVE_SPEED / 1000 * Constants.TIMER_INTERVAL;
		}
	}

	public void setCurMap(MapPart map){
		this.curMap = map;
	}
	@Override
	public void setLocation(MyPoint location){
		setLocation(location.x.value, location.y.value);
	}
	@Override
	public void setLocation(double x, double y){
		this.location.x.value = x;
		this.location.y.value = y;
	}
	@Override
	public void setLocationX(double x){
		this.location.x.value = x;
	}
	@Override
	public void setLocationY(double y){
		this.location.y.value = y;
	}
	@Override
	public void setOldLocation(MyPoint oldLocation){
		setOldLocation(oldLocation.x.value, oldLocation.y.value);
	}
	@Override
	public void setOldLocation(double x, double y){
		this.oldLocation.x.value = x;
		this.oldLocation.y.value = y;
	}
	public void setVelocity(MyPoint velocity){
		setVelocityX(velocity.x.value);
		setVelocityY(velocity.y.value);
	}
	@Override
	public void setVelocityX(double vx){
		this.velocity.x.value = vx;
		if(this.velocity.x.value > 0)
			this.lastMoveDirection = Direction.EAST;
		else
			this.lastMoveDirection = Direction.WEST;
	}
	@Override
	public void setVelocityY(double vy){
		this.velocity.y.value = vy;
	}
	public void setMoveDirection(Direction moveDirection){
		if(!this.moveDirections.contains(moveDirection)){
			this.moveDirections.add(moveDirection);
			this.lastMoveDirection = moveDirection;
		}
	}
	public void resetMoveDirection(Direction moveDirection){
		this.moveDirections.remove(moveDirection);
	}
	@Override
	public void setFeetOnGround(){}
	
	public MapPart getCurMap(){
		return this.curMap;
	}
	public MyPoint getLocation(){
		return this.location;
	}
	@Override
	public MyPoint getOldLocation(){
		return this.oldLocation;
	}
	public MyPoint getVelocity(){
		return this.velocity;
	}
	public boolean isStunned(){
		return this.isStunned;
	}
	
	@Override
	public MyPoint getCollisionLocation(){
		return new MyPoint(this.location.x.value, this.location.y.value - getCollisionSize().height);
	}
	@Override
	public MyPoint getOldCollisionLocation(){
		return new MyPoint(this.oldLocation.x.value, this.oldLocation.y.value - getCollisionSize().height);
	}
	@Override
	public Dimension getCollisionSize(){
		float width = Constants.DEFAULT_BLOCK_SIZE.width-2*Constants.DEFAULT_KOOPA_SIZE_OFFSET*2f/3;
		return new Dimension((int)width, (int)(width*
				(this.isStunned ? Constants.KOOPA_SHELL_SIZE_RATIO : Constants.KOOPA_NORMAL_SIZE_RATIO)));
	}
	@Override
	public double getVelocityX(){
		return this.velocity.x.value;
	}
	@Override
	public double getVelocityY(){
		return this.velocity.y.value;
	}
	@Override
	public Direction getLastMoveDirection(){
		return this.lastMoveDirection;
	}
	@Override
	public Image getImage(){
		return this.image;
	}
}