package model.blocks;

import model.MapPart;
import model.formula.Variable;
import util.Constants;
import util.Constants.BlockType;
import util.VariableState;

public class VariableAssignmentBlock extends LabelBlock{
	private Variable variable;
	private VariableState assignment;
	
	public VariableAssignmentBlock(MapPart map, BlockType type, Variable variable){
		super(map, type, null);
		
		this.variable = variable;
		this.assignment = (type == BlockType.VARIABLE_ASSIGNMENT_POSITIVE ? VariableState.TRUE : VariableState.FALSE);
		if(type == BlockType.VARIABLE_ASSIGNMENT_POSITIVE_LABEL || type == BlockType.VARIABLE_ASSIGNMENT_NEGATIVE_LABEL)
			this.label = (type == BlockType.VARIABLE_ASSIGNMENT_NEGATIVE_LABEL ? Constants.NOT : "") + variable.getName();
	}
	
	public Variable getVariable(){
		return this.variable;
	}
	public VariableState getAssignment(){
		return this.assignment;
	}
}