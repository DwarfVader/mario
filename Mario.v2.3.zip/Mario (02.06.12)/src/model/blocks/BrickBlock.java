package model.blocks;

import model.MapPart;
import model.formula.Clause;
import util.Constants.BlockType;

public class BrickBlock extends Block{
	private Clause clause;
	
	public BrickBlock(MapPart map, BlockType type, Clause clause){
		super(map, type);
		
		this.clause = clause;
	}
	
	public Clause getClause(){
		return this.clause;
	}
}