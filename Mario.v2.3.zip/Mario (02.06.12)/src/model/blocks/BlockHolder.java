package model.blocks;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.util.List;

import model.MapPart;
import util.Collidable;
import util.Constants.Direction;
import util.MyPoint;

public class BlockHolder implements Collidable{
	private Block block;
	private MyPoint defaultLocation;
	private MyPoint location;
	
	public BlockHolder(MyPoint location){
		this.defaultLocation = new MyPoint(location);
		this.location = new MyPoint(location);
	}
	
	public void resetLocation(){
		this.location.x = this.defaultLocation.x;
		this.location.y = this.defaultLocation.y;
	}
	
	public void setBlock(Block block){
		this.block = block;
	}
	
	public void interchangeLocation(BlockHolder other){
		MyPoint help = new MyPoint(this.defaultLocation);
		this.defaultLocation = other.defaultLocation;
		other.defaultLocation = help;
	}
	
	public void setLocation(int x, int y){
		this.location.x.value = x;
		this.location.y.value = y;
	}
	
	public Block getBlock(){
		return this.block;
	}
	public MyPoint getDefaultLocation(){
		return this.defaultLocation;
	}
	public MyPoint getLocation(){
		return this.location;
	}
	
	@Override
	public MyPoint getCollisionLocation(){
		return this.location;
		//return new MyPoint(this.location.x + (Constants.DEFAULT_BLOCK_SIZE.width - this.block.getCollisionSize().width)/2,
		//		this.location.y + (Constants.DEFAULT_BLOCK_SIZE.height - this.block.getCollisionSize().height)/2);
	}
	@Override
	public MyPoint getOldCollisionLocation(){
		return this.location;
		//return new MyPoint(this.location.x + (Constants.DEFAULT_BLOCK_SIZE.width - this.block.getCollisionSize().width)/2,
		//		this.location.y + (Constants.DEFAULT_BLOCK_SIZE.height - this.block.getCollisionSize().height)/2);
	}
	@Override
	public Dimension getCollisionSize(){
		return this.block.getCollisionSize();
	}

	@Override
	public Image getImage(){
		throw new RuntimeException("BlockHolder.getImage() was called. Should not have been entered!");
	}
	
	@Override
	public MapPart getCurMap(){
		return null; //dummy
	}

	@Override
	public List<Direction> collides(Collidable collidable, Point offset){
		return null;
	}
	@Override
	public List<Direction> collides(Collidable collidable, Point offset, boolean ignorePassable){
		return null;
	}
}