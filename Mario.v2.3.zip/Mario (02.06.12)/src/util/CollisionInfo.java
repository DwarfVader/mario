package util;

import util.Constants.Direction;

public class CollisionInfo{
	private boolean isColliding;
	private Direction collisionDirection;
	private double collisionValue;
	
	public CollisionInfo(boolean isColliding){
		this(isColliding, null, 0);
	}
	public CollisionInfo(boolean isColliding, Direction collisionDirection, double collisionValue){
		this.isColliding = isColliding;
		this.collisionDirection = collisionDirection;
		this.collisionValue = collisionValue;
	}
	
	public boolean isColliding(){
		return this.isColliding;
	}
	public Direction getCollisionDirection(){
		return this.collisionDirection;
	}
	public double getCollisionValue(){
		return this.collisionValue;
	}
}