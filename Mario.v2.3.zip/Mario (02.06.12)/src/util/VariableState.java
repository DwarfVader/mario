package util;

public enum VariableState{
	UNDEFINED, 
	TRUE, 
	FALSE
}