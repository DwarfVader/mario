package util;

import java.awt.Point;

public class LabelInfo{
	private Point index;
	private String label;
	
	public LabelInfo(Point index, String label){
		this.index = index;
		this.label = label;
	}
	
	public Point getIndex(){
		return this.index;
	}
	public String getLabel(){
		return this.label;
	}
}