package util;

import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import model.GameMapTemplate;
import util.Constants.BlockType;

public class MapLoader{
	private MapLoader(){}
	
	private static String path = "/maps/";
	private static boolean ok = false;
	
	private static Map<Character, BlockType> charMapping = new HashMap<Character, BlockType>();
	public static Map<String, GameMapTemplate> mapMapping = new HashMap<String, GameMapTemplate>();
	
	public static void init(){
		if(!loadMapsFromFiles()){
			System.out.println("MapLoader: Probleme beim Laden der Karten!");
			return;
		}
		mapMapping.get("crossover2").mirrorHorizontally();
		mapMapping.get("finish").mirrorHorizontally();
		mapMapping.get("finish_pspace").mirrorHorizontally();
		ok = true;
	}
	
	public static boolean isOk(){
		return ok;
	}
	
	public static void initCharMapping(){
		if(charMapping.isEmpty()){ //avoid multiple initializations
			charMapping.put('e', BlockType.ENTRANCE);
			charMapping.put('.', BlockType.EMPTY);
			charMapping.put('w', BlockType.WALL);
			charMapping.put('k', BlockType.KOOPA);
			charMapping.put('m', BlockType.MUSHROOM_BLOCK);
			charMapping.put('c', BlockType.COIN_BLOCK);
			charMapping.put('f', BlockType.FLAG);
			charMapping.put('h', BlockType.FLAG_HEAD);
			charMapping.put('g', BlockType.FINISH_GATE);
			charMapping.put('a', BlockType.COIN);
			charMapping.put('l', BlockType.LABEL);
			charMapping.put('j', BlockType.LABEL_LITERAL);
			charMapping.put('p', BlockType.VARIABLE_ASSIGNMENT_POSITIVE);
			charMapping.put('n', BlockType.VARIABLE_ASSIGNMENT_NEGATIVE);
			charMapping.put('+', BlockType.VARIABLE_ASSIGNMENT_POSITIVE_LABEL);
			charMapping.put('-', BlockType.VARIABLE_ASSIGNMENT_NEGATIVE_LABEL);
			charMapping.put('<', BlockType.ARROW);
			
			charMapping.put('x', BlockType.VINE);
			charMapping.put('y', BlockType.FIREBALL);
			charMapping.put('i', BlockType.STONE);
			charMapping.put('r', BlockType.ROTATE_BLOCK);
			charMapping.put('t', BlockType.TRAMPOLINE);
			charMapping.put('u', BlockType.TRAMPOLINE_FIXED);
			charMapping.put('d', BlockType.TRAMPOLINE_DESTINATION);
			
			charMapping.put('0', BlockType.CROSSOVER_UP_LEFT_MAP);
			charMapping.put('1', BlockType.CROSSOVER_DOWN_LEFT_MAP);
			charMapping.put('2', BlockType.CROSSOVER_UP_RIGHT_MAP);
			charMapping.put('3', BlockType.CROSSOVER_DOWN_RIGHT_MAP);
			charMapping.put('4', BlockType.DOOR_MAP);
		}
	}
	
	public static boolean loadMapsFromFiles(){
		if(charMapping.isEmpty())
			initCharMapping();
		
		//if there are problems, false will be returned
		return loadMapFromFile(path + "variable.map") && loadMapFromFile(path + "clause.map") && 
				loadMapFromFile(path + "link_entrance.part") && loadMapFromFile(path + "link_clause.part") && 
				loadMapFromFile(path + "clause_entrance.part") && loadMapFromFile(path + "link_exit.part") && 
				loadMapFromFile(path + "variable_entrance_left.part") && loadMapFromFile(path + "variable_entrance_right.part") && 
				loadMapFromFile(path + "variable_exit.part") && loadMapFromFile(path + "jump_down.map") && 
				loadMapFromFile(path + "clause_pass_through_left.part") && 
				loadMapFromFile(path + "clause_pass_through_right.part") && loadMapFromFile(path + "clause_bricks.part") && 
				loadMapFromFile(path + "finish_entrance.part") && loadMapFromFile(path + "finish_flag.part") && 
				loadMapFromFile(path + "start_mushroom.part") && loadMapFromFile(path + "start_obstacle.part") && 
				loadMapFromFile(path + "start.map") && loadMapFromFile(path + "finish.map") && 
				loadMapFromFile(path + "start_pspace.map") && loadMapFromFile(path + "finish_pspace.map") && 
				loadMapFromFile(path + "crossover1.map") && loadMapFromFile(path + "crossover2.map") && 
				loadMapFromFile(path + "path1.part") && loadMapFromFile(path + "path2.part") && 
				loadMapFromFile(path + "path3.part") && loadMapFromFile(path + "path4.part") && 
				loadMapFromFile(path + "path5.part") && loadMapFromFile(path + "path6.part") && 
				loadMapFromFile(path + "path7.part") && loadMapFromFile(path + "path8.part") && 
				loadMapFromFile(path + "path9.part") && loadMapFromFile(path + "path10.part") && 
				loadMapFromFile(path + "path11.part") && loadMapFromFile(path + "path12.part") && 
				loadMapFromFile(path + "path13.part") && loadMapFromFile(path + "path14.part") && 
				loadMapFromFile(path + "path17.part") && loadMapFromFile(path + "path19.part") && 
				loadMapFromFile(path + "path20.part") && loadMapFromFile(path + "path21.part") && 
				loadMapFromFile(path + "path22.part") && loadMapFromFile(path + "path23.part") && 
				loadMapFromFile(path + "path25.part") && loadMapFromFile(path + "path27.part") && 
				loadMapFromFile(path + "path28.part") && 
				loadMapFromFile(path + "path29.part") && loadMapFromFile(path + "path30.part") && 
				loadMapFromFile(path + "path31.part") && loadMapFromFile(path + "path15.part") && 
				loadMapFromFile(path + "path53.part") && loadMapFromFile(path + "path57.part") && 
				loadMapFromFile(path + "path52.part") && loadMapFromFile(path + "path54.part") && 
				loadMapFromFile(path + "seppl.part") && loadMapFromFile(path + "easteregg.part") && 
				loadMapFromFile(path + "crossover_up.map") && loadMapFromFile(path + "crossover_down.map") && 
				loadMapFromFile(path + "door.map") && loadMapFromFile(path + "ex_quantifier_control.part") && 
				loadMapFromFile(path + "ex_quantifier.part") && loadMapFromFile(path + "un_quantifier_control.part") && 
				loadMapFromFile(path + "un_quantifier.part") && loadMapFromFile(path + "generalized_door.map");
	}
	
	private static boolean loadMapFromFile(String file){
		try{
			Dimension mapSize = new Dimension(-1, -1); //dummy
			String mapName = ""; //dummy
			BlockType types[][] = null;
			int currentMapLine = 0;
			
			BufferedReader inStream = new BufferedReader(new InputStreamReader(MapLoader.class.getResource(file).openStream()));
			
			String line, tokens[];
			while((line = inStream.readLine()) != null){
				if(line.isEmpty() || line.charAt(0) == '#') //ignore empty and comment lines
					continue;
				
				//read in size and initialize map
				//definition line of format ': width height name'
				if(line.charAt(0) == ':' && types == null){ //only allow one initialization
					tokens = line.split(" "); //split will lead to [:, width, height, name]
					mapSize = new Dimension(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]));
					types = new BlockType [mapSize.width][mapSize.height];
					mapName = tokens[3];
					if(mapMapping.containsKey(mapName)){
						inStream.close();
						return true; //avoid duplicates
					}
					continue; //continue with next line; don't use the same line again in the next if-block
				}
				
				if(types != null){
					tokens = line.split(" ");
					
					for(int i = 0; i < mapSize.width; i++)
						types[i][currentMapLine] = charMapping.get(tokens[i].charAt(0)); //single-letter string
					
					currentMapLine++;
				}else
					System.out.println("Datei '" + file + "' ist fehlerhaft: Definition der Kartengr��e (mit ':') " +
							"muss als erste Anweisung erfolgen!");
			}
			
			mapMapping.put(mapName, new GameMapTemplate(types, mapSize));
			inStream.close();
		}catch(Exception e){
			e.printStackTrace();
			return false; //in case of exception -> problems in loading files
		}
		
		return true; //no exception thrown; fine
	}
}