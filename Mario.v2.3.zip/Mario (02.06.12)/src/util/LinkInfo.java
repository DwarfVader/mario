package util;

import model.MapPart;
import model.blocks.BlockHolder;

public class LinkInfo{
	private MapPart link;
	private BlockHolder entranceBlockHolder;
	
	public LinkInfo(MapPart link, BlockHolder entranceBlockHolder){
		this.link = link;
		this.entranceBlockHolder = entranceBlockHolder;
	}
	
	public MapPart getLink(){
		return this.link;
	}
	public BlockHolder getEntranceBlockHolder(){
		return this.entranceBlockHolder;
	}
}