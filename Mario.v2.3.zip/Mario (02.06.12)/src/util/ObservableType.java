package util;

public enum ObservableType{
	GUI_DEFAULT,
	//GUI_NEW_MAP,
	GAME_STATE,
	GAME_ERROR_STATE,
	FORMULA
}