package util;

public class MyPoint{
	public MyDouble x;
	public MyDouble y;
	
	public MyPoint(MyPoint other){
		this(other.x.value, other.y.value);
	}
	public MyPoint(double x, double y){
		this.x = new MyDouble(x);
		this.y = new MyDouble(y);
	}
	
	public void add(MyPoint other){
		this.x.value += other.x.value;
		this.y.value += other.y.value;
	}
	
	public int getX(){
		return (int)Math.round(this.x.value);
	}
	public int getY(){
		return (int)Math.round(this.y.value);
	}
}