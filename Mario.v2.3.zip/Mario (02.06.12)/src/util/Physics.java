package util;

import java.awt.Point;

import util.Constants.Direction;

public class Physics{
	public static CollisionInfo collidesHorizontally(Collidable actor, Collidable other, Point offset){
		/* Objects have to really lie (partially) inside each other. Edge contact does NOT count as collision! */
		if(actor.getCollisionLocation().x.value + actor.getCollisionSize().width > other.getCollisionLocation().x.value + offset.x && 
				actor.getCollisionLocation().x.value < other.getCollisionLocation().x.value + offset.x + other.getCollisionSize().width && 
				actor.getOldCollisionLocation().y.value + actor.getCollisionSize().height > other.getCollisionLocation().y.value + offset.y && 
				actor.getOldCollisionLocation().y.value < other.getCollisionLocation().y.value + offset.y + other.getCollisionSize().height){
			Direction collisionDirection = null;
			double collisionValue = 0; //initial values used in case of actor lying completely inside other
			if(actor.getCollisionLocation().x.value < other.getCollisionLocation().x.value + offset.x){
				collisionDirection = Direction.WEST;
				collisionValue = other.getCollisionLocation().x.value + offset.x - actor.getCollisionSize().width;
			}else if(actor.getCollisionLocation().x.value + actor.getCollisionSize().width > 
					other.getCollisionLocation().x.value + offset.x + other.getCollisionSize().width){
				collisionDirection = Direction.EAST;
				collisionValue = other.getCollisionLocation().x.value + offset.x + other.getCollisionSize().width;
			}
			
			return new CollisionInfo(true, collisionDirection, collisionValue);
		}
		
		return new CollisionInfo(false);
	}
	public static CollisionInfo collidesVertically(Collidable actor, Collidable other, Point offset){
		/* Objects have to really lie (partially) inside each other. Edge contact does NOT count as collision! */
		if(actor.getOldCollisionLocation().x.value + actor.getCollisionSize().width > other.getCollisionLocation().x.value + offset.x && 
				actor.getOldCollisionLocation().x.value < other.getCollisionLocation().x.value + offset.x + other.getCollisionSize().width && 
				actor.getCollisionLocation().y.value + actor.getCollisionSize().height > other.getCollisionLocation().y.value + offset.y && 
				actor.getCollisionLocation().y.value < other.getCollisionLocation().y.value + offset.y + other.getCollisionSize().height){
			Direction collisionDirection = null;
			double collisionValue = 0; //initial values used in case of actor lying completely inside other
			if(actor.getCollisionLocation().y.value < other.getCollisionLocation().y.value + offset.y){ //actor's top above other
				collisionDirection = Direction.SOUTH;
				collisionValue = other.getCollisionLocation().y.value + offset.y - actor.getCollisionSize().height;
			}else if(actor.getCollisionLocation().y.value + actor.getCollisionSize().height > //actor's bottom below other
					other.getCollisionLocation().y.value + offset.y + other.getCollisionSize().height){
				collisionDirection = Direction.NORTH;
				collisionValue = other.getCollisionLocation().y.value + offset.y + other.getCollisionSize().height;
			}
			
			return new CollisionInfo(true, collisionDirection, collisionValue);
		}
		
		return new CollisionInfo(false);
	}
}