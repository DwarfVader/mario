package view;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

import model.Game;
import model.action.ActionManager;
import model.action.EntranceAction;
import util.Constants;
import util.GameMode;
import util.Language;
import util.ObservableType;

public class GameFrame extends JFrame implements Observer{
	private static final long serialVersionUID = -6399886456682347905L;

	private Container contentPane;
	private GamePanel gamePanel;
	private FormulaPanel formulaPanel;
	private JScrollPane formulaScrollPane;
	
	private ActionManager actionManager;
	private JMenuBar menuBar;
	private JMenu menuFile;
	private JMenu menuUndo;
	private JMenuItem menuItemEnd;
	private JMenuItem menuItemRestart;
	
	private Dimension unextendedSize;
	private Thread resizeThread;
	private boolean resizingInProgress;
	private long latestResizeTime;
	
	//private Game game;
	private JCheckBoxMenuItem chkBoxFullscreen;

	private JMenu menuWindow;
	
	public GameFrame(){
		addWindowStateListener(new WindowStateListener(){
			public void windowStateChanged(WindowEvent e){
				if(e.getNewState() == JFrame.MAXIMIZED_BOTH)
					GameFrame.this.setExtendedState(JFrame.NORMAL);
			}
		});
		addComponentListener(new ComponentAdapter(){
			@Override
			public void componentResized(ComponentEvent e){
				if(!resizingInProgress){
					latestResizeTime = System.currentTimeMillis();
					
					initResizeThread();
				}
			}
		});
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){
			e.printStackTrace();
		}
		
		this.resizingInProgress = false;
		
		//setUndecorated(true);
		setVisible(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		//setExtendedState(getExtendedState() | MAXIMIZED_BOTH);
		
		setSize(Constants.FRAME_SIZE);
		setPreferredSize(getSize());
		setLocation(Constants.calcFrameLocation(getSize()));
		setTitle("Super Formula World");
		this.unextendedSize = new Dimension(getSize());
		
		this.contentPane = getContentPane();
		this.contentPane.setBackground(Color.DARK_GRAY);
		this.contentPane.setLayout(null);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		menuFile = new JMenu(Language.getString("file"));
		menuBar.add(menuFile);
		
		menuItemRestart = new JMenuItem(Language.getString("restart"));
		menuFile.add(menuItemRestart);
		
		menuItemEnd = new JMenuItem(Language.getString("end"));
		menuFile.add(menuItemEnd);
		
		menuUndo = new JMenu(Language.getString("undo"));
		menuBar.add(menuUndo);
		
		menuWindow = new JMenu(Language.getString("window"));
		menuBar.add(menuWindow);
		
		chkBoxFullscreen = new JCheckBoxMenuItem(Language.getString("fullscreen"));
		chkBoxFullscreen.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent arg0){
				changeWindowMode();
			}
		});
		menuWindow.add(chkBoxFullscreen);
		
		this.gamePanel = new GamePanel();
		this.gamePanel.setSize(Constants.GAME_PANEL_SIZE);
		this.gamePanel.setPreferredSize(this.gamePanel.getSize());
		this.gamePanel.setLocation(0, 0);
		this.contentPane.add(this.gamePanel);
		
		this.formulaPanel = new FormulaPanel();
		
		this.formulaScrollPane = new JScrollPane(this.formulaPanel);
		this.formulaScrollPane.setBorder(null);
		this.formulaScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		this.formulaScrollPane.setSize(Constants.FORMULA_PANEL_SIZE);
		this.formulaScrollPane.setLocation(0, this.gamePanel.getLocation().y + this.gamePanel.getSize().height);
		getContentPane().add(this.formulaScrollPane);
	}
	
	public void languageChanged(){
		menuFile.setText(Language.getString("file"));
		menuItemRestart.setText(Language.getString("restart"));
		menuItemEnd.setText(Language.getString("end"));
		menuUndo.setText(Language.getString("undo"));
		menuWindow.setText(Language.getString("window"));
		chkBoxFullscreen.setText(Language.getString("fullscreen"));
	}
	
	private void changeWindowMode(){
		if(this.chkBoxFullscreen.isSelected()){
			this.unextendedSize = new Dimension(getSize());
			setSize(Toolkit.getDefaultToolkit().getScreenSize());
			setLocation(0, 0);
			setVisible(false);
			dispose();
			setUndecorated(true);
			setVisible(true);
			//setExtendedState(getExtendedState() | MAXIMIZED_BOTH);
		}else{
			setSize(this.unextendedSize);
			setLocation(Constants.calcFrameLocation(getSize()));
			setVisible(false);
			dispose();
			setUndecorated(false);
			setVisible(true);
		}
		
		resize();
	}
	
	@Override
	public void update(Observable arg0, Object arg1){
		if(arg0 instanceof Game){
			if(arg1 != null && !(arg1 instanceof ObservableType))
				return; //ignore illegal arguments
			if(((Game)arg0).getCurFormula() == null)
				return; //ignore on non-existing formula
			
			if(Constants.GAME_MODE == GameMode.NORMAL && ((Game)arg0).getCurFormula().getCnfInfo().getQuantifierInfo() == null){
				this.menuUndo.setVisible(true); //only visible in NP framework and normal mode
			}else{ //hardcore or PSPACE frameork
				this.menuUndo.setVisible(false);
			}
			
			ObservableType type = (ObservableType)arg1;
			switch(type){
			case GUI_DEFAULT:
				this.gamePanel.repaint();
				break;
			case FORMULA:
				double value = this.formulaScrollPane.getHorizontalScrollBar().getValue();
				double minValue = this.formulaScrollPane.getHorizontalScrollBar().getMinimum();
				double maxValue = this.formulaScrollPane.getHorizontalScrollBar().getMaximum();
				value = ((value-minValue) / (maxValue-minValue))*(float)this.formulaPanel.getPreferredSize().width;
				
				this.formulaPanel.resize();
				this.formulaScrollPane.getViewport().setViewPosition(new Point((int)value, 0));
				
				break;
			default:
				//nothing to do
			}
		}else if(arg0 instanceof ActionManager){
			this.menuUndo.removeAll();
			
			for(final EntranceAction entranceAction : this.actionManager.getEntranceActions()){
				JMenuItem entranceActionUndoItem = new JMenuItem(Language.getString("undo until") + ": " + entranceAction.toString());
				entranceActionUndoItem.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						GameFrame.this.actionManager.undoUntil(entranceAction);
					}
				});
				entranceActionUndoItem.setHorizontalAlignment(SwingConstants.LEFT);
				entranceActionUndoItem.setVerticalAlignment(SwingConstants.CENTER);
				this.menuUndo.add(entranceActionUndoItem);
			}
			
			this.gamePanel.repaint();
			this.formulaPanel.repaint();
		}
	}
	
	public void initResizeThread(){
		if(this.resizeThread == null || !this.resizeThread.isAlive()){
			this.resizeThread = new Thread(new Runnable(){
				private int interval = 200;
				
				@Override
				public void run(){
					try{
						while(System.currentTimeMillis() - latestResizeTime < interval){
							Thread.sleep(interval);
						}
						
						resize();
					}catch(Exception e){}
				}
			});
			
			this.resizeThread.start();
		}
	}
	private void resize(){
		if(resizingInProgress)
			return;
		
		this.resizingInProgress = true;
		
		if(!this.chkBoxFullscreen.isSelected()){
			if(getSize().width < Constants.GAME_FRAME_MINIMUM_SIZE.width)
				setSize(Constants.GAME_FRAME_MINIMUM_SIZE.width, getSize().height);
			if(getSize().height < Constants.GAME_FRAME_MINIMUM_SIZE.height)
				setSize(getSize().width, Constants.GAME_FRAME_MINIMUM_SIZE.height);
			
			setPreferredSize(getSize());
			
			Constants.GAME_FRAME_SIZE.setSize(getSize().width-getInsets().left-getInsets().right, 
					getSize().height-getInsets().top-getInsets().bottom);
		}else
			Constants.GAME_FRAME_SIZE.setSize(getSize());
		
		Constants.resize(); //This needs to be called first!
		if(gamePanel != null){
			gamePanel.resize();
		}
		if(formulaPanel != null){
			formulaPanel.resize();
		}
		if(formulaScrollPane != null){
			formulaScrollPane.setSize(Constants.FORMULA_PANEL_SIZE);
			formulaScrollPane.setLocation(0, gamePanel.getLocation().y + gamePanel.getSize().height);
		}
		
		this.resizingInProgress = false;
	}
	
	public void setGame(Game game){
		//this.game = game;
		this.actionManager = game.getActionManager();
		this.gamePanel.setGame(game);
		this.formulaPanel.setGame(game);
	}
	
	public GamePanel getGamePanel(){
		return this.gamePanel;
	}
	/** Attention! Do not confuse with getMenuBar() of the frame. */
	public JMenuBar getMyMenuBar(){
		return this.menuBar;
	}
	public JMenu getMenuFile(){
		return this.menuFile;
	}
	public JMenu getMenuUndo(){
		return this.menuUndo;
	}
	public JMenuItem getMenuItemEnd(){
		return this.menuItemEnd;
	}
	public JMenuItem getMenuItemRestart(){
		return this.menuItemRestart;
	}
}